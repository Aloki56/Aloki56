#!/usr/bin/env bash
# start.sh — start the WhatsApp bridge in the background, then the FastAPI app.
set -e
cd /app

# 1) WhatsApp bridge (Node + Baileys)
echo "📱 Starting WhatsApp bridge…"
node channels/whatsapp/server.js &
WA_PID=$!

# 2) FastAPI app
echo "🚀 Starting FastAPI…"
exec uvicorn app:app --host 0.0.0.0 --port ${APP_PORT:-8000} --workers 1
