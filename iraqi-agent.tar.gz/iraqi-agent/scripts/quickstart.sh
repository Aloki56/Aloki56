#!/usr/bin/env bash
# scripts/quickstart.sh
# Setup + start the bot in one command.
# Usage:
#   bash scripts/quickstart.sh

set -e

cd "$(dirname "$0")/.."

GREEN='\033[92m'
RED='\033[91m'
YELLOW='\033[93m'
CYAN='\033[96m'
BOLD='\033[1m'
RESET='\033[0m'

echo -e "${CYAN}${BOLD}"
echo "═══════════════════════════════════════════════════"
echo "  🇮🇶 IRAQI AGENT — QUICK START"
echo "═══════════════════════════════════════════════════"
echo -e "${RESET}"

# 1) Check .env
if [ ! -f .env ]; then
    echo -e "${YELLOW}⚠️  .env ما موجود — أنشئ واحد من .env.example${RESET}"
    if [ -f .env.example ]; then
        cp .env.example .env
        echo -e "${GREEN}✅${RESET} أنشأت .env من .env.example"
        echo -e "${YELLOW}   عبّي المفاتيح وبعدين أعد تشغيل السكربت${RESET}"
        echo ""
        echo "   لازم تضيف:"
        echo "   1) TELEGRAM_BOT_TOKEN (من @BotFather)"
        echo "   2) ADMIN_TELEGRAM_ID (من @userinfobot)"
        echo "   3) GROQ_API_KEY أو GOOGLE_API_KEY (للـ LLM)"
        echo ""
        exit 1
    fi
fi

# 2) Check Python
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ Python 3 مو موجود${RESET}"
    exit 1
fi

# 3) Check Node (for WhatsApp bridge)
if ! command -v node &> /dev/null; then
    echo -e "${YELLOW}⚠️  Node مو موجود — الواتساب ما راح يشتغل${RESET}"
fi

# 4) Install Python deps
echo -e "${CYAN}→ نصب Python deps...${RESET}"
pip install -q -r requirements.txt 2>&1 | tail -2 || pip install -q --break-system-packages -r requirements.txt

# 5) Install Node deps
if command -v npm &> /dev/null; then
    echo -e "${CYAN}→ نصب Node deps...${RESET}"
    npm install --silent 2>&1 | tail -2
fi

# 6) Diagnostic
echo ""
echo -e "${CYAN}→ تشخيص البوت...${RESET}"
python3 scripts/diagnose_bot.py

# 7) Start
echo ""
echo -e "${CYAN}→ تشغيل المشروع...${RESET}"
echo -e "${YELLOW}   اضغط Ctrl+C للإيقاف${RESET}"
echo ""

bash start.sh
