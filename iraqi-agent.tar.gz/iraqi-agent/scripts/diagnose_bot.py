#!/usr/bin/env python3
"""
scripts/diagnose_bot.py
اختبر شغلية البوت قبل ما تشغّل المشروع كامل.

يفحص:
  - الـ token صحيح؟
  - شو اسم البوت؟
  - في webhook conflict؟
  - الـ admin ID صحيح؟
  - البوت يگدر يبعت رسائل؟

شغّله:
    python scripts/diagnose_bot.py
"""
import os
import sys
import json
import urllib.request
import urllib.parse
from pathlib import Path

# Try to load .env
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "")
ADMIN = os.environ.get("ADMIN_TELEGRAM_ID", "0")

GREEN = "\033[92m"
RED = "\033[91m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
BOLD = "\033[1m"
RESET = "\033[0m"


def http_get(url, timeout=10):
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            return r.status, json.loads(r.read().decode())
    except Exception as e:
        return 0, {"error": str(e)}


def http_post(url, data, timeout=10):
    try:
        body = urllib.parse.urlencode(data).encode()
        req = urllib.request.Request(url, data=body, method="POST")
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, json.loads(r.read().decode())
    except Exception as e:
        return 0, {"error": str(e)}


def main():
    print(f"\n{CYAN}{BOLD}═══════════════════════════════════════════════{RESET}")
    print(f"{CYAN}{BOLD}  🇮🇶 IRAQI AGENT — BOT DIAGNOSTIC{RESET}")
    print(f"{CYAN}{BOLD}═══════════════════════════════════════════════{RESET}\n")

    # 1) Check token
    if not TOKEN or ":" not in TOKEN:
        print(f"{RED}❌ TELEGRAM_BOT_TOKEN مفقود أو غير صالح بـ .env{RESET}")
        print(f"   حطه بشكل: TELEGRAM_BOT_TOKEN=123456:ABCDEF...")
        sys.exit(1)
    print(f"{GREEN}✅{RESET} Token موجود: {TOKEN[:10]}...{TOKEN[-5:]}")

    # 2) getMe
    print(f"\n{CYAN}→ /getMe{RESET}")
    status, data = http_get(f"https://api.telegram.org/bot{TOKEN}/getMe")
    if status == 200 and data.get("ok"):
        bot = data["result"]
        print(f"{GREEN}✅{RESET} البوت شغّال!")
        print(f"   الاسم: {bot.get('first_name')}")
        print(f"   اليوزر: @{bot.get('username')}")
        print(f"   ID: {bot.get('id')}")
    else:
        print(f"{RED}❌ فشل: {data}{RESET}")
        sys.exit(1)

    # 3) Webhook check
    print(f"\n{CYAN}→ /getWebhookInfo{RESET}")
    status, data = http_get(f"https://api.telegram.org/bot{TOKEN}/getWebhookInfo")
    if status == 200:
        wh = data.get("result", {})
        if wh.get("url"):
            print(f"{YELLOW}⚠️{RESET}  Webhook مفعل: {wh['url']}")
            print(f"   لازم نحذفه عشان polling يشتغل محلياً")
            print(f"   أو حط WEBHOOK_URL بـ .env واستخدم ngrok")
        else:
            print(f"{GREEN}✅{RESET} ماكو webhook (ممتاز للـ polling)")

    # 4) Check admin
    print(f"\n{CYAN}→ ADMIN_TELEGRAM_ID{RESET}")
    if not ADMIN or ADMIN == "0":
        print(f"{YELLOW}⚠️{RESET}  ماكو admin ID! أول واحد يبعت رسالة راح يصير admin تلقائياً")
    else:
        print(f"{GREEN}✅{RESET} Admin ID: {ADMIN}")

    # 5) Test send to admin
    if ADMIN and ADMIN != "0":
        print(f"\n{CYAN}→ إرسال رسالة تجريبية للـ admin...{RESET}")
        status, data = http_post(
            f"https://api.telegram.org/bot{TOKEN}/sendMessage",
            {
                "chat_id": ADMIN,
                "text": (
                    "🟢 *البوت شغّال!*\n\n"
                                    "هسه إذا شغّلت المشروع محلياً (bash start.sh أو make run)\n"
                                    "كل الأوامر راح تشتغل.\n\n"
                                    "الأوامر الأساسية:\n"
                                    "/start — بداية\n"
                                    "/whoami — شوف ID تبعك\n"
                                    "/help — كل الأوامر\n"
                                    "/dashboard — لوحة المعلومات"
                ),
                "parse_mode": "Markdown",
            }
        )
        if status == 200 and data.get("ok"):
            print(f"{GREEN}✅{RESET} تم إرسال رسالة تجريبية للـ admin {ADMIN}")
        else:
            print(f"{YELLOW}⚠️{RESET}  فشل الإرسال: {data}")
            print(f"   تأكد إنك أرسلت /start للبوت قبل، عشان يگدر يبعتلك")

    # 6) Pending messages
    print(f"\n{CYAN}→ /getUpdates (الرسائل اللي ما انردت عليها){RESET}")
    status, data = http_get(f"https://api.telegram.org/bot{TOKEN}/getUpdates?timeout=2")
    if status == 200 and data.get("ok"):
        updates = data.get("result", [])
        if updates:
            print(f"{YELLOW}⚠️{RESET}  {len(updates)} رسالة ما انردت عليها")
            for u in updates[:3]:
                msg = u.get("message", {})
                print(f"   من: {msg.get('from', {}).get('first_name', '?')} ({msg.get('from', {}).get('id', '?')})")
                print(f"   قال: {msg.get('text', '')[:80]}")
        else:
            print(f"{GREEN}✅{RESET} ماكو رسائل معلقة")
    elif status == 409:
        print(f"{RED}❌ Webhook conflict — شغّل البوت محلياً أولاً، أو:{RESET}")
        print(f"   curl 'https://api.telegram.org/bot{TOKEN}/deleteWebhook'")

    print(f"\n{CYAN}{BOLD}═══════════════════════════════════════════════{RESET}")
    print(f"{BOLD}  الخطوات التالية:{RESET}")
    print(f"  1) cd /workspace/iraqi-agent")
    print(f"  2) pip install -r requirements.txt")
    print(f"  3) npm install")
    print(f"  4) bash start.sh")
    print(f"  5) أرسل /start للبوت")
    print(f"{CYAN}{BOLD}═══════════════════════════════════════════════{RESET}\n")


if __name__ == "__main__":
    main()
