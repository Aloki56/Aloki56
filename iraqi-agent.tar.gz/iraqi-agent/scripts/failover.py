#!/usr/bin/env python3
"""
scripts/failover.py
Multi-instance leader election using free Upstash Redis.
Run this as a sidecar in the Docker image (or as a separate service).
"""
import os
import time
import socket
import requests
import redis
from loguru import logger

CF_API = "https://api.cloudflare.com/client/v4"

def main():
    cf_token = os.environ.get("CF_TOKEN")
    cf_zone  = os.environ.get("CF_ZONE_ID")
    cf_rec   = os.environ.get("CF_RECORD_ID")
    pub_ip   = os.environ.get("PUBLIC_IP")
    redis_url= os.environ["UPSTASH_REDIS_URL"]
    ttl      = int(os.environ.get("LEADER_TTL", "25"))
    interval = int(os.environ.get("LEADER_INTERVAL", "20"))

    r = redis.from_url(redis_url)
    KEY = "iraqi-agent:leader"
    ID  = f"{socket.gethostname()}-{os.getpid()}"
    logger.info(f"Failover loop starting, id={ID}")

    while True:
        try:
            became = r.set(KEY, ID, ex=ttl, nx=True)
            current = r.get(KEY)
            if current == ID.encode():
                logger.info("👑 I am leader")
                # If Cloudflare creds given, point DNS to us.
                if cf_token and cf_zone and cf_rec and pub_ip:
                    try:
                        requests.put(
                            f"{CF_API}/zones/{cf_zone}/dns_records/{cf_rec}",
                            headers={"Authorization": f"Bearer {cf_token}"},
                            json={"type": "A", "name": "agent",
                                  "content": pub_ip, "ttl": 60, "proxied": False},
                            timeout=10,
                        ).raise_for_status()
                    except Exception as e:
                        logger.warning(f"DNS update failed: {e!r}")
            elif became:
                logger.info(f"👑 I just became leader (was {current!r})")
            else:
                logger.info(f"😴 standby (leader={current!r})")
        except Exception as e:
            logger.error(f"Failover loop error: {e!r}")
        time.sleep(interval)


if __name__ == "__main__":
    main()
