#!/usr/bin/env python3
"""
scripts/worker.py
Background worker that runs periodic tasks:
  - Extract customer facts from recent conversations
  - Re-index RAG when KB files change
  - Sweep expired subscriptions
  - Run usage analytics & emit metrics
  - Send billing reminders
"""
from __future__ import annotations
import asyncio
import time
from loguru import logger

from memory.manager import get_memory_manager
from rag.pipeline import get_rag
from billing.subscription import get_subscription_manager
from billing.invoices import get_invoice_manager
from monitoring.alerts import get_alert_manager
from monitoring.metrics import metrics
from tenants.store import get_store


async def extract_facts_loop(interval: int = 1800):
    """Every 30 min, look at recent conversations and extract facts."""
    while True:
        try:
            await asyncio.sleep(interval)
            tenants = get_store().list_all()
            for t in tenants:
                # Look for facts the LLM might catch
                recent = get_memory_manager().cm.search(t.tenant_id, "", limit=20)
                # Naive heuristic: detect phone numbers + emails
                import re
                for msg in recent:
                    content = msg.content or ""
                    for m in re.findall(r"(07[0-9]{9}|\+?9647[0-9]{9})", content):
                        get_memory_manager().upsert_fact(
                            t.tenant_id, msg.user_id, "phone", m, confidence=0.9,
                        )
                    for m in re.findall(r"[\w.+-]+@[\w-]+\.[\w.-]+", content):
                        get_memory_manager().upsert_fact(
                            t.tenant_id, msg.user_id, "email", m, confidence=0.95,
                        )
        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.error(f"extract_facts: {e!r}")


async def subscription_sweep_loop(interval: int = 3600):
    """Hourly: warn about subscriptions that will expire soon."""
    while True:
        try:
            await asyncio.sleep(interval)
            sm = get_subscription_manager()
            for sub in sm.list_expiring(within_days=3):
                if sub.tier != "trial":
                    await get_alert_manager().alert(
                        "warn",
                        f"اشتراك {sub.tenant_id} ينتهي خلال {sub.days_remaining()} يوم",
                        f"الباقة: {sub.current_tier().name_ar}\n"
                        f"التجديد التلقائي: {'مفعل' if sub.auto_renew else 'معطل'}",
                        key=f"expiring:{sub.tenant_id}",
                    )
        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.error(f"subscription_sweep: {e!r}")


async def metrics_emit_loop(interval: int = 60):
    """Update gauges."""
    while True:
        try:
            await asyncio.sleep(interval)
            tenants = get_store().list_all()
            metrics.active_tenants.set(
                sum(1 for t in tenants if t.status == "active")
            )
        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.error(f"metrics_emit: {e!r}")


async def main():
    logger.info("🔧 Background worker started")
    await asyncio.gather(
        extract_facts_loop(),
        subscription_sweep_loop(),
        metrics_emit_loop(),
    )


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Worker stopped")
