#!/usr/bin/env python3
"""
scripts/onboard.py
Quick CLI to add a tenant without using the Telegram bot.

Usage:
  python -m scripts.onboard --id baghdad_kebab \
      --name "مطعم بغداد" --owner "أبو محمد" --phone 96477xxx \
      --type مطعم --address "شارع المتنبي" --hours "١٠ ص - ١١ م" \
      --kb-file menu.txt
"""
import argparse
import os
import sys
from pathlib import Path

# Allow running from project root
sys.path.insert(0, str(Path(__file__).parent.parent))

from tenants.manager import create_tenant
from tenants.schemas import ChannelConfig


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--id", required=True)
    p.add_argument("--name", required=True)
    p.add_argument("--owner", required=True)
    p.add_argument("--phone", required=True)
    p.add_argument("--type", default="مطعم")
    p.add_argument("--address", default="")
    p.add_argument("--hours", default="يومياً ١٠ ص - ١١ م")
    p.add_argument("--kb", default="", help="Knowledge base text")
    p.add_argument("--kb-file", default="", help="Read KB from this file")
    p.add_argument("--fee", type=int, default=50000, help="Monthly fee in IQD")
    args = p.parse_args()

    kb = args.kb
    if args.kb_file and os.path.exists(args.kb_file):
        with open(args.kb_file, "r", encoding="utf-8") as f:
            kb = f.read()

    t = create_tenant(
        tenant_id=args.id,
        business_name=args.name,
        owner_name=args.owner,
        owner_phone=args.phone,
        business_type=args.type,
        address=args.address,
        working_hours=args.hours,
        knowledge_base=kb,
        monthly_fee_iqd=args.fee,
    )
    print(f"✅ Created tenant '{t.tenant_id}' — {t.business_name}")


if __name__ == "__main__":
    main()
