#!/usr/bin/env python3
"""
scripts/health.py
Hit /health on the local agent to verify everything is up.
Exits 0 on success, 1 on any error.

Useful for cron + UptimeRobot / healthchecks.io.
"""
import sys
import os
import json
import urllib.request
from pathlib import Path

URL = os.environ.get("HEALTH_URL", "http://localhost:8000/health")


def main():
    try:
        with urllib.request.urlopen(URL, timeout=10) as r:
            data = json.load(r)
        if data.get("status") != "ok":
            print(f"❌ Health check failed: {data}")
            sys.exit(1)
        print(f"✅ {json.dumps(data, indent=2, ensure_ascii=False)}")
        sys.exit(0)
    except Exception as e:
        print(f"❌ Could not reach agent at {URL}: {e!r}")
        sys.exit(1)


if __name__ == "__main__":
    main()
