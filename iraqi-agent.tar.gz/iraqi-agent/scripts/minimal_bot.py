#!/usr/bin/env python3
"""
scripts/minimal_bot.py
🪶 بوت مصغّر جداً — يشتغل بأقل عدد من المكتبات.

الهدف: تتأكد إن البوت + Token + Admin ID شغّالين ١٠٠٪
بدون ما تعتمد على RAG / Billing / LangGraph / etc.

شغّله:
    pip install python-telegram-bot python-dotenv
    python scripts/minimal_bot.py

الأوامر المدعومة:
    /start  - ترحيب
    /whoami - يگولك الـ ID
    /help    - كل الأوامر
    /echo    - يردد رسالتك
    /ping    - Pong!
"""
import os
import sys
import asyncio
import logging
from pathlib import Path

# Load .env if exists
try:
    from dotenv import load_dotenv
    load_dotenv(Path(".env"))
except ImportError:
    pass

try:
    from telegram import Update
    from telegram.ext import (
        Application, CommandHandler, MessageHandler,
        ContextTypes, filters,
    )
except ImportError:
    print("❌ python-telegram-bot مو مثبت")
    print("   شغّل: pip install python-telegram-bot")
    sys.exit(1)


TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "")
ADMIN_ID = os.environ.get("ADMIN_TELEGRAM_ID", "0")

# Configure logging
logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    level=logging.INFO,
)
log = logging.getLogger("minimal_bot")


async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    is_admin = str(user.id) == str(ADMIN_ID) if ADMIN_ID != "0" else False

    msg = (
        f"🟢 أهلاً {user.first_name or 'صديقي'}!\n\n"
        f"🆔 الـ ID تبعك: {user.id}\n"
        f"👑 Admin: {'✅ إي' if is_admin else '❌ لا'}\n\n"
        f"الأوامر:\n"
        f"/start — بداية\n"
        f"/whoami — بياناتك\n"
        f"/help — المساعدة\n"
        f"/ping — فحص الاتصال\n"
        f"/echo <نص> — يردد\n\n"
        f"📝 ADMIN_ID: {ADMIN_ID}"
    )
    await update.message.reply_text(msg)


async def cmd_whoami(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    msg = (
        f"👤 بياناتك\n\n"
        f"🆔 ID: {user.id}\n"
        f"📛 الاسم: {user.first_name or ''} {user.last_name or ''}\n"
        f"🔗 @{user.username or '—'}\n\n"
    )
    if str(user.id) == str(ADMIN_ID) and ADMIN_ID != "0":
        msg += "✅ أنت admin. شغّال كل شي."
    elif ADMIN_ID == "0":
        msg += "⚠️ ماكو ADMIN_ID بـ .env. أنت أول واحد، صرت admin تلقائياً."
    else:
        msg += f"⛔ ADMIN_ID المعرّف: {ADMIN_ID}"
    await update.message.reply_text(msg)


async def cmd_help(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "📖 الأوامر المتاحة:\n\n"
        "/start — بداية\n"
        "/whoami — بياناتك\n"
        "/help — المساعدة\n"
        "/ping — pong\n"
        "/echo <نص> — يردد\n\n"
        "إذا هذا البوت المصغّر يشتغل، البوت الكامل راح يشتغل."
    )


async def cmd_ping(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🏓 Pong!")


async def cmd_echo(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    text = " ".join(ctx.args) if ctx.args else "(ما كتبت شي)"
    await update.message.reply_text(f"🔊 {text}")


async def on_text(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Catch-all for plain text messages."""
    if update.message and update.message.text:
        await update.message.reply_text(
            f"هلا خيو! 👋\n"
            f"بعث /help عشان تشوف الأوامر.\n"
            f"رسالتك كانت: {update.message.text[:200]}"
        )


def main():
    if not TOKEN or ":" not in TOKEN:
        print("❌ TELEGRAM_BOT_TOKEN مفقود أو غير صالح بـ .env")
        print(f"   Token الحالي: {TOKEN[:30] if TOKEN else '(فاضي)'}")
        sys.exit(1)

    print(f"🔧 Token: {TOKEN[:10]}...{TOKEN[-5:]}")
    print(f"👑 Admin: {ADMIN_ID}")
    print()

    # Build app
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("whoami", cmd_whoami))
    app.add_handler(CommandHandler("help", cmd_help))
    app.add_handler(CommandHandler("ping", cmd_ping))
    app.add_handler(CommandHandler("echo", cmd_echo))
    # Catch-all for non-command text
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text))

    print("🚀 Starting bot...")
    print("📱 أرسل /start من تيليكرام")
    print("⏹️  Ctrl+C للإيقاف")
    print()

    try:
        app.run_polling(drop_pending_updates=False, allowed_updates=["message"])
    except KeyboardInterrupt:
        print("\n👋 Bot stopped")
    except Exception as e:
        print(f"❌ Error: {e!r}")
        sys.exit(1)


if __name__ == "__main__":
    main()
