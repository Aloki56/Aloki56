#!/usr/bin/env python3
"""
scripts/run_bot.py
🎯 مشغّل البوت الذكي — يشخّص المشكلة ويگولك شو الحل.

Modes:
    --mode=minimal   البوت المصغّر (موصى به للبداية)
    --mode=full      البوت الكامل بكل الـ features
    --mode=check     فحص بدون تشغيل
    --mode=webhook   تشغيل بـ webhook (production)
"""
import os
import sys
import subprocess
import argparse
from pathlib import Path


def log(emoji, msg, color="\033[0m"):
    print(f"{color}{emoji} {msg}\033[0m")


def green(msg): return log("✅", msg, "\033[92m")
def red(msg):   return log("❌", msg, "\033[91m")
def yellow(msg):return log("⚠️ ", msg, "\033[93m")
def cyan(msg):  return log("🔷", msg, "\033[96m")
def bold(msg):  return log("🔹", msg, "\033[1m")


def check_python():
    """Check Python version."""
    bold(f"Python: {sys.version.split()[0]}")
    if sys.version_info < (3, 11):
        red("Python 3.11+ مطلوب")
        return False
    return True


def check_dep(module, friendly=""):
    """Check if a Python module is installed."""
    try:
        __import__(module)
        return True
    except ImportError:
        red(f"مكتبة مفقودة: {friendly or module}")
        return False


def check_all_deps(mode="minimal"):
    """Check all required dependencies for a mode."""
    bold("فحص المكتبات...")
    ok = True

    # Always required
    for mod, name in [
        ("telegram", "python-telegram-bot"),
        ("dotenv", "python-dotenv"),
    ]:
        if not check_dep(mod, name):
            ok = False

    if mode == "full":
        # Full bot deps
        deps = [
            ("fastapi", "fastapi"),
            ("uvicorn", "uvicorn"),
            ("httpx", "httpx"),
            ("loguru", "loguru"),
            ("tinydb", "tinydb"),
            ("pydantic_settings", "pydantic-settings"),
            ("tenacity", "tenacity"),
        ]
        for mod, name in deps:
            if not check_dep(mod, name):
                ok = False
                yellow(f"   شغّل: pip install {name}")

    return ok


def check_token():
    """Verify token format + reachability."""
    bold("فحص Token...")
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
    if not token:
        red("TELEGRAM_BOT_TOKEN مو موجود بـ .env")
        return False
    if ":" not in token or len(token.split(":")[0]) < 6:
        red(f"Token شكله غلط: {token[:20]}...")
        return False

    # Try to reach Telegram API
    import urllib.request, json
    try:
        with urllib.request.urlopen(
            f"https://api.telegram.org/bot{token}/getMe", timeout=10
        ) as r:
            data = json.loads(r.read())
            if data.get("ok"):
                bot = data["result"]
                green(f"Token شغّال! @{bot.get('username')} (id={bot.get('id')})")
                return True
            else:
                red(f"Token مو مقبول من Telegram: {data}")
                return False
    except Exception as e:
        red(f"ما گدرت أتصل بـ Telegram: {e!r}")
        return False


def check_admin_id():
    """Verify admin ID is set."""
    bold("فحص Admin ID...")
    admin = os.environ.get("ADMIN_TELEGRAM_ID", "0")
    if admin == "0" or not admin:
        yellow("ADMIN_TELEGRAM_ID ما محدد — أول مستخدم يصير admin تلقائياً")
    else:
        green(f"Admin ID: {admin}")
    return True


def check_running_bot():
    """Check if any process is using our bot."""
    import urllib.request, json
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
    if not token:
        return False, None
    try:
        with urllib.request.urlopen(
            f"https://api.telegram.org/bot{token}/getUpdates", timeout=5
        ) as r:
            data = json.loads(r.read())
            if data.get("ok"):
                return False, data.get("result", [])
    except urllib.error.HTTPError as e:
        if e.code == 409:
            return True, None
    except Exception:
        pass
    return False, None


def run_minimal():
    """Run the minimal bot."""
    bold("تشغيل البوت المصغّر...")
    print()
    # Use subprocess so we don't block
    proc = subprocess.run([sys.executable, "scripts/minimal_bot.py"])
    return proc.returncode


def run_full():
    """Run the full bot."""
    bold("تشغيل البوت الكامل...")
    print()
    # Try the main app entry
    proc = subprocess.run([sys.executable, "app.py"])
    return proc.returncode


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", default="minimal",
                        choices=["minimal", "full", "check", "webhook"])
    args = parser.parse_args()

    # Load .env
    try:
        from dotenv import load_dotenv
        load_dotenv(Path(".env"))
    except ImportError:
        yellow("python-dotenv مو مثبت — متغيرّات .env ما راح تنقرأ")
        yellow("شغّل: pip install python-dotenv")
        if args.mode != "check":
            red("لازم تثقّل .env! شغّل --mode=check للتفاصيل")

    print()
    cyan("═══════════════════════════════════════════════")
    cyan("  🇮🇶 IRAQI AGENT — BOT RUNNER")
    cyan("═══════════════════════════════════════════════")
    print()

    if not check_python():
        sys.exit(1)

    if not check_all_deps(args.mode):
        red("\nنصّب المكتبات الناقصة ثم اعد المحاولة")
        yellow("الأمر: pip install -r requirements.txt")
        sys.exit(1)

    if not check_token():
        sys.exit(1)

    check_admin_id()

    # Check for conflict
    running, _ = check_running_bot()
    if running:
        yellow("في bot ثاني شغّال بنفس الـ token!")
        yellow("أوقفه أولاً")

    print()
    cyan("═══════════════════════════════════════════════")

    if args.mode == "check":
        green("\n✅ كل شي تمام! شغّل --mode=minimal للتجربة")
        return

    if args.mode == "minimal":
        sys.exit(run_minimal())
    elif args.mode == "full":
        sys.exit(run_full())
    elif args.mode == "webhook":
        cyan("Webhook mode يحتاج HTTPS server. راجع docs/setup.md")
        return


if __name__ == "__main__":
    main()
