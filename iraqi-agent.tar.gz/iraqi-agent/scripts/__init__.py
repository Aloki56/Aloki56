"""CLI scripts package."""
