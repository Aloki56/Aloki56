"""
memory/manager.py
The MemoryManager composes all four memory tiers and is the only
object the rest of the app talks to.
"""
from __future__ import annotations
import asyncio
import time
from typing import Dict, List, Optional
from loguru import logger

from .short_term import get_stm
from .long_term import get_ltm, CustomerFact
from .conversation import get_cm, ConversationMessage
from .customer import get_cust, CustomerProfile


class MemoryManager:
    """One-stop facade for all memory tiers."""

    def __init__(self):
        self.stm = get_stm()
        self.ltm = get_ltm()
        self.cm  = get_cm()
        self.cust = get_cust()

    # ---------- Conversation flow ----------
    def record_turn(
        self,
        tenant_id: str,
        channel: str,
        user_id: str,
        user_text: str,
        assistant_text: str,
        intent: List[str] = None,
        provider: str = None,
        latency_ms: int = 0,
    ):
        # 1) Short-term (rolling buffer for the LLM)
        self.stm.append(tenant_id, channel, user_id, "user", user_text)
        self.stm.append(tenant_id, channel, user_id, "assistant", assistant_text)
        # 2) Full conversation archive
        self.cm.add(ConversationMessage(
            role="user", content=user_text, channel=channel, user_id=user_id,
            tenant_id=tenant_id,
        ))
        self.cm.add(ConversationMessage(
            role="assistant", content=assistant_text, channel=channel, user_id=user_id,
            tenant_id=tenant_id, intent=intent or [], provider=provider, latency_ms=latency_ms,
        ))
        # 3) Customer profile update
        self.cust.get_or_create(tenant_id, channel, user_id)

    def context_for_llm(self, tenant_id: str, channel: str, user_id: str) -> List[dict]:
        """Returns the rolling messages to feed the LLM."""
        # Short-term rolling buffer
        msgs = self.stm.get(tenant_id, channel, user_id)
        # Enrich with long-term facts (as a system-level addendum is added separately)
        return msgs

    def long_term_facts(self, tenant_id: str, user_id: str) -> str:
        return self.ltm.to_prompt(tenant_id, user_id)

    def customer_profile(self, tenant_id: str, channel: str, user_id: str) -> CustomerProfile:
        return self.cust.get_or_create(tenant_id, channel, user_id)

    def upsert_fact(self, tenant_id: str, user_id: str, key: str, value: str, confidence: float = 1.0, source: str = None):
        self.ltm.upsert(CustomerFact(
            tenant_id=tenant_id, user_id=user_id, key=key, value=value,
            confidence=confidence, source_msg_id=source,
        ))

    # ---------- Admin / analytics ----------
    def search_conversations(self, tenant_id: str, query: str, limit: int = 20):
        return self.cm.search(tenant_id, query, limit)

    def list_customers(self, tenant_id: str, limit: int = 100):
        return self.cust.list_for_tenant(tenant_id, limit)

    def stats(self) -> dict:
        return {
            **self.stm.stats(),
            **self.ltm.stats(),
            **self.cm.stats(),
            **self.cust.stats(),
        }


_mm: Optional[MemoryManager] = None
def get_memory_manager() -> MemoryManager:
    global _mm
    if _mm is None:
        _mm = MemoryManager()
    return _mm
