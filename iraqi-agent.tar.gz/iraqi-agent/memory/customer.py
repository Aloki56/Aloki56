"""
memory/customer.py
Customer profile: name, phone, email, channel IDs across all
platforms, total spend, lifetime value, last interaction.

Persists to PostgreSQL (or TinyDB in dev). One profile per
(tenant_id, canonical_user_id). Different channels for the same
human get linked when they share identifying info.
"""
from __future__ import annotations
import time
from typing import Dict, Optional, List
from pydantic import BaseModel, Field
from loguru import logger


class CustomerProfile(BaseModel):
    tenant_id: str
    user_id: str               # canonical id (per channel, then merged)
    canonical_id: str          # group id across channels
    name: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    channel_ids: Dict[str, str] = Field(default_factory=dict)
    # channel -> user_id on that channel
    # e.g. {"whatsapp": "96477xxx", "instagram": "17841234"}
    tags: List[str] = []
    notes: str = ""
    total_messages: int = 0
    first_seen: float = Field(default_factory=time.time)
    last_seen: float = Field(default_factory=time.time)
    total_orders: int = 0
    total_spend_iqd: int = 0
    opted_in_marketing: bool = False


class CustomerMemory:
    def __init__(self):
        # key: (tenant_id, user_id) -> CustomerProfile
        self._store: Dict[tuple, CustomerProfile] = {}

    def get_or_create(self, tenant_id: str, channel: str, user_id: str) -> CustomerProfile:
        k = (tenant_id, user_id)
        p = self._store.get(k)
        if not p:
            p = CustomerProfile(tenant_id=tenant_id, user_id=user_id, canonical_id=user_id)
            self._store[k] = p
        if channel and channel not in p.channel_ids:
            p.channel_ids[channel] = user_id
        p.last_seen = time.time()
        p.total_messages += 1
        return p

    def update(self, tenant_id: str, user_id: str, **kwargs):
        p = self.get_or_create(tenant_id, "", user_id)
        for k, v in kwargs.items():
            if hasattr(p, k) and v is not None:
                setattr(p, k, v)

    def list_for_tenant(self, tenant_id: str, limit: int = 100) -> List[CustomerProfile]:
        out = [p for (t, _), p in self._store.items() if t == tenant_id]
        out.sort(key=lambda p: p.last_seen, reverse=True)
        return out[:limit]

    def add_tag(self, tenant_id: str, user_id: str, tag: str):
        p = self.get_or_create(tenant_id, "", user_id)
        if tag not in p.tags:
            p.tags.append(tag)

    def stats(self) -> dict:
        return {
            "customer_profiles": len(self._store),
        }


_cust: Optional[CustomerMemory] = None
def get_cust() -> CustomerMemory:
    global _cust
    if _cust is None:
        _cust = CustomerMemory()
    return _cust
