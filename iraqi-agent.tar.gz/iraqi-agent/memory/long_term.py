"""
memory/long_term.py
Long-term memory: facts, preferences, and behaviors learned about
each customer across sessions. Persisted to PostgreSQL.

Stored as key/value records with a confidence score and a source
trace (which conversation the fact was learned from).

A periodic extractor scans recent conversations and writes new
facts via LLM (see scripts/extract_facts.py).
"""
from __future__ import annotations
import json
import time
from typing import Dict, List, Optional, Any
from pydantic import BaseModel, Field
from loguru import logger


class CustomerFact(BaseModel):
    tenant_id: str
    user_id: str
    key: str              # e.g. "favorite_dish", "spice_preference", "phone"
    value: str
    confidence: float = 1.0
    source_msg_id: Optional[str] = None
    created_at: float = Field(default_factory=time.time)
    updated_at: float = Field(default_factory=time.time)


class LongTermMemory:
    """
    In-process storage with optional Redis backend.
    For production with PostgreSQL, see db/models.py + the
    CustomerFactDB model.
    """

    def __init__(self):
        # key: (tenant_id, user_id, fact_key) -> CustomerFact
        self._store: Dict[tuple, CustomerFact] = {}

    def upsert(self, fact: CustomerFact):
        key = (fact.tenant_id, fact.user_id, fact.key)
        existing = self._store.get(key)
        if existing:
            existing.value = fact.value
            existing.confidence = fact.confidence
            existing.updated_at = time.time()
        else:
            self._store[key] = fact

    def get(self, tenant_id: str, user_id: str, key: str) -> Optional[CustomerFact]:
        return self._store.get((tenant_id, user_id, key))

    def list_for_user(self, tenant_id: str, user_id: str) -> List[CustomerFact]:
        return [f for (t, u, _), f in self._store.items() if t == tenant_id and u == user_id]

    def delete(self, tenant_id: str, user_id: str, key: str):
        self._store.pop((tenant_id, user_id, key), None)

    def to_prompt(self, tenant_id: str, user_id: str) -> str:
        facts = self.list_for_user(tenant_id, user_id)
        if not facts:
            return ""
        lines = ["## ما نعرفه عن هذا الزبون:"]
        for f in facts:
            lines.append(f"- {f.key}: {f.value} (ثقة: {f.confidence:.0%})")
        return "\n".join(lines)

    def stats(self) -> dict:
        return {
            "long_term_facts": len(self._store),
            "unique_customers": len({(t, u) for (t, u, _) in self._store}),
        }


_ltm: Optional[LongTermMemory] = None
def get_ltm() -> LongTermMemory:
    global _ltm
    if _ltm is None:
        _ltm = LongTermMemory()
    return _ltm
