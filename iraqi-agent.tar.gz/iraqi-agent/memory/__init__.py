"""
memory/__init__.py
Multi-tier memory system:
  - ShortTermMemory: per-conversation rolling buffer
  - LongTermMemory: persistent facts about users
  - ConversationMemory: full conversation history
  - CustomerMemory: cross-session profile per customer

Backed by:
  - In-process dicts for short term (TTL-based)
  - Redis for fast persistent
  - PostgreSQL (via SQLAlchemy) for long-term durable storage
"""
from .short_term import ShortTermMemory
from .long_term import LongTermMemory
from .conversation import ConversationMemory
from .customer import CustomerMemory
from .manager import MemoryManager

__all__ = [
    "ShortTermMemory", "LongTermMemory",
    "ConversationMemory", "CustomerMemory", "MemoryManager",
]
