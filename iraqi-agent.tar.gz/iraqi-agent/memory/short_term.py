"""
memory/short_term.py
Short-term conversation buffer per (tenant, channel, user).
Keeps the last N messages to feed the LLM. TTL 1 hour.
"""
from __future__ import annotations
import time
from collections import deque
from typing import Dict, Deque, List, Tuple, Optional
from threading import Lock


class ShortTermMemory:
    def __init__(self, max_turns: int = 12, ttl_seconds: int = 3600):
        self.max_turns = max_turns
        self.ttl = ttl_seconds
        self._store: Dict[Tuple[str, str, str], Deque[dict]] = {}
        self._last_touch: Dict[Tuple[str, str, str], float] = {}
        self._lock = Lock()

    def _key(self, tenant_id: str, channel: str, user_id: str):
        return (tenant_id, channel, user_id)

    def _gc(self):
        now = time.time()
        expired = [k for k, t in self._last_touch.items() if now - t > self.ttl]
        for k in expired:
            self._store.pop(k, None)
            self._last_touch.pop(k, None)

    def get(self, tenant_id: str, channel: str, user_id: str) -> List[dict]:
        with self._lock:
            self._gc()
            buf = self._store.get(self._key(tenant_id, channel, user_id))
            if not buf:
                return []
            return [{"role": m["role"], "content": m["content"]} for m in buf]

    def append(self, tenant_id: str, channel: str, user_id: str, role: str, content: str):
        with self._lock:
            k = self._key(tenant_id, channel, user_id)
            buf = self._store.setdefault(k, deque(maxlen=self.max_turns))
            buf.append({"role": role, "content": content, "ts": time.time()})
            self._last_touch[k] = time.time()

    def clear(self, tenant_id: str, channel: str, user_id: str):
        with self._lock:
            self._store.pop(self._key(tenant_id, channel, user_id), None)
            self._last_touch.pop(self._key(tenant_id, channel, user_id), None)

    def stats(self) -> dict:
        with self._lock:
            return {
                "short_term_conversations": len(self._store),
                "short_term_messages": sum(len(b) for b in self._store.values()),
            }


_stm: Optional[ShortTermMemory] = None
def get_stm() -> ShortTermMemory:
    global _stm
    if _stm is None:
        _stm = ShortTermMemory()
    return _stm
