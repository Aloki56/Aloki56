"""
memory/conversation.py
Full conversation history per (tenant, channel, user) — older
messages archived in PostgreSQL, recent ones in Redis / in-process.
"""
from __future__ import annotations
import time
from typing import Dict, List, Optional
from threading import Lock
from pydantic import BaseModel, Field


class ConversationMessage(BaseModel):
    role: str           # user | assistant | system
    content: str
    ts: float = Field(default_factory=time.time)
    intent: List[str] = []
    provider: Optional[str] = None
    latency_ms: int = 0
    channel: str = ""
    user_id: str = ""
    tenant_id: str = ""


class ConversationMemory:
    def __init__(self, keep_recent: int = 200):
        self.keep_recent = keep_recent
        # key: (tenant, channel, user) -> deque[ConversationMessage]
        self._recent: Dict[tuple, list] = {}
        self._lock = Lock()

    def add(self, msg: ConversationMessage):
        with self._lock:
            k = (msg.tenant_id, msg.channel, msg.user_id)
            buf = self._recent.setdefault(k, [])
            buf.append(msg)
            if len(buf) > self.keep_recent:
                # archive the older ones to DB (caller's job) and trim
                del buf[: len(buf) - self.keep_recent]

    def list_recent(self, tenant_id: str, channel: str, user_id: str, limit: int = 50) -> List[ConversationMessage]:
        with self._lock:
            buf = self._recent.get((tenant_id, channel, user_id), [])
            return list(buf)[-limit:]

    def search(self, tenant_id: str, query: str, limit: int = 20) -> List[ConversationMessage]:
        q = (query or "").lower()
        out: List[ConversationMessage] = []
        with self._lock:
            for (t, _, _), buf in self._recent.items():
                if t != tenant_id:
                    continue
                for m in buf:
                    if q in m.content.lower():
                        out.append(m)
        return out[-limit:]

    def stats(self) -> dict:
        with self._lock:
            return {
                "conversation_threads": len(self._recent),
                "total_messages": sum(len(b) for b in self._recent.values()),
            }


_cm: Optional[ConversationMemory] = None
def get_cm() -> ConversationMemory:
    global _cm
    if _cm is None:
        _cm = ConversationMemory()
    return _cm
