"""
core/models.py
Free-tier LLM orchestration with automatic fallback.

Strategy: every request goes through a prioritized list of providers
(Groq → Google → OpenRouter → Together → HF). If the primary returns
a rate-limit, timeout, or any non-recoverable error, we instantly
retry on the next provider. The caller never sees a 500 unless ALL
providers are down.

All providers expose a simple `chat(messages, **kwargs) -> str` interface
so swapping them in/out is trivial.
"""
from __future__ import annotations
import asyncio
import time
from typing import List, Dict, Optional, Any
import httpx
from loguru import logger

from core.config import get_settings


# ====================================================================
# Provider interface
# ====================================================================
class LLMProvider:
    name: str = "base"
    timeout: float = 30.0

    async def chat(self, messages: List[Dict[str, str]], **kwargs) -> str:
        raise NotImplementedError

    async def health(self) -> bool:
        return True


# ---------- Groq (OpenAI-compatible, very fast) ----------
class GroqProvider(LLMProvider):
    name = "groq"

    def __init__(self, api_key: str, model: str):
        self.api_key = api_key
        self.model = model
        self.url = "https://api.groq.com/openai/v1/chat/completions"

    async def chat(self, messages, **kwargs) -> str:
        async with httpx.AsyncClient(timeout=self.timeout) as c:
            r = await c.post(
                self.url,
                headers={"Authorization": f"Bearer {self.api_key}"},
                json={
                    "model": self.model,
                    "messages": messages,
                    "temperature": kwargs.get("temperature", 0.7),
                    "max_tokens": kwargs.get("max_tokens", 512),
                },
            )
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"]


# ---------- Google AI Studio (Gemini) ----------
class GoogleProvider(LLMProvider):
    name = "google"

    def __init__(self, api_key: str, model: str):
        self.api_key = api_key
        self.model = model
        # gemini-1.5-flash etc
        self.url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"

    def _convert_messages(self, messages):
        # Gemini wants "contents" with role user/model
        out = []
        sys_prompt = None
        for m in messages:
            if m["role"] == "system":
                sys_prompt = (sys_prompt + "\n\n" if sys_prompt else "") + m["content"]
            elif m["role"] == "user":
                out.append({"role": "user", "parts": [{"text": m["content"]}]})
            elif m["role"] == "assistant":
                out.append({"role": "model", "parts": [{"text": m["content"]}]})
        if sys_prompt:
            out.insert(0, {"role": "user", "parts": [{"text": f"[SYSTEM]\n{sys_prompt}"}]})
            out.insert(1, {"role": "model", "parts": [{"text": "فهمت، جاهز."}]})
        return out

    async def chat(self, messages, **kwargs) -> str:
        body = {
            "contents": self._convert_messages(messages),
            "generationConfig": {
                "temperature": kwargs.get("temperature", 0.7),
                "maxOutputTokens": kwargs.get("max_tokens", 512),
            },
        }
        async with httpx.AsyncClient(timeout=self.timeout) as c:
            r = await c.post(
                f"{self.url}?key={self.api_key}",
                json=body,
            )
            r.raise_for_status()
            data = r.json()
            return data["candidates"][0]["content"]["parts"][0]["text"]


# ---------- OpenRouter (OpenAI-compatible) ----------
class OpenRouterProvider(LLMProvider):
    name = "openrouter"

    def __init__(self, api_key: str, model: str):
        self.api_key = api_key
        self.model = model
        self.url = "https://openrouter.ai/api/v1/chat/completions"

    async def chat(self, messages, **kwargs) -> str:
        async with httpx.AsyncClient(timeout=self.timeout) as c:
            r = await c.post(
                self.url,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "HTTP-Referer": "https://iraqi-agent.local",
                    "X-Title": "Iraqi Agent",
                },
                json={
                    "model": self.model,
                    "messages": messages,
                    "temperature": kwargs.get("temperature", 0.7),
                    "max_tokens": kwargs.get("max_tokens", 512),
                },
            )
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"]


# ---------- Together.ai (OpenAI-compatible) ----------
class TogetherProvider(LLMProvider):
    name = "together"

    def __init__(self, api_key: str, model: str):
        self.api_key = api_key
        self.model = model
        self.url = "https://api.together.xyz/v1/chat/completions"

    async def chat(self, messages, **kwargs) -> str:
        async with httpx.AsyncClient(timeout=self.timeout) as c:
            r = await c.post(
                self.url,
                headers={"Authorization": f"Bearer {self.api_key}"},
                json={
                    "model": self.model,
                    "messages": messages,
                    "temperature": kwargs.get("temperature", 0.7),
                    "max_tokens": kwargs.get("max_tokens", 512),
                },
            )
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"]


# ---------- HuggingFace Inference API ----------
class HFProvider(LLMProvider):
    name = "hf"

    def __init__(self, api_key: str, model: str):
        self.api_key = api_key
        self.model = model
        self.url = f"https://api-inference.huggingface.co/models/{model}"

    async def chat(self, messages, **kwargs) -> str:
        # Naive concatenation for HF inference (it doesn't have chat API by default)
        prompt = ""
        for m in messages:
            if m["role"] == "system":
                prompt += f"[INST] {m['content']} [/INST]\n"
            elif m["role"] == "user":
                prompt += f"[INST] {m['content']} [/INST]\n"
            elif m["role"] == "assistant":
                prompt += f" {m['content']}\n"
        async with httpx.AsyncClient(timeout=self.timeout) as c:
            r = await c.post(
                self.url,
                headers={"Authorization": f"Bearer {self.api_key}"},
                json={
                    "inputs": prompt,
                    "parameters": {
                        "max_new_tokens": kwargs.get("max_tokens", 512),
                        "temperature": kwargs.get("temperature", 0.7),
                        "return_full_text": False,
                    },
                },
            )
            r.raise_for_status()
            data = r.json()
            if isinstance(data, list) and data:
                return data[0].get("generated_text", "").strip()
            return data.get("generated_text", "").strip()


# ====================================================================
# Fallback orchestrator
# ====================================================================
class ModelRouter:
    def __init__(self):
        s = get_settings()
        self.providers: List[LLMProvider] = []
        if s.groq_api_key:
            self.providers.append(GroqProvider(s.groq_api_key, s.groq_model))
        if s.google_api_key:
            self.providers.append(GoogleProvider(s.google_api_key, s.google_model))
        if s.openrouter_api_key:
            self.providers.append(OpenRouterProvider(s.openrouter_api_key, s.openrouter_model))
        if s.together_api_key:
            self.providers.append(TogetherProvider(s.together_api_key, s.together_model))
        if s.hf_api_key:
            self.providers.append(HFProvider(s.hf_api_key, s.hf_model))

        if not self.providers:
            logger.warning("⚠️  No LLM provider configured! Add at least one API key to .env")
        else:
            logger.info(f"✅ Loaded {len(self.providers)} LLM providers: "
                        f"{[p.name for p in self.providers]}")

    async def chat(
        self,
        messages: List[Dict[str, str]],
        **kwargs,
    ) -> Dict[str, Any]:
        """Try providers in order until one succeeds.

        Returns: {"text": str, "provider": str, "latency_ms": int, "fallbacks": int}
        """
        if not self.providers:
            raise RuntimeError("No LLM provider is configured. Fill in at least one API key in .env")

        fallbacks = 0
        last_error: Optional[Exception] = None
        for provider in self.providers:
            t0 = time.time()
            try:
                text = await provider.chat(messages, **kwargs)
                latency = int((time.time() - t0) * 1000)
                if fallbacks > 0:
                    logger.warning(f"🔁 Fell back to {provider.name} after {fallbacks} failures")
                return {
                    "text": text,
                    "provider": provider.name,
                    "latency_ms": latency,
                    "fallbacks": fallbacks,
                }
            except Exception as e:
                fallbacks += 1
                last_error = e
                logger.warning(f"❌ Provider {provider.name} failed: {e!r}")
                continue

        # All failed
        raise RuntimeError(f"All LLM providers failed. Last error: {last_error!r}")


# Singleton
_router: Optional[ModelRouter] = None

def get_router() -> ModelRouter:
    global _router
    if _router is None:
        _router = ModelRouter()
    return _router
