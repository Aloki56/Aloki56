"""
core/config.py
Centralized configuration loader.
Uses pydantic-settings so all env vars validate on startup.
"""
from __future__ import annotations
from typing import List, Optional
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field
from functools import lru_cache


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ---- App ----
    app_env: str = "production"
    app_port: int = 8000
    app_host: str = "0.0.0.0"
    app_secret: str = "change-me"
    admin_telegram_id: int = 0
    admin_telegram_ids: str = ""   # comma-separated, e.g. "123,456,789"

    # ---- Storage ----
    storage_backend: str = "tinydb"
    tinydb_path: str = "./data/tenants.json"
    database_url: Optional[str] = None

    # ---- LLM Providers (free) ----
    groq_api_key: Optional[str] = None
    groq_model: str = "llama-3.3-70b-versatile"

    google_api_key: Optional[str] = None
    google_model: str = "gemini-1.5-flash"

    openrouter_api_key: Optional[str] = None
    openrouter_model: str = "meta-llama/llama-3.1-70b-instruct:free"

    together_api_key: Optional[str] = None
    together_model: str = "meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo"

    hf_api_key: Optional[str] = None
    hf_model: str = "meta-llama/Meta-Llama-3-8B-Instruct"

    # ---- Telegram ----
    telegram_bot_token: Optional[str] = None

    # ---- WhatsApp Bridge ----
    wa_bridge_url: str = "ws://localhost:3001"
    wa_bridge_http: str = "http://localhost:3001"
    wa_bridge_auth: str = "change-me"

    # ---- Meta / Instagram ----
    meta_app_id: Optional[str] = None
    meta_app_secret: Optional[str] = None
    meta_verify_token: str = "iraqi-agent-verify"

    # ---- TikTok ----
    tiktok_enabled: bool = False

    # ---- Failover ----
    backup_instance_url: Optional[str] = None
    health_check_interval: int = 60
    ping_url: Optional[str] = None

    # ---- Logging ----
    log_level: str = "INFO"
    log_file: str = "./logs/agent.log"

    # ---- Helpers ----
    def enabled_providers(self) -> List[str]:
        """Return names of providers that have an API key, in priority order."""
        out = []
        if self.groq_api_key:
            out.append("groq")
        if self.google_api_key:
            out.append("google")
        if self.openrouter_api_key:
            out.append("openrouter")
        if self.together_api_key:
            out.append("together")
        if self.hf_api_key:
            out.append("hf")
        return out


@lru_cache
def get_settings() -> Settings:
    return Settings()
