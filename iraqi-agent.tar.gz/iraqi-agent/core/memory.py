"""
core/memory.py
Per-user, per-tenant conversation memory. Cheap, in-process,
but pluggable — swap for Redis/Postgres when you scale.

Stores the last N turns of each (tenant_id, user_id) pair so the
agent can keep context across multi-turn conversations.
"""
from __future__ import annotations
import time
import asyncio
from collections import deque
from typing import Dict, Deque, List, Tuple
from threading import Lock


class ConversationMemory:
    def __init__(self, max_turns: int = 12):
        self.max_turns = max_turns
        # key: (tenant_id, channel, user_id) -> deque[dict]
        self._store: Dict[Tuple[str, str, str], Deque[dict]] = {}
        self._lock = Lock()
        # TTL in seconds — after this we wipe the buffer
        self._ttl = 60 * 60 * 6  # 6 hours

    def _key(self, tenant_id: str, channel: str, user_id: str):
        return (tenant_id, channel, user_id)

    def get(self, tenant_id: str, channel: str, user_id: str) -> List[dict]:
        with self._lock:
            buf = self._store.get(self._key(tenant_id, channel, user_id))
            if not buf:
                return []
            # TTL check
            if buf and (time.time() - buf[0].get("_ts", 0)) > self._ttl:
                self._store.pop(self._key(tenant_id, channel, user_id), None)
                return []
            return [{"role": m["role"], "content": m["content"]} for m in buf]

    def append(self, tenant_id: str, channel: str, user_id: str, role: str, content: str):
        with self._lock:
            key = self._key(tenant_id, channel, user_id)
            buf = self._store.setdefault(key, deque(maxlen=self.max_turns))
            buf.append({"role": role, "content": content, "_ts": time.time()})

    def clear(self, tenant_id: str, channel: str, user_id: str):
        with self._lock:
            self._store.pop(self._key(tenant_id, channel, user_id), None)

    def stats(self) -> dict:
        with self._lock:
            return {
                "active_conversations": len(self._store),
                "total_turns": sum(len(b) for b in self._store.values()),
            }


_memory: ConversationMemory | None = None

def get_memory() -> ConversationMemory:
    global _memory
    if _memory is None:
        _memory = ConversationMemory()
    return _memory
