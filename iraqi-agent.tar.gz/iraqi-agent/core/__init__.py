"""Core package: agent, models, prompts, memory, config."""
