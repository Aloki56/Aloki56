"""
core/iraqi.py
Iraqi Arabic dialect utilities — normalization, slang dictionary,
greetings, and a few helpers so the agent speaks *real* Iraqi,
not Modern Standard Arabic dressed up.
"""
from __future__ import annotations
import re
from typing import Dict, List

# ------------------------------------------------------------------
# 1.  Common Iraqi expressions used in restaurants / cafes / shops
# ------------------------------------------------------------------
IRAQI_GREETINGS = [
    "هلا والله", "هلا بيك", "هلا بيك خيو", "هلا بيج خيتو",
    "هلا بكم", "أهلين", "شخبارك", "شخباركم", "شلونك", "شلونج",
    "حياكم", "نورتونا", "نورتني",
]

IRAQI_FILLERS = [
    "هسه", "بعدين", "يلا", "خلص", "زين", "خوش", "هواية",
    "تمام", "أوكي", "ماشي", "حچي", "چان", "شكو ماكو",
    "عيني", "حبيبي", "حبيبتي", "خيو", "خيتو", "يابه", "يا هلا",
]

IRAQI_AFFIRMATIVE = ["إي", "إي والله", "زين", "تمام", "أكيد", "بالتأكيد", "أوكي", "ماشي"]
IRAQI_NEGATIVE    = ["لأ", "لأ كلا", "كلا", "ما أريد", "لا شكرا"]

# Frequently used in restaurants:
IRAQI_FOOD_HINTS = {
    "كباب": ["كباب", "كباب عراقي", "كباب تكا", "كباب مشوي"],
    "برياني": ["برياني دجاج", "برياني لحم", "برياني سمك"],
    "دجاج": ["دجاج", "فراخ", "دجاج مشوي", "دجاج مقلي"],
    "سمك": ["سمك", "صيادية", "مسكوف", "هواية سمك"],
    "مشروبات": ["شاي", "قهوة", "عصير", "موهيتو", "سموذي", "كولد برو"],
    "حلويات": ["كنافة", "بسبوسة", "زلابية", "مهلبية", "بقلاوة"],
}

# ------------------------------------------------------------------
# 2.  Normalization — turn colloquial Iraqi into something
#     every LLM understands, while keeping flavour.
# ------------------------------------------------------------------
_NORMALIZE_MAP: Dict[str, str] = {
    # چ (Iraqi ch) → ك (so MSAs can also understand)
    "چ": "ك", "گ": "ك", "پ": "ب",
    # Pronouns / particles
    "هسه": "الآن",
    "هواية": "كثير",
    "خوش": "جيد",
    "يابه": "يالله",
    "عيني": "يا عيني",
    "خيو": "أخوي",
    "خيتو": "أختي",
    "حچي": "كلام",
    "أكولج": "أكل",
    "ماكو": "لا يوجد",
    "أكو": "يوجد",
    "ما أريد": "لا أريد",
    "أريد": "أبي",
    "أبي": "أريد",
    "شلون": "كيف",
    "ليش": "لماذا",
    "وين": "أين",
    "شكو": "ماذا",
    "ماكو": "لا يوجد",
    "كلش": "جداً",
    "زحمة": "ازدحام",
    "دز": "أرسل",
    "دگ": "أعطني",
    "بگ": "لك",
    "أگول": "أقول",
    "گال": "قال",
    "گالت": "قالت",
}

def normalize_iraqi(text: str) -> str:
    """Light-touch normalization for the LLM context window."""
    out = text
    for k, v in _NORMALIZE_MAP.items():
        out = out.replace(k, v)
    return re.sub(r"\s+", " ", out).strip()


def add_iraqi_flavor(text: str) -> str:
    """Inject a tiny bit of Iraqi flavor if the LLM answered in MSA.
    This is best-effort — most modern models already speak Iraqi when
    prompted properly."""
    if not text:
        return text
    # If the answer is *too* formal and missing any Iraqi marker, prepend one
    iraqi_markers = ["هلا", "خوش", "زين", "عيني", "خيو", "خيتو", "هسه", "يلا", "أكيد", "بالتأكيد"]
    if not any(m in text for m in iraqi_markers) and len(text) < 200:
        return f"خيو، {text}"
    return text


# ------------------------------------------------------------------
# 3.  Intent detection helpers (cheap regex pre-classification
#     so the LLM only has to fill in the answer, not decide).
# ------------------------------------------------------------------
INTENT_PATTERNS = {
    "greeting":   r"(هلا|سلام|شلونك|شلونج|شخبار|صباح|مساء)",
    "menu":       r"(منيو|قائمة|اكل|أكل|عندكم|شنو عندكم|ايش عندكم|شو عندكم)",
    "order":      r"(أبي|أريد|اطلب|أطلب|ابغى|أبغى|دز|order)",
    "price":      r"(بكم|كم سعر|كم الثمن|سعر|كلفة|كلف)",
    "location":   r"(وين|أين|عنوان|موقع|فين)",
    "hours":      r"(دوام|موعد|ساعات|متى|امتى|متى تفتحون|تفتحون)",
    "delivery":   r"(ديليفري|توصيل|يوصل|ديليفري)",
    "reservation":r"(حجز|حجزت|احجز|أحجز|طاولة|موعد)",
    "complaint":  r"(شكوى|مشكلة|تأخر|بارد|ما طاب|سيء|سيئة|خربان|خربانة)",
    "bye":        r"(باي|مع السلامة|وداع|باي باي|الى اللقاء)",
    "thanks":     r"(شكرا|شكراً|مشكور|مشكورة|تسلم|يسلمو|يعطيك العافية)",
}

def detect_intent(text: str) -> List[str]:
    """Return a list of intents found in `text`."""
    text_norm = text
    found = []
    for intent, pattern in INTENT_PATTERNS.items():
        if re.search(pattern, text_norm):
            found.append(intent)
    return found
