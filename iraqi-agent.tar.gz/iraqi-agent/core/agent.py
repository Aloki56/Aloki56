"""
core/agent.py
The main agent orchestration. This is what the channel adapters
and the Telegram bot call.

For every incoming message it:
  1. Loads the tenant config (system prompt, business info, KB).
  2. Pulls the rolling conversation memory.
  3. Pre-classifies intent (cheap regex) for routing / metrics.
  4. Calls the LLM router (with fallback).
  5. Post-processes the reply (Iraqi flavor, length cap, safety).
  6. Stores the turn in memory.
  7. Returns the final text + metadata.
"""
from __future__ import annotations
import asyncio
import time
from typing import Dict, Any, List, Optional
from loguru import logger

from core.config import get_settings
from core.models import get_router
from core.memory import get_memory
from core.prompts import build_system_prompt, FEW_SHOTS
from core.iraqi import detect_intent, add_iraqi_flavor, normalize_iraqi


# Per-channel & per-tenant concurrency limits (to keep free tiers happy)
_TENANT_SEMAPHORES: Dict[str, asyncio.Semaphore] = {}
_TENANT_LOCK = asyncio.Lock()

async def _semaphore_for(tenant_id: str) -> asyncio.Semaphore:
    if tenant_id not in _TENANT_SEMAPHORES:
        async with _TENANT_LOCK:
            if tenant_id not in _TENANT_SEMAPHORES:
                _TENANT_SEMAPHORES[tenant_id] = asyncio.Semaphore(3)
    return _TENANT_SEMAPHORES[tenant_id]


class Agent:
    """The Iraqi-dialect business agent."""

    def __init__(self):
        self.router = get_router()
        self.memory = get_memory()

    # ---- Public API ----
    async def reply(
        self,
        tenant: dict,
        channel: str,
        user_id: str,
        user_message: str,
        user_name: Optional[str] = None,
        image_url: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Generate a reply for one incoming message.

        Returns:
            {"text": str, "intent": list[str], "provider": str,
             "latency_ms": int, "fallbacks": int}
        """
        sem = await _semaphore_for(tenant["tenant_id"])
        async with sem:
            return await self._reply_locked(
                tenant, channel, user_id, user_message, user_name, image_url
            )

    # ---- Internals ----
    async def _reply_locked(self, tenant, channel, user_id, user_message, user_name, image_url):
        tenant_id = tenant["tenant_id"]
        t0 = time.time()

        # 1. Build system prompt
        system_prompt = build_system_prompt(tenant)

        # 2. Pull memory
        history = self.memory.get(tenant_id, channel, user_id)

        # 3. Compose the messages array
        messages: List[Dict[str, str]] = [{"role": "system", "content": system_prompt}]
        # Add few-shot examples ONCE per conversation
        if not history:
            messages.extend(FEW_SHOTS)
        messages.extend(history)

        # 4. Normalize + enrich the user turn
        enriched = user_message
        if user_name:
            enriched = f"[اسم الزبون: {user_name}]\n{enriched}"
        if image_url:
            enriched += f"\n[مرفق صورة: {image_url}]"
        messages.append({"role": "user", "content": enriched})

        # 5. Detect intent (for routing/analytics — doesn't change prompt)
        intent = detect_intent(normalize_iraqi(user_message))

        # 6. Call the LLM
        try:
            result = await self.router.chat(messages, max_tokens=400, temperature=0.7)
        except Exception as e:
            logger.error(f"Agent failed for tenant={tenant_id}: {e!r}")
            return {
                "text": "عيني، صار عندي مشكلة فنية بسيطة. حاول مرة ثانية بعد دقيقة، وإذا ما زبط راح أوصّل الرسالة للمسؤول. 🙏",
                "intent": intent,
                "provider": None,
                "latency_ms": int((time.time() - t0) * 1000),
                "fallbacks": -1,
                "error": str(e),
            }

        # 7. Post-process: enforce Iraqi flavor + length cap
        text = add_iraqi_flavor(result["text"].strip())
        if len(text) > 800:
            text = text[:800].rsplit(" ", 1)[0] + "…"

        # 8. Persist to memory
        self.memory.append(tenant_id, channel, user_id, "user", user_message)
        self.memory.append(tenant_id, channel, user_id, "assistant", text)

        return {
            "text": text,
            "intent": intent,
            "provider": result["provider"],
            "latency_ms": result["latency_ms"],
            "fallbacks": result["fallbacks"],
            "total_ms": int((time.time() - t0) * 1000),
        }


# Singleton
_agent: Optional[Agent] = None
def get_agent() -> Agent:
    global _agent
    if _agent is None:
        _agent = Agent()
    return _agent
