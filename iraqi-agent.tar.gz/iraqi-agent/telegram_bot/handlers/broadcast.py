"""
telegram_bot/handlers/broadcast.py
Pluggable broadcast handler. The default Telegram broadcast command
just echoes; for production wire this to Meta's bulk-send endpoints.
"""
from __future__ import annotations
import asyncio
from typing import List
import httpx
from loguru import logger

from channels.manager import get_manager


async def broadcast_to_tenant(tenant_id: str, text: str) -> int:
    """Send a message to every known user of `tenant_id` across all
    active channels. Returns the number of successful sends.

    NOTE: This requires a per-channel "user_id list" which we don't
    yet persist. For now this is a stub; the real implementation
    should iterate over the conversations table.
    """
    # TODO: persist user_ids from inbound messages
    logger.warning("broadcast_to_tenant: no user list persisted yet — no-op")
    return 0
