"""
telegram_bot/handlers/auth.py
Improved authentication layer for the admin bot.

Features:
  - Multiple admin IDs supported (ADMIN_TELEGRAM_IDS=123,456,789)
  - First-user-becomes-admin bootstrap (if no admins configured)
  - /whoami command always works
  - Friendly deny message that tells the user EXACTLY what's wrong
  - Per-tenant admin roles (future)
"""
from __future__ import annotations
import time
from pathlib import Path
from typing import List, Optional, Set
from loguru import logger
from telegram import Update

from core.config import get_settings


# Persistent storage for the bootstrap "first admin" + custom roles
_ADMIN_STORE_PATH = Path("./data/admin_store.json")


def _load_admins() -> Set[int]:
    """Load extra admins from disk (the bootstrap-admin)."""
    if not _ADMIN_STORE_PATH.exists():
        return set()
    try:
        import json
        with open(_ADMIN_STORE_PATH, "r") as f:
            return set(json.load(f).get("admins", []))
    except Exception:
        return set()


def _save_admins(admins: Set[int]):
    try:
        _ADMIN_STORE_PATH.parent.mkdir(parents=True, exist_ok=True)
        import json
        with open(_ADMIN_STORE_PATH, "w") as f:
            json.dump({"admins": sorted(admins)}, f)
    except Exception as e:
        logger.error(f"Failed to save admin store: {e!r}")


def get_admin_ids() -> List[int]:
    """All admin Telegram IDs (from env + persistent store)."""
    s = get_settings()
    out: Set[int] = set()
    # 1) Single admin from env (legacy)
    if s.admin_telegram_id and s.admin_telegram_id != 0:
        out.add(int(s.admin_telegram_id))
    # 2) Multi-admin from env (new)
    raw = getattr(s, "admin_telegram_ids", "") or ""
    for piece in str(raw).split(","):
        piece = piece.strip()
        if piece.isdigit():
            out.add(int(piece))
    # 3) Bootstrap admins from disk
    out.update(_load_admins())
    return sorted(out)


def is_admin(update: Update) -> bool:
    if not update.effective_user:
        return False
    return int(update.effective_user.id) in get_admin_ids()


def bootstrap_admin_if_empty(update: Update) -> bool:
    """If no admins are configured anywhere, the FIRST user to message
    the bot becomes the admin. Returns True if this user was just promoted."""
    if get_admin_ids():
        return False
    if not update.effective_user:
        return False
    user_id = int(update.effective_user.id)
    # Check this user isn't already a "blocked" user (future feature)
    admins = _load_admins()
    admins.add(user_id)
    _save_admins(admins)
    logger.warning(f"🔐 BOOTSTRAP: {user_id} is now admin (first user)")
    return True


async def friendly_deny(update: Update):
    """Sends a helpful message when a non-admin tries to use the bot."""
    s = get_settings()
    user = update.effective_user
    if not user:
        return
    user_id = user.id
    user_name = user.first_name or "صديقي"
    is_supergroup = update.effective_chat and update.effective_chat.type in ("group", "supergroup")

    msg_lines = [
        f"⛔ *هلا {user_name}، هذا البوت خاص*",
        "",
        f"🆔 الـ ID تبعك: `{user_id}`",
    ]

    if is_supergroup:
        msg_lines += [
            "",
            "⚠️ أنت داخل مجموعة. البوت ما يشتغل بالمجموعات.",
            "ابعثله بالخاص (Direct Message).",
        ]
    else:
        if not get_admin_ids():
            # No admins configured — but first user just messaged
            # We auto-promote them; tell them they're now admin
            if bootstrap_admin_if_empty(update):
                msg_lines += [
                    "",
                    "🎉 *ماكو أي admin مسجّل! سويتها أنت الـ admin الأول.*",
                    "أعد الإرسال /start",
                ]
            else:
                msg_lines += [
                    "",
                    "❓ البوت ما عنده admin مسجّل. شغّله محلياً وراجع `.env`",
                ]
        else:
            msg_lines += [
                "",
                "أضف الـ ID أعلاه لـ `ADMIN_TELEGRAM_ID` بـ `.env`:",
                "```",
                f"ADMIN_TELEGRAM_ID={user_id}",
                "# أو متعددين:",
                f"ADMIN_TELEGRAM_IDS={','.join(str(x) for x in get_admin_ids())},{user_id}",
                "```",
                "وبعدين أعد تشغيل البوت.",
            ]

    # Use reply_text for messages, answer for callback queries
    cbq = getattr(update, "callback_query", None)
    if cbq:
        try:
            await cbq.answer("⛔ مو لك", show_alert=True)
        except Exception:
            pass
    msg = getattr(update, "message", None)
    if msg:
        await msg.reply_text("\n".join(msg_lines), parse_mode="Markdown")


# ----- Public: rate-limit per admin -----
_LAST_CMD: dict[int, float] = {}


def rate_limited(user_id: int, min_interval: float = 0.5) -> bool:
    """Returns True if user is sending commands too fast."""
    now = time.time()
    last = _LAST_CMD.get(user_id, 0)
    if now - last < min_interval:
        return True
    _LAST_CMD[user_id] = now
    return False
