"""
telegram_bot/handlers/whoami.py
Identity-related commands that work for ANY user (not just admins).
This way, anyone can find out their Telegram ID and request admin access.
"""
from __future__ import annotations
import time
from loguru import logger
from telegram import Update
from telegram.ext import ContextTypes

from core.config import get_settings
from telegram_bot.handlers.auth import is_admin, get_admin_ids, friendly_deny, _load_admins, _save_admins


async def cmd_whoami(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Always works. Tells the user their Telegram ID and admin status."""
    user = update.effective_user
    if not user or not update.message:
        return
    admins = get_admin_ids()
    is_admin_user = int(user.id) in admins
    is_bootstrap = not admins  # no admins at all

    msg = (
        f"👤 *بياناتك*\n\n"
        f"🆔 Telegram ID: `{user.id}`\n"
        f"📛 الاسم: {user.first_name or ''} {user.last_name or ''}\n"
        f"🔗 اليوزر: @{user.username or '—'}\n"
        f"🌐 اللغة: {user.language_code or '—'}\n\n"
    )
    if is_admin_user:
        msg += f"✅ أنت *admin*. عدد الأدمنز الكلي: {len(admins)}\n"
    elif is_bootstrap:
        msg += (
            f"⚠️ *ماكو أي admin مسجّل بالبوت!*\n\n"
            f"انت أول واحد بعث رسالة، فراح تصير admin تلقائياً لما ترسل أي أمر.\n"
            f"أو حط هذا الـ ID بـ `.env`:\n"
            f"```\nADMIN_TELEGRAM_ID={user.id}\n```"
        )
    else:
        msg += (
            f"⛔ أنت *مو admin*.\n"
            f"الـ admins الحاليين: `{','.join(str(x) for x in admins)}`\n\n"
            f"إذا تريد تصير admin، ابعث الـ ID تبعك (`{user.id}`) لمالك البوت."
        )
    await update.message.reply_text(msg, parse_mode="Markdown")


async def cmd_addadmin(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Add a Telegram ID as admin. Existing admins only."""
    if not is_admin(update):
        return await friendly_deny(update)
    if not ctx.args:
        return await update.message.reply_text("استعمل: /addadmin <telegram_id>")
    try:
        new_id = int(ctx.args[0])
    except ValueError:
        return await update.message.reply_text("❌ ID غير صالح. لازم يكون رقم.")
    admins = _load_admins()
    admins.add(new_id)
    _save_admins(admins)
    await update.message.reply_text(f"✅ تم إضافة {new_id} كـ admin\nالإجمالي: {len(get_admin_ids())}")


async def cmd_removeadmin(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    if not ctx.args:
        return await update.message.reply_text("استعمال: /removeadmin <telegram_id>")
    try:
        target = int(ctx.args[0])
    except ValueError:
        return await update.message.reply_text("❌ ID غير صالح")
    admins = _load_admins()
    admins.discard(target)
    _save_admins(admins)
    await update.message.reply_text(f"✅ تم إزالة {target} من admins\nالمتبقي: {len(get_admin_ids())}")


async def cmd_admins(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """List all admins."""
    if not is_admin(update):
        return await friendly_deny(update)
    admins = get_admin_ids()
    s = get_settings()
    sources = []
    if s.admin_telegram_id and s.admin_telegram_id != 0:
        sources.append(f"  من ADMIN_TELEGRAM_ID: {s.admin_telegram_id}")
    if getattr(s, "admin_telegram_ids", ""):
        sources.append(f"  من ADMIN_TELEGRAM_IDS: {s.admin_telegram_ids}")
    extras = _load_admins()
    if extras:
        sources.append(f"  من bootstrap (أول مستخدم): {sorted(extras)}")
    msg = (
        f"👑 *الأدمنز المسجّلين* ({len(admins)})\n\n"
        f"{chr(10).join(str(a) for a in admins) or 'لا يوجد!'}\n\n"
        f"المصادر:\n" + "\n".join(sources) if sources else "لا يوجد مصادر"
    )
    await update.message.reply_text(msg, parse_mode="Markdown")
