"""
telegram_bot/handlers/add_wizard.py
The interactive "add new tenant" wizard.
"""
from __future__ import annotations
from telegram import Update
from telegram.ext import ContextTypes, ConversationHandler, MessageHandler, CommandHandler, filters

from core.config import get_settings
from tenants.manager import create_tenant
from security.audit import get_audit


S_TENANT_ID, S_NAME, S_OWNER, S_PHONE, S_TYPE, S_ADDRESS, S_HOURS, S_FEE, S_KB = range(9)


def is_admin(update: Update) -> bool:
    return update.effective_user and update.effective_user.id == get_settings().admin_telegram_id


async def add_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update): return ConversationHandler.END
    await update.message.reply_text(
        "➕ *إضافة مشروع جديد*\n\n"
        "أرسل الـ ID (إنكليزي، بدون مسافات):\n"
        "مثال: `baghdad_kebab`\n\n"
        "/cancel للإلغاء",
        parse_mode="Markdown",
    )
    return S_TENANT_ID


async def add_tenant_id(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    tid = (update.message.text or "").strip().lower()
    if not tid.replace("_", "").replace("-", "").isalnum():
        return await update.message.reply_text("❌ ID غير صالح. حروف إنكليزية صغيرة وأرقام و _ -")
    from tenants.store import get_store
    if get_store().get(tid):
        return await update.message.reply_text("❌ هذا الـ ID موجود قبل. اختار غيره.")
    ctx.user_data["tid"] = tid
    await update.message.reply_text("تمام. شنو اسم المشروع؟")
    return S_NAME


async def add_name(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data["name"] = update.message.text.strip()
    await update.message.reply_text("اسم المالك؟")
    return S_OWNER


async def add_owner(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data["owner"] = update.message.text.strip()
    await update.message.reply_text("رقم هاتف المالك؟")
    return S_PHONE


async def add_phone(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data["phone"] = update.message.text.strip()
    await update.message.reply_text("نوع المشروع؟\nمثال: مطعم، كافيه، حلويات، بقالة، ملابس")
    return S_TYPE


async def add_type(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data["type"] = update.message.text.strip()
    await update.message.reply_text("العنوان؟ (أو /skip)")
    return S_ADDRESS


async def add_address(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if update.message.text.strip() != "/skip":
        ctx.user_data["address"] = update.message.text.strip()
    await update.message.reply_text("ساعات الدوام؟ (مثال: ١٠ ص - ١١ م)\nأو /skip")
    return S_HOURS


async def add_hours(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if update.message.text.strip() != "/skip":
        ctx.user_data["hours"] = update.message.text.strip()
    await update.message.reply_text("الاشتراك الشهري بالدينار؟\nمثال: 75000 (أو 0 للتجربة)")
    return S_FEE


async def add_fee(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    try:
        fee = int((update.message.text or "0").strip())
    except ValueError:
        return await update.message.reply_text("❌ رقم غير صحيح. ابعث رقم صحيح.")
    ctx.user_data["fee"] = fee
    await update.message.reply_text(
        "📚 قاعدة المعرفة (القائمة، الأسعار، العنوان...):\n"
        "ابعثها كلها، أو /skip لإضافة لاحقاً."
    )
    return S_KB


async def add_kb(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    kb = ""
    if update.message.text.strip() != "/skip":
        kb = update.message.text.strip()
    try:
        t = create_tenant(
            tenant_id=ctx.user_data["tid"],
            business_name=ctx.user_data["name"],
            owner_name=ctx.user_data["owner"],
            owner_phone=ctx.user_data["phone"],
            business_type=ctx.user_data.get("type", "مطعم"),
            address=ctx.user_data.get("address", ""),
            working_hours=ctx.user_data.get("hours", "يومياً ١٠ ص - ١١ م"),
            knowledge_base=kb,
            monthly_fee_iqd=ctx.user_data.get("fee", 75000),
        )
    except Exception as e:
        await update.message.reply_text(f"❌ فشل: {e}")
        return ConversationHandler.END

    # Activate trial subscription
    from billing.subscription import get_subscription_manager
    get_subscription_manager().set_tier(t.tenant_id, "trial", days=14)

    # Audit
    get_audit().log(
        actor=str(update.effective_user.id),
        action="tenant.create",
        target=t.tenant_id,
        details={"name": t.business_name},
    )

    await update.message.reply_text(
        f"✅ *تم بنجاح!*\n\n"
        f"🆔 `{t.tenant_id}`\n"
        f"🏪 {t.business_name}\n"
        f"📦 {t.business_type}\n"
        f"💰 {t.monthly_fee_iqd:,} د.ع/شهر\n"
        f"🎁 فترة تجربة: ١٤ يوم\n\n"
        f"📡 اربط القنوات:\n"
        f"  /link_wa {t.tenant_id} 96477xxxxxxxx\n"
        f"  /link_ig {t.tenant_id} handle <ig_business_id>\n\n"
        f"📚 ارفع KB:\n"
        f"  /upload {t.tenant_id} (ثم ابعت ملف)\n"
        f"  /addurl {t.tenant_id} <url>\n"
        f"  /kb {t.tenant_id} <نص>",
        parse_mode="Markdown",
    )
    ctx.user_data.clear()
    return ConversationHandler.END


async def add_cancel(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("تم الإلغاء.")
    return ConversationHandler.END


def build_add_conversation():
    return ConversationHandler(
        entry_points=[CommandHandler("add", add_start)],
        states={
            S_TENANT_ID: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_tenant_id)],
            S_NAME:      [MessageHandler(filters.TEXT & ~filters.COMMAND, add_name)],
            S_OWNER:     [MessageHandler(filters.TEXT & ~filters.COMMAND, add_owner)],
            S_PHONE:     [MessageHandler(filters.TEXT & ~filters.COMMAND, add_phone)],
            S_TYPE:      [MessageHandler(filters.TEXT & ~filters.COMMAND, add_type)],
            S_ADDRESS:   [MessageHandler(filters.TEXT & ~filters.COMMAND, add_address)],
            S_HOURS:     [MessageHandler(filters.TEXT & ~filters.COMMAND, add_hours)],
            S_FEE:       [MessageHandler(filters.TEXT & ~filters.COMMAND, add_fee)],
            S_KB:        [MessageHandler(filters.TEXT & ~filters.COMMAND, add_kb)],
        },
        fallbacks=[CommandHandler("cancel", add_cancel)],
    )
