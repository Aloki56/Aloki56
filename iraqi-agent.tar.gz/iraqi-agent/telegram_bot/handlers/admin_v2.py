"""
telegram_bot/handlers/admin_v2.py
The complete admin bot — full feature set:
  - Add/edit/delete/suspend tenants
  - Upload KB files (PDF, DOCX, XLSX, CSV, photos)
  - View stats, billing, invoices
  - Broadcast messages
  - Monitor live conversations
  - Manage LLM providers
  - See system alerts
  - Rate limit protection per admin
"""
from __future__ import annotations
import asyncio
import io
import time
from typing import Optional
from loguru import logger
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, InputFile
from telegram.ext import ContextTypes

from core.config import get_settings
from telegram_bot.handlers.auth import is_admin, friendly_deny, get_admin_ids
from tenants.store import get_store
from tenants.manager import (
    create_tenant, link_whatsapp, link_instagram, link_messenger, link_tiktok,
    suspend_tenant, activate_tenant, update_knowledge_base, update_monthly_fee,
)
from memory.manager import get_memory_manager
from billing.subscription import get_subscription_manager
from billing.invoices import get_invoice_manager
from billing.tiers import TIERS, get_tier
from rag.pipeline import get_rag
from channels.manager import get_manager
from monitoring.alerts import get_alert_manager


# ============== AUTH ==============
# (is_admin, friendly_deny, get_admin_ids imported above from auth.py)


# ============== START / HELP ==============
async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    await update.message.reply_text(
        "🟢 *لوحة تحكم الوكيل العراقي*\n\n"
        "🚀 أوامر سريعة:\n"
        "/dashboard — لوحة المعلومات\n"
        "/tenants — المشاريع\n"
        "/add — إضافة مشروع\n"
        "/billing — الفواتير والاشتراكات\n"
        "/stats — إحصائيات النظام\n"
        "/monitoring — المراقبة\n"
        "/help — كل الأوامر",
        parse_mode="Markdown",
    )


async def cmd_help(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    await update.message.reply_text(
        "📖 *كل الأوامر*\n\n"
        "*🏪 المشاريع:*\n"
        "  /tenants — قائمة\n"
        "  /add — إضافة\n"
        "  /edit <id> — تعديل\n"
        "  /delete <id> — حذف\n"
        "  /suspend <id> — إيقاف\n"
        "  /activate <id> — تفعيل\n\n"
        "*📚 قاعدة المعرفة:*\n"
        "  /upload <id> — ارفع ملف\n"
        "  /addurl <id> <url> — أضف رابط\n"
        "  /kb <id> <نص> — أضف نص\n"
        "  /kbclear <id> — امسح KB\n\n"
        "*📡 القنوات:*\n"
        "  /link_wa <id> <phone>\n"
        "  /link_ig <id> <handle> <ig_business_id>\n"
        "  /link_fb <id> <page_id>\n"
        "  /link_tt <id> <handle>\n"
        "  /channels <id> — القنوات النشطة\n\n"
        "*💰 الفواتير:*\n"
        "  /billing — كل الفواتير\n"
        "  /invoice <id> <tier> <months> — أصدر فاتورة\n"
        "  /paid <invoice_id> <ref> — سجّل دفعة\n"
        "  /subscriptions — الاشتراكات\n\n"
        "*📣 التسويق:*\n"
        "  /broadcast <id> <نص>\n"
        "  /customers <id> — قائمة الزبائن\n\n"
        "*🛠 النظام:*\n"
        "  /dashboard\n"
        "  /stats\n"
        "  /monitoring\n"
        "  /audit — سجل التدقيق\n"
        "  /healthcheck — فحص شامل",
        parse_mode="Markdown",
    )


# ============== DASHBOARD ==============
async def cmd_dashboard(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    s = get_settings()
    tenants = get_store().list_all()
    active = sum(1 for t in tenants if t.status == "active")
    sm = get_subscription_manager()
    im = get_invoice_manager()
    mem = get_memory_manager().stats()
    providers = s.enabled_providers()
    rev = im.stats()
    kb_total = sum(get_rag().stats(t.tenant_id).get("vectors", 0) for t in tenants)

    txt = (
        f"📊 *لوحة المعلومات*\n\n"
        f"🏪 المستأجرون: *{len(tenants)}* (نشط: {active})\n"
        f"💰 الإيرادات: *{rev['revenue_iqd']:,}* د.ع\n"
        f"⏳ مستحقات: *{rev['pending_iqd']:,}* د.ع\n"
        f"📨 الرسائل: *{mem.get('total_messages', 0):,}*\n"
        f"🧠 القطع المعرفية: *{kb_total:,}*\n"
        f"🤖 الموفرون: {' / '.join(providers) or 'لا يوجد!'}\n"
        f"📡 القنوات: {sum(1 for n in ['whatsapp','instagram','messenger','tiktok','webchat'] if get_manager().get(n))}/5\n\n"
        f"_آخر تحديث: {time.strftime('%H:%M:%S')}_"
    )
    await update.message.reply_text(txt, parse_mode="Markdown")


# ============== TENANTS ==============
async def cmd_tenants(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    tenants = get_store().list_all()
    if not tenants:
        return await update.message.reply_text("📭 ما عندك أي مشروع. /add")
    sm = get_subscription_manager()
    lines = ["🏪 *كل المشاريع:*\n"]
    for t in tenants:
        chs = []
        if t.channels.whatsapp_number: chs.append("WA")
        if t.channels.instagram_handle: chs.append("IG")
        if t.channels.messenger_page_id: chs.append("FB")
        if t.channels.tiktok_handle: chs.append("TT")
        sub = sm.get(t.tenant_id)
        tier_ar = sub.current_tier().name_ar
        days = sub.days_remaining()
        emoji = "🟢" if t.status == "active" and days > 0 else ("⏸" if t.status != "active" else "⚠️")
        lines.append(
            f"{emoji} *{t.business_name}* `{t.tenant_id}`\n"
            f"   {t.business_type} | {', '.join(chs) or '—'} | {tier_ar} ({days}ي)"
        )
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


async def cmd_tenant_detail(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    if not ctx.args:
        return await update.message.reply_text("استعمل: /tenant <id>")
    tid = ctx.args[0]
    t = get_store().get(tid)
    if not t:
        return await update.message.reply_text("❌ ما لكيت هذا المستأجر")
    sub = get_subscription_manager().get(tid)
    rag = get_rag().stats(tid)
    mem = get_memory_manager().list_customers(tid, limit=5)
    customers_count = len(get_memory_manager().list_customers(tid, limit=9999))
    ch = t.channels
    msg = (
        f"🏪 *{t.business_name}* (`{t.tenant_id}`)\n\n"
        f"📍 {t.address or '—'}\n"
        f"⏰ {t.working_hours}\n"
        f"📞 {t.phone or '—'}\n"
        f"👤 المالك: {t.owner_name} ({t.owner_phone})\n\n"
        f"💎 الباقة: {sub.current_tier().name_ar}\n"
        f"📅 متبقي: {sub.days_remaining()} يوم\n"
        f"💳 الدفع: {sub.payment_method}\n\n"
        f"📡 القنوات:\n"
        f"  • واتساب: {ch.whatsapp_number or '—'}\n"
        f"  • إنستكرام: {ch.instagram_handle or '—'}\n"
        f"  • ماسنجر: {ch.messenger_page_id or '—'}\n"
        f"  • تيك توك: {ch.tiktok_handle or '—'}\n\n"
        f"📚 KB: {rag.get('vectors', 0):,} قطعة\n"
        f"👥 الزبائن: {customers_count}\n"
        f"📨 الرسائل: {mem and '...' or 0}\n"
        f"📊 الحالة: {t.status}\n\n"
        f"📝 ملاحظات: {t.notes or '—'}"
    )
    kb_buttons = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📚 رفع KB", callback_data=f"upload:{tid}"),
            InlineKeyboardButton("💰 فاتورة", callback_data=f"invoice:{tid}"),
        ],
        [
            InlineKeyboardButton("📣 بث", callback_data=f"broadcast:{tid}"),
            InlineKeyboardButton("📊 إحصائيات", callback_data=f"stats:{tid}"),
        ],
        [
            InlineKeyboardButton("⏸ إيقاف" if t.status == "active" else "▶️ تفعيل",
                                 callback_data=f"toggle:{tid}"),
            InlineKeyboardButton("🗑 حذف", callback_data=f"delete:{tid}"),
        ],
    ])
    await update.message.reply_text(msg, parse_mode="Markdown", reply_markup=kb_buttons)


# ============== KB UPLOAD (file handler) ==============
async def on_document(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Catch uploaded files. The user must first send /upload <tenant_id>."""
    if not is_admin(update):
        return await friendly_deny(update)
    expected_tid = ctx.user_data.get("awaiting_upload_for")
    if not expected_tid:
        return await update.message.reply_text("أرسل /upload <id> أول، بعدين ابعث الملف.")
    doc = update.message.document
    if not doc:
        return
    # Download
    f = await doc.get_file()
    buf = io.BytesIO()
    await f.download_to_memory(buf)
    buf.seek(0)
    # Save to disk
    path = f"./data/uploads/{expected_tid}_{int(time.time())}_{doc.file_name}"
    import os
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as out:
        out.write(buf.read())
    # Index
    try:
        n = get_rag().ingest_file(expected_tid, path)
        await update.message.reply_text(f"✅ تم فهرسة {n} قطعة في قاعدة المعرفة لـ {expected_tid}")
    except Exception as e:
        await update.message.reply_text(f"❌ فشل: {e!r}")
    ctx.user_data.pop("awaiting_upload_for", None)


async def cmd_upload(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    if not ctx.args:
        return await update.message.reply_text("استعمل: /upload <tenant_id>")
    tid = ctx.args[0]
    if not get_store().get(tid):
        return await update.message.reply_text("❌ ما لكيت المستأجر")
    ctx.user_data["awaiting_upload_for"] = tid
    await update.message.reply_text(
        f"📚 ابعت الملف اللي تريد تنضيفه لقاعدة المعرفة لـ `{tid}`.\n"
        f"يدعم: PDF, DOCX, XLSX, CSV, TXT",
        parse_mode="Markdown",
    )


async def cmd_addurl(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    if len(ctx.args) < 2:
        return await update.message.reply_text("استعمل: /addurl <id> <url>")
    tid, url = ctx.args[0], ctx.args[1]
    try:
        n = get_rag().ingest_url(tid, url)
        await update.message.reply_text(f"✅ تم فهرسة {n} قطعة من {url}")
    except Exception as e:
        await update.message.reply_text(f"❌ {e}")


async def cmd_kb(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    if len(ctx.args) < 2:
        return await update.message.reply_text("استعمل: /kb <id> <نص>")
    tid = ctx.args[0]
    text = " ".join(ctx.args[1:])
    try:
        n = get_rag().ingest_text(tid, text, source="telegram")
        await update.message.reply_text(f"✅ تم إضافة {n} قطعة")
    except Exception as e:
        await update.message.reply_text(f"❌ {e}")


async def cmd_kbclear(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    if not ctx.args: return await update.message.reply_text("استعمل: /kbclear <id>")
    get_rag().reset_tenant(ctx.args[0])
    await update.message.reply_text(f"🧹 تم مسح KB لـ {ctx.args[0]}")


# ============== CHANNELS ==============
async def cmd_link_wa(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    if len(ctx.args) < 2:
        return await update.message.reply_text("استعمل: /link_wa <id> <phone>")
    try:
        link_whatsapp(ctx.args[0], ctx.args[1])
        await update.message.reply_text(f"✅ تم ربط واتساب {ctx.args[1]} بـ {ctx.args[0]}")
    except Exception as e:
        await update.message.reply_text(f"❌ {e}")


async def cmd_link_ig(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    if len(ctx.args) < 3:
        return await update.message.reply_text("استعمل: /link_ig <id> <handle> <ig_business_id>")
    tid, handle, ig_id = ctx.args[0], ctx.args[1], ctx.args[2]
    ctx.user_data["pending_ig"] = (tid, handle, ig_id)
    await update.message.reply_text("تمام. ابعث الـ Page Access Token هسه:")


async def cmd_link_fb(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    if len(ctx.args) < 2:
        return await update.message.reply_text("استعمل: /link_fb <id> <page_id>")
    ctx.user_data["pending_fb"] = (ctx.args[0], ctx.args[1])
    await update.message.reply_text("تمام. ابعث الـ Page Access Token:")


async def cmd_link_tt(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    if len(ctx.args) < 2:
        return await update.message.reply_text("استعمل: /link_tt <id> <handle>")
    try:
        link_tiktok(ctx.args[0], ctx.args[1])
        await update.message.reply_text(f"✅ تم ربط تيك توك @{ctx.args[1]}")
    except Exception as e:
        await update.message.reply_text(f"❌ {e}")


# ============== BILLING ==============
async def cmd_billing(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    im = get_invoice_manager()
    invoices = []
    for t in get_store().list_all():
        invoices.extend(im.list_for_tenant(t.tenant_id))
    if not invoices:
        return await update.message.reply_text("📭 ما عندك أي فواتير")
    lines = [f"💰 *الفواتير* (المجموع: {im.stats()['invoices_total']})\n"]
    for inv in sorted(invoices, key=lambda i: -i.issued_at)[:30]:
        sign = "✅" if inv.status == "paid" else "⏳"
        lines.append(
            f"{sign} `{inv.invoice_id}` — {inv.total_iqd:,} د.ع — {inv.status}\n"
            f"   مستأجر: {inv.tenant_id}"
        )
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


async def cmd_invoice(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    if len(ctx.args) < 2:
        tiers_list = "\n".join([f"  • {tid} — {t.name_ar} ({t.monthly_iqd:,} د.ع)" for tid, t in TIERS.items()])
        return await update.message.reply_text(
            f"📋 *الباقات:*\n{tiers_list}\n\n"
            f"استعمل: /invoice <tenant_id> <tier_id> [months]",
            parse_mode="Markdown",
        )
    tid = ctx.args[0]
    tier = ctx.args[1] if len(ctx.args) > 1 else "basic"
    months = int(ctx.args[2]) if len(ctx.args) > 2 else 1
    if not get_store().get(tid):
        return await update.message.reply_text("❌ ما لكيت المستأجر")
    inv = get_invoice_manager().create(tid, tier, months)
    get_subscription_manager().set_tier(tid, tier, days=30*months)
    await update.message.reply_text(
        f"🧾 *فاتورة جديدة*\n\n"
        f"الرقم: `{inv.invoice_id}`\n"
        f"الباقة: {get_tier(tier).name_ar}\n"
        f"المدة: {months} شهر\n"
        f"المبلغ: *{inv.total_iqd:,}* د.ع\n\n"
        f"ابعث الـ ID للزبون. لما يدفع:\n"
        f"`/paid {inv.invoice_id} <ref>`",
        parse_mode="Markdown",
    )


async def cmd_paid(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    if len(ctx.args) < 2:
        return await update.message.reply_text("استعمل: /paid <invoice_id> <ref>")
    inv_id, ref = ctx.args[0], ctx.args[1]
    inv = get_invoice_manager().mark_paid(inv_id, ref)
    if not inv:
        return await update.message.reply_text("❌ ما لكيت الفاتورة")
    from monitoring.metrics import metrics
    metrics.tenant_billing.labels(tier="unknown").inc(inv.total_iqd)
    await update.message.reply_text(
        f"✅ تم تسجيل الدفعة\n"
        f"الفاتورة: {inv.invoice_id}\n"
        f"المبلغ: {inv.total_iqd:,} د.ع\n"
        f"المرجع: {ref}"
    )


async def cmd_subscriptions(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    sm = get_subscription_manager()
    stats = sm.stats()
    expiring = sm.list_expiring(7)
    expired = sm.list_expired()
    txt = (
        f"📊 *الاشتراكات*\n"
        f"المجموع: {stats['subscriptions']}\n"
        f"نشط: {stats['active']}\n"
        f"حسب الباقة: {stats['by_tier']}\n\n"
    )
    if expiring:
        txt += "⚠️ *تنتهي خلال ٧ أيام:*\n"
        for s in expiring:
            txt += f"  • {s.tenant_id} — {s.current_tier().name_ar} ({s.days_remaining()}ي)\n"
    if expired:
        txt += "\n❌ *منتهية:*\n"
        for s in expired:
            txt += f"  • {s.tenant_id}\n"
    await update.message.reply_text(txt, parse_mode="Markdown")


# ============== BROADCAST / CUSTOMERS ==============
async def cmd_broadcast(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    if len(ctx.args) < 2:
        return await update.message.reply_text("استعمل: /broadcast <id> <نص>")
    tid = ctx.args[0]
    text = " ".join(ctx.args[1:])
    customers = get_memory_manager().list_customers(tid, limit=9999)
    if not customers:
        return await update.message.reply_text("ما عندك زبائن لهالمستأجر لحد الآن")
    mgr = get_manager()
    sent = 0
    for c in customers:
        for ch_name, ch_id in c.channel_ids.items():
            ad = mgr.get(ch_name)
            if ad:
                try:
                    await ad.send(ch_id, text, tenant=get_store().get(tid))
                    sent += 1
                except Exception:
                    pass
    await update.message.reply_text(f"📣 تم إرسال {sent} رسالة لـ {len(customers)} زبون.")


async def cmd_customers(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    if not ctx.args: return await update.message.reply_text("استعمل: /customers <id>")
    customers = get_memory_manager().list_customers(ctx.args[0], limit=50)
    if not customers:
        return await update.message.reply_text("📭 ما عنده زبائن لحد الآن")
    lines = [f"👥 *زبائن {ctx.args[0]}* ({len(customers)})\n"]
    for c in customers[:30]:
        chs = ", ".join(c.channel_ids.keys())
        lines.append(f"• {c.name or 'بدون اسم'} — {c.phone or '—'} — {chs}")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


# ============== SYSTEM ==============
async def cmd_stats(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    s = get_settings()
    mem = get_memory_manager().stats()
    sm = get_subscription_manager().stats()
    im = get_invoice_manager().stats()
    providers = s.enabled_providers()
    mgr = get_manager()
    chs = {n: (mgr.get(n).is_connected if mgr.get(n) else False) for n in
           ["whatsapp", "instagram", "messenger", "tiktok", "webchat", "gmail", "sms", "outlook"]}
    await update.message.reply_text(
        f"📊 *إحصائيات النظام*\n\n"
        f"💎 الباقات: {sm}\n"
        f"💰 الإيرادات: {im}\n"
        f"🧠 الذاكرة: {mem}\n"
        f"🤖 LLM: {providers or '— لا يوجد —'}\n"
        f"📡 القنوات: {chs}",
        parse_mode="Markdown",
    )


async def cmd_monitoring(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    from monitoring.health import HealthChecker
    h = await HealthChecker().check_all()
    overall = h.get("overall", "unknown")
    emoji = {"ok": "✅", "degraded": "⚠️", "down": "❌"}.get(overall, "❓")
    lines = [f"{emoji} الحالة العامة: *{overall}*\n"]
    for name, info in h.get("checks", {}).items():
        s = info.get("status", "?")
        e = {"ok": "✅", "warn": "⚠️", "error": "❌"}.get(s, "❓")
        lines.append(f"{e} *{name}*: {s}")
        for k, v in info.items():
            if k != "status":
                lines.append(f"   `{k}`: {v}")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


async def cmd_audit(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    from security.audit import get_audit
    entries = get_audit().query(limit=30)
    if not entries:
        return await update.message.reply_text("📭 السجل فاضي")
    lines = ["🛡 *آخر ٣٠ عملية:*\n"]
    for e in entries[-30:]:
        ts = time.strftime("%H:%M", time.localtime(e.get("ts", 0)))
        lines.append(f"`{ts}` {e.get('actor','?')} → {e.get('action','?')} ({e.get('target','-')})")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


# ============== CALLBACKS (inline buttons) ==============
async def on_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    q = update.callback_query
    await q.answer()
    data = q.data or ""
    if ":" not in data:
        return
    action, tid = data.split(":", 1)
    if action == "upload":
        ctx.user_data["awaiting_upload_for"] = tid
        await q.message.reply_text(f"📚 ابعت الملف لـ {tid}")
    elif action == "invoice":
        await q.message.reply_text(f"/invoice {tid} basic 1")
    elif action == "broadcast":
        await q.message.reply_text(f"/broadcast {tid} <نص>")
    elif action == "stats":
        cust = get_memory_manager().list_customers(tid, limit=9999)
        msgs = get_memory_manager().cm.search(tid, "", limit=1)
        await q.message.reply_text(
            f"📊 {tid}\nالزبائن: {len(cust)}\nآخر نشاط: {time.strftime('%H:%M', time.localtime(cust[0].last_seen)) if cust else '—'}"
        )
    elif action == "toggle":
        t = get_store().get(tid)
        if t:
            if t.status == "active":
                suspend_tenant(tid)
            else:
                activate_tenant(tid)
            await q.message.reply_text(f"✅ تم تغيير حالة {tid}")
    elif action == "delete":
        # Soft delete — we just mark inactive and rename id
        from tenants.manager import suspend_tenant
        suspend_tenant(tid)
        await q.message.reply_text(f"🗑 تم إيقاف (soft-delete) {tid}. للحذف النهائي: /delete_confirm {tid}")


# ============== TENANT OPERATIONS ==============
async def cmd_suspend(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    if not ctx.args: return await update.message.reply_text("/suspend <id>")
    suspend_tenant(ctx.args[0])
    await update.message.reply_text(f"⏸ تم إيقاف {ctx.args[0]}")


async def cmd_activate(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    if not ctx.args: return await update.message.reply_text("/activate <id>")
    activate_tenant(ctx.args[0])
    await update.message.reply_text(f"🟢 تم تفعيل {ctx.args[0]}")


async def cmd_delete(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update):
        return await friendly_deny(update)
    if not ctx.args: return await update.message.reply_text("/delete <id>")
    get_store().delete(ctx.args[0])
    get_rag().reset_tenant(ctx.args[0])
    await update.message.reply_text(f"🗑 تم حذف {ctx.args[0]} نهائياً")
