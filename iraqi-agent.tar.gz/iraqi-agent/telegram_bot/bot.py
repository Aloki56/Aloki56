"""
telegram_bot/bot.py
Builds the full Telegram control bot.
"""
from __future__ import annotations
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters

from core.config import get_settings
from telegram_bot.handlers import admin_v2 as admin
from telegram_bot.handlers import whoami as wm
from telegram_bot.handlers.add_wizard import build_add_conversation


def build_bot() -> Application:
    s = get_settings()
    if not s.telegram_bot_token:
        raise RuntimeError("TELEGRAM_BOT_TOKEN missing in .env")
    app = Application.builder().token(s.telegram_bot_token).build()

    # Add conversation handlers
    app.add_handler(build_add_conversation())

    # Public commands (work for anyone)
    app.add_handler(CommandHandler("whoami", wm.cmd_whoami))

    # Commands
    app.add_handler(CommandHandler("start", admin.cmd_start))
    app.add_handler(CommandHandler("help", admin.cmd_help))
    app.add_handler(CommandHandler("dashboard", admin.cmd_dashboard))
    app.add_handler(CommandHandler("tenants", admin.cmd_tenants))
    app.add_handler(CommandHandler("tenant", admin.cmd_tenant_detail))
    app.add_handler(CommandHandler("suspend", admin.cmd_suspend))
    app.add_handler(CommandHandler("activate", admin.cmd_activate))
    app.add_handler(CommandHandler("delete", admin.cmd_delete))

    # KB
    app.add_handler(CommandHandler("upload", admin.cmd_upload))
    app.add_handler(CommandHandler("addurl", admin.cmd_addurl))
    app.add_handler(CommandHandler("kb", admin.cmd_kb))
    app.add_handler(CommandHandler("kbclear", admin.cmd_kbclear))

    # Channels
    app.add_handler(CommandHandler("link_wa", admin.cmd_link_wa))
    app.add_handler(CommandHandler("link_ig", admin.cmd_link_ig))
    app.add_handler(CommandHandler("link_fb", admin.cmd_link_fb))
    app.add_handler(CommandHandler("link_tt", admin.cmd_link_tt))

    # Billing
    app.add_handler(CommandHandler("billing", admin.cmd_billing))
    app.add_handler(CommandHandler("invoice", admin.cmd_invoice))
    app.add_handler(CommandHandler("paid", admin.cmd_paid))
    app.add_handler(CommandHandler("subscriptions", admin.cmd_subscriptions))

    # Marketing
    app.add_handler(CommandHandler("broadcast", admin.cmd_broadcast))
    app.add_handler(CommandHandler("customers", admin.cmd_customers))

    # System
    app.add_handler(CommandHandler("stats", admin.cmd_stats))
    app.add_handler(CommandHandler("monitoring", admin.cmd_monitoring))
    app.add_handler(CommandHandler("audit", admin.cmd_audit))

    # Admin management
    app.add_handler(CommandHandler("addadmin", wm.cmd_addadmin))
    app.add_handler(CommandHandler("removeadmin", wm.cmd_removeadmin))
    app.add_handler(CommandHandler("admins", wm.cmd_admins))

    # Callbacks
    app.add_handler(CallbackQueryHandler(admin.on_callback))

    # Document uploads (catch all)
    app.add_handler(MessageHandler(filters.Document.ALL, admin.on_document))

    return app
