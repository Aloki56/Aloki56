"""
billing/subscription.py
Per-tenant subscription state.
"""
from __future__ import annotations
import time
from typing import Optional, List
from pydantic import BaseModel, Field
from loguru import logger

from .tiers import TIERS, get_tier, Tier


class Subscription(BaseModel):
    tenant_id: str
    tier: str = "trial"                 # trial | basic | pro | enterprise
    started_at: float = Field(default_factory=time.time)
    expires_at: float = 0.0              # 0 = no expiry (lifetime/trial)
    auto_renew: bool = True
    payment_method: str = "manual"       # manual | zain_cash | fastpay | fib
    notes: str = ""

    def is_active(self) -> bool:
        if self.tier == "trial" and self.expires_at == 0:
            return True
        return self.expires_at > time.time()

    def days_remaining(self) -> int:
        if self.expires_at == 0:
            return 9999
        return max(0, int((self.expires_at - time.time()) / 86400))

    def current_tier(self) -> Tier:
        return get_tier(self.tier)


class SubscriptionManager:
    """CRUD for subscriptions. Backed by TinyDB in dev, Postgres in prod."""

    def __init__(self):
        self._subs: dict[str, Subscription] = {}

    def get(self, tenant_id: str) -> Subscription:
        s = self._subs.get(tenant_id)
        if not s:
            s = Subscription(tenant_id=tenant_id, tier="trial",
                             expires_at=time.time() + 14 * 86400)  # 14-day trial
            self._subs[tenant_id] = s
        return s

    def set_tier(self, tenant_id: str, tier: str, days: int = 30, payment_method: str = "manual"):
        t = get_tier(tier)
        s = self.get(tenant_id)
        s.tier = tier
        s.expires_at = time.time() + days * 86400
        s.payment_method = payment_method
        self._subs[tenant_id] = s
        logger.info(f"💳 {tenant_id} → {t.name_ar} until {time.ctime(s.expires_at)}")

    def extend(self, tenant_id: str, days: int):
        s = self.get(tenant_id)
        if s.expires_at < time.time():
            s.expires_at = time.time()
        s.expires_at += days * 86400
        self._subs[tenant_id] = s

    def cancel(self, tenant_id: str):
        s = self.get(tenant_id)
        s.auto_renew = False
        self._subs[tenant_id] = s

    def list_expiring(self, within_days: int = 7) -> List[Subscription]:
        threshold = time.time() + within_days * 86400
        return [s for s in self._subs.values()
                if s.expires_at > 0 and s.expires_at < threshold]

    def list_expired(self) -> List[Subscription]:
        now = time.time()
        return [s for s in self._subs.values() if s.expires_at > 0 and s.expires_at < now]

    def stats(self) -> dict:
        active = sum(1 for s in self._subs.values() if s.is_active())
        by_tier = {}
        for s in self._subs.values():
            by_tier[s.tier] = by_tier.get(s.tier, 0) + 1
        return {
            "subscriptions": len(self._subs),
            "active": active,
            "by_tier": by_tier,
        }


_subs: SubscriptionManager | None = None
def get_subscription_manager() -> SubscriptionManager:
    global _subs
    if _subs is None:
        _subs = SubscriptionManager()
    return _subs
