"""
billing/invoices.py
Invoices for the Iraqi market — header in Arabic, line items,
total in IQD, payment instructions for Zain Cash / FastPay / FIB.
"""
from __future__ import annotations
import time
import secrets
from typing import Dict, List
from pydantic import BaseModel, Field
from loguru import logger

from .tiers import get_tier, TIERS


class InvoiceLine(BaseModel):
    description: str
    quantity: int = 1
    unit_iqd: int = 0
    total_iqd: int = 0


class Invoice(BaseModel):
    invoice_id: str
    tenant_id: str
    issued_at: float = Field(default_factory=time.time)
    due_at: float = 0.0
    lines: List[InvoiceLine] = []
    subtotal_iqd: int = 0
    tax_iqd: int = 0
    total_iqd: int = 0
    status: str = "pending"     # pending | paid | overdue | cancelled
    paid_at: float = 0.0
    payment_ref: str = ""
    notes: str = ""

    def to_text_ar(self) -> str:
        lines = [
            f"🧾 فاتورة رقم: {self.invoice_id}",
            f"📅 تاريخ الإصدار: {time.strftime('%Y-%m-%d', time.localtime(self.issued_at))}",
            f"💰 المبلغ: {self.total_iqd:,} د.ع",
            f"📌 الحالة: {self._status_ar()}",
        ]
        if self.notes:
            lines.append(f"📝 ملاحظات: {self.notes}")
        return "\n".join(lines)

    def _status_ar(self) -> str:
        return {
            "pending": "غير مدفوعة",
            "paid": "مدفوعة ✅",
            "overdue": "متأخرة ⚠️",
            "cancelled": "ملغاة ❌",
        }.get(self.status, self.status)


class InvoiceManager:
    def __init__(self):
        self._invoices: Dict[str, Invoice] = {}

    def create(
        self,
        tenant_id: str,
        tier: str,
        months: int = 1,
        tax_rate: float = 0.0,
        notes: str = "",
    ) -> Invoice:
        t = get_tier(tier)
        unit = t.monthly_iqd
        line = InvoiceLine(
            description=f"اشتراك {t.name_ar} × {months} شهر",
            quantity=months,
            unit_iqd=unit,
            total_iqd=unit * months,
        )
        subtotal = line.total_iqd
        tax = int(subtotal * tax_rate)
        inv = Invoice(
            invoice_id="INV-" + secrets.token_hex(4).upper(),
            tenant_id=tenant_id,
            due_at=time.time() + 7 * 86400,
            lines=[line],
            subtotal_iqd=subtotal,
            tax_iqd=tax,
            total_iqd=subtotal + tax,
            notes=notes,
        )
        self._invoices[inv.invoice_id] = inv
        logger.info(f"🧾 Created invoice {inv.invoice_id} for {tenant_id} ({tier})")
        return inv

    def mark_paid(self, invoice_id: str, payment_ref: str = "") -> Invoice | None:
        inv = self._invoices.get(invoice_id)
        if not inv:
            return None
        inv.status = "paid"
        inv.paid_at = time.time()
        inv.payment_ref = payment_ref
        return inv

    def get(self, invoice_id: str) -> Invoice | None:
        return self._invoices.get(invoice_id)

    def list_for_tenant(self, tenant_id: str) -> List[Invoice]:
        return [i for i in self._invoices.values() if i.tenant_id == tenant_id]

    def stats(self) -> dict:
        paid = sum(i.total_iqd for i in self._invoices.values() if i.status == "paid")
        pending = sum(i.total_iqd for i in self._invoices.values() if i.status == "pending")
        return {
            "invoices_total": len(self._invoices),
            "revenue_iqd": paid,
            "pending_iqd": pending,
        }


_inv: InvoiceManager | None = None
def get_invoice_manager() -> InvoiceManager:
    global _inv
    if _inv is None:
        _inv = InvoiceManager()
    return _inv
