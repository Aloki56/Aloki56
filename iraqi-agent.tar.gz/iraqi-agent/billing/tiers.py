"""
billing/tiers.py
Subscription tier definitions (IQD pricing).
"""
from __future__ import annotations
from typing import Dict, List
from pydantic import BaseModel


class Tier(BaseModel):
    id: str
    name_ar: str
    monthly_iqd: int
    channels: int             # max enabled channels
    monthly_messages: int     # soft cap; overages are billed
    rag_chunks: int           # max KB chunks indexed
    agents: int = 1           # concurrent agent slots
    features: List[str] = []


TIERS: Dict[str, Tier] = {
    "trial": Tier(
        id="trial",
        name_ar="تجربة",
        monthly_iqd=0,
        channels=1,
        monthly_messages=200,
        rag_chunks=200,
        agents=1,
        features=["تجربة لمدة ١٤ يوم", "قناة واحدة", "دعم بالبريد"],
    ),
    "basic": Tier(
        id="basic",
        name_ar="أساسي",
        monthly_iqd=75_000,
        channels=2,
        monthly_messages=2_000,
        rag_chunks=2_000,
        agents=1,
        features=["قناتان", "٢٠٠٠ رسالة/شهر", "KB حتى ٢٠٠٠ قطعة", "دعم تليكرام"],
    ),
    "pro": Tier(
        id="pro",
        name_ar="احترافي",
        monthly_iqd=150_000,
        channels=4,
        monthly_messages=10_000,
        rag_chunks=10_000,
        agents=3,
        features=["كل القنوات", "١٠,٠٠٠ رسالة/شهر", "KB حتى ١٠,٠٠٠", "تحليلات", "دعم ٢٤/٧"],
    ),
    "enterprise": Tier(
        id="enterprise",
        name_ar="مؤسسي",
        monthly_iqd=500_000,
        channels=8,
        monthly_messages=100_000,
        rag_chunks=100_000,
        agents=10,
        features=["غير محدود تقريباً", "API خاص", "تدريب مخصص", "مدير حساب", "SLA"],
    ),
}


def get_tier(tier_id: str) -> Tier:
    return TIERS.get(tier_id) or TIERS["trial"]
