"""
billing/payments.py
Manual payment recorder. Iraqi market uses Zain Cash, FastPay, FIB,
Qi Card. We record the payment reference and mark the invoice paid.
"""
from __future__ import annotations
import time
from typing import Optional
from loguru import logger

from .invoices import get_invoice_manager, Invoice


PAYMENT_INSTRUCTIONS_AR = """
طرق الدفع المتاحة:
1) **زين كاش** — 07XX XXX XXXX  (اسم: [اسمك])
2) **فاست باي** — FastPay: 07XX XXX XXXX
3) **FIB** — 07XX XXX XXXX
4) **كي كارد** — حوّل على [اسمك]

بعد التحويل، ابعث صورة الإيصال + رقم الفاتورة.
"""


class PaymentRecorder:
    def __init__(self):
        self.invoices = get_invoice_manager()

    def confirm_payment(
        self,
        invoice_id: str,
        method: str,
        reference: str,
        amount_iqd: int,
        notes: str = "",
    ) -> Optional[Invoice]:
        inv = self.invoices.get(invoice_id)
        if not inv:
            return None
        if inv.status == "paid":
            return inv
        if amount_iqd < inv.total_iqd:
            inv.notes += f"\n⚠️ دفعة جزئية: {amount_iqd:,} د.ع من {inv.total_iqd:,}"
        inv = self.invoices.mark_paid(invoice_id, payment_ref=f"{method}:{reference}")
        logger.info(f"💵 Payment recorded for {invoice_id}: {method} {amount_iqd}")
        return inv
