# 🇮🇶 Iraqi Agent — منصة SaaS متعددة العملاء للذكاء الاصطناعي العراقي

> **منصة كاملة جاهزة للإنتاج** — وكيل ذكاء اصطناعي باللهجة العراقية، متعدد العملاء (Multi-Tenant)، يعمل على كل القنوات (واتساب، إنستكرام، ماسنجر، تيك توك، تيليجرام، ويب، إيميل، SMS)، مع نظام اشتراكات وفوترة ولوحة تحكم كاملة من بوت تيليكرام، وكلها مجانية ١٠٠٪.

---

## 🎯 ليش هذا المشروع؟

صُمّم خصيصاً للسوق العراقي والعربي:

- 🗣 **يتكلم عراقي طبيعي** (بغدادي / جنوبي) — مو فصحى ثقيلة
- 🍽 **جاهز للمطاعم والكافيهات** — أضف مشروع في ٥ دقائق وابدأ يرد
- 💸 **مصدر دخل سلبي** — بيع اشتراكات شهرية من ٢٥ ألف د.ع
- 🛡 **ما يوقف أبداً** — failover تلقائي بين سيرفرات مجانية
- 🤖 **ذكاء حقيقي** — RAG + Memory + LangGraph + أفضل الموديلات المجانية
- 🔒 **آمن** — JWT, RBAC, rate limiting, audit logs, encryption

---

## ✨ المميزات الكاملة

### الـ Agent نفسه
- ✅ لهجة عراقية مع few-shot examples
- ✅ RAG مع Hybrid Retrieval (vector + BM25)
- ✅ استيراد PDF, DOCX, XLSX, CSV, Google Sheets, روابط، صفحات فيسبوك
- ✅ Multi-tier Memory (Short / Long / Conversation / Customer)
- ✅ LangGraph workflows (مطعم، دعم)
- ✅ Sentiment analysis
- ✅ Order/Reservation collection
- ✅ Auto-escalation to human
- ✅ Customer fact extraction (phone, email, preferences)

### القنوات (Channel Integrations)
- ✅ WhatsApp Business (Baileys bridge)
- ✅ Instagram DM (Meta Graph API)
- ✅ Facebook Messenger
- ✅ TikTok (Business API)
- ✅ Telegram (control bot)
- ✅ Web Chat Widget (embeddable JS)
- ✅ Email (Gmail, Outlook, IMAP/SMTP)
- ✅ SMS (Twilio / custom provider)

### Multi-Tenancy
- ✅ Per-tenant KB (vector store isolated)
- ✅ Per-tenant memory
- ✅ Per-tenant prompts
- ✅ Per-tenant subscription tier
- ✅ Per-tenant channel configuration
- ✅ Per-tenant API keys

### الإدارة من تليكرام
- ✅ Dashboard مع KPIs
- ✅ Onboarding wizard (add tenant)
- ✅ Edit / Delete / Suspend / Activate
- ✅ KB upload (PDF, DOCX, XLSX, CSV, photos)
- ✅ URL ingestion
- ✅ Channel linking
- ✅ Invoice generation
- ✅ Payment recording
- ✅ Subscription management
- ✅ Broadcast messages
- ✅ Live stats
- ✅ System health
- ✅ Audit log

### البنية التحتية
- ✅ FastAPI + WebSocket
- ✅ PostgreSQL (Supabase / Neon / local)
- ✅ Redis (Upstash / local)
- ✅ Qdrant (vector store)
- ✅ MinIO (S3-compatible)
- ✅ Prometheus + Grafana
- ✅ Background workers
- ✅ LangGraph + LangChain

### الأمان
- ✅ JWT auth
- ✅ RBAC (Owner, Admin, Tenant Owner, Agent, Customer)
- ✅ Per-tenant API keys
- ✅ Rate limiting (slowapi)
- ✅ Audit log
- ✅ Bcrypt password hashing
- ✅ CORS, security headers

### النشر
- ✅ Docker + Docker Compose
- ✅ Kubernetes manifests
- ✅ GitHub Actions CI/CD
- ✅ Fly.io config
- ✅ Render config
- ✅ Railway config
- ✅ Oracle Cloud guide
- ✅ Multi-server failover

---

## 🏗 المعمارية

```
┌─────────────────────────────────────────────────────────────┐
│                    Telegram Control Bot                     │
│         (لوحة التحكم الكاملة من جوالك)                       │
└──────────────────────────┬──────────────────────────────────┘
                           │ admin commands
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                       FastAPI App                           │
│  ┌────────────┐  ┌────────────┐  ┌────────────────────────┐│
│  │ LangGraph  │  │  Channel   │  │  Admin REST API        ││
│  │ Workflows  │  │  Manager   │  │  • /api/admin/tenants  ││
│  │ • rest.    │  │            │  │  • /api/kb/upload      ││
│  │ • support  │  │  8 adapters│  │  • /api/auth/login     ││
│  └─────┬──────┘  └─────┬──────┘  └────────────────────────┘│
│        │                │                                    │
│  ┌─────▼────────────────▼────────────────────────────────┐  │
│  │              Agent Engine                            │  │
│  │  • LLM Router (5 providers + fallback)               │  │
│  │  • RAG Pipeline (Qdrant + BM25)                      │  │
│  │  • Memory Manager (4 tiers)                          │  │
│  │  • Iraqi Dialect Layer                               │  │
│  │  • Sentiment Analysis                                │  │
│  │  • Intent Detection                                  │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
         │              │              │            │
         ▼              ▼              ▼            ▼
   ┌──────────┐   ┌──────────┐   ┌──────────┐ ┌──────────┐
   │  Groq    │   │  Google  │   │OpenRouter│ │ Together │
   │  (fast)  │   │  Gemini  │   │  (free)  │ │  (free)  │
   └──────────┘   └──────────┘   └──────────┘ └──────────┘

   ┌──────────┐   ┌──────────┐   ┌──────────┐
   │PostgreSQL│   │  Redis   │   │  Qdrant  │  + MinIO
   │ Supabase │   │ Upstash  │   │ (Vector) │    (S3)
   └──────────┘   └──────────┘   └──────────┘
```

---

## 📁 هيكل المشروع

```
iraqi-agent/
├── core/                      # Core engine
│   ├── agent.py               # Main orchestrator
│   ├── models.py              # 5 LLM providers + fallback
│   ├── prompts.py             # Iraqi system prompt
│   ├── iraqi.py               # Iraqi dialect utilities
│   ├── memory.py              # Legacy in-process memory
│   └── config.py              # Settings
│
├── rag/                       # RAG system
│   ├── loaders/               # PDF, DOCX, XLSX, CSV, URL, GSheet, FB
│   ├── chunkers/              # Arabic-aware text splitter
│   ├── embeddings/            # Local sentence-transformers + Google
│   ├── retrievers/            # Qdrant + BM25 hybrid
│   └── pipeline.py            # End-to-end pipeline
│
├── memory/                    # Multi-tier memory
│   ├── short_term.py
│   ├── long_term.py
│   ├── conversation.py
│   ├── customer.py
│   └── manager.py
│
├── billing/                   # SaaS billing
│   ├── tiers.py               # Subscription tiers
│   ├── subscription.py
│   ├── invoices.py
│   └── payments.py
│
├── channels/                  # Channel adapters
│   ├── whatsapp_bridge.py     # Python side
│   ├── whatsapp/server.js     # Node + Baileys
│   ├── instagram.py
│   ├── messenger.py
│   ├── tiktok.py
│   ├── webchat.py
│   ├── sms.py
│   └── email/                 # Gmail, Outlook, IMAP
│
├── tenants/                   # Multi-tenant
│   ├── schemas.py
│   ├── store.py
│   └── manager.py
│
├── telegram_bot/              # Control bot
│   ├── bot.py
│   └── handlers/
│       ├── admin_v2.py        # Full control commands
│       ├── add_wizard.py      # Onboarding wizard
│       └── broadcast.py
│
├── langgraph/                 # Multi-step workflows
│   ├── state.py
│   ├── router.py
│   └── workflows/
│       ├── restaurant.py      # Order taking
│       └── support.py         # Generic support
│
├── security/                  # Auth + RBAC
│   ├── jwt_handler.py
│   ├── passwords.py
│   ├── api_keys.py
│   ├── rbac.py
│   ├── audit.py
│   └── rate_limit.py
│
├── monitoring/                # Observability
│   ├── metrics.py             # Prometheus
│   ├── health.py              # Health checks
│   └── alerts.py              # Telegram alerts
│
├── api/                       # API routes
├── deployment/                # Deployment configs
│   ├── render.yaml
│   ├── railway.toml
│   ├── fly.toml
│   ├── prometheus.yml
│   ├── free_servers.md
│   └── failover.md
│
├── scripts/                   # CLI + workers
│   ├── onboard.py
│   ├── failover.py
│   ├── health.py
│   └── worker.py              # Background tasks
│
├── tests/                     # Tests
├── docs/                      # Documentation
├── k8s/                       # Kubernetes manifests
│
├── app.py                     # FastAPI main entry
├── start.sh
├── Dockerfile
├── docker-compose.yml
├── .github/workflows/ci.yml   # CI/CD
├── requirements.txt
└── package.json
```

---

## 🚀 بداية سريعة (٥ دقائق)

### ١) المتطلبات
- Python 3.11+
- Node.js 18+
- Docker (اختياري، لكن موصى به)

### ٢) التحميل
```bash
git clone <repo> iraqi-agent
cd iraqi-agent
cp .env.example .env
nano .env   # أضف مفاتيحك (راجع docs/setup.md)
```

### ٣) المفاتيح المجانية المطلوبة

| الخدمة | الرابط | الاستخدام |
|--------|--------|----------|
| Groq | [console.groq.com](https://console.groq.com) | LLM primary |
| Google AI | [aistudio.google.com](https://aistudio.google.com) | LLM backup + embeddings |
| OpenRouter | [openrouter.ai](https://openrouter.ai) | LLM free models |
| @BotFather | Telegram | Control bot |
| healthchecks.io | [healthchecks.io](https://healthchecks.io) | Self-monitoring |

### ٤) التشغيل المحلي
```bash
# الطريقة السريعة
pip install -r requirements.txt
npm install
bash start.sh

# أو Docker
docker compose up -d
```

### ٥) افتح بوت تيليكرام، ابعث
```
/start
/dashboard
/add
```

---

## 📖 الوثائق

- [`docs/setup.md`](docs/setup.md) — إعداد مفصّل
- [`docs/channel_setup.md`](docs/channel_setup.md) — ربط كل قناة
- [`docs/iraqi_prompts.md`](docs/iraqi_prompts.md) — هندسة البرومبتات
- [`docs/monetization.md`](docs/monetization.md) — استراتيجية البيع
- [`docs/architecture.md`](docs/architecture.md) — المعمارية
- [`deployment/free_servers.md`](deployment/free_servers.md) — خوادم مجانية

---

## 🧪 الاختبارات
```bash
make test
```

## 🤝 المساهمة
Pull requests مرحب بها!

## 📜 الرخصة
MIT — استخدم، عدّل، بيع.

---

🇮🇶 **صُنع بحب للسوق العراقي والعربي**
