"""API package (FastAPI routes live in app.py)."""
