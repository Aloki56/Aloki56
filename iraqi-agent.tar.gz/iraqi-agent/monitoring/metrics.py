"""
monitoring/metrics.py
Prometheus metrics + middleware.
"""
from __future__ import annotations
import time
from prometheus_client import (
    Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST,
)
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware


# ---- Counters ----
MESSAGES_TOTAL = Counter(
    "iraqi_agent_messages_total",
    "Total messages processed",
    ["tenant_id", "channel", "direction"],
)
LLM_REQUESTS = Counter(
    "iraqi_agent_llm_requests_total",
    "LLM API calls",
    ["provider", "result"],
)
LLM_LATENCY = Histogram(
    "iraqi_agent_llm_latency_seconds",
    "LLM latency",
    ["provider"],
    buckets=(0.1, 0.25, 0.5, 1, 2, 3, 5, 10, 20),
)
TENANT_BILLING = Counter(
    "iraqi_agent_billing_iqd_total",
    "Revenue (IQD) by tier",
    ["tier"],
)
ACTIVE_TENANTS = Gauge(
    "iraqi_agent_active_tenants",
    "Currently active tenants",
)
CHANNELS_UP = Gauge(
    "iraqi_agent_channels_up",
    "Channels up (1=yes)",
    ["channel"],
)


class Metrics:
    def __init__(self):
        self.messages_total = MESSAGES_TOTAL
        self.llm_requests = LLM_REQUESTS
        self.llm_latency = LLM_LATENCY
        self.tenant_billing = TENANT_BILLING
        self.active_tenants = ACTIVE_TENANTS
        self.channels_up = CHANNELS_UP

    def render(self) -> bytes:
        return generate_latest()


metrics = Metrics()


def record_message(tenant_id: str, channel: str, direction: str = "inbound"):
    MESSAGES_TOTAL.labels(tenant_id=tenant_id, channel=channel, direction=direction).inc()


class MetricsMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        t0 = time.time()
        response = await call_next(request)
        latency = time.time() - t0
        # Could add a histogram for HTTP latency here
        response.headers["X-Process-Time"] = f"{latency:.3f}"
        return response
