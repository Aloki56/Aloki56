"""
monitoring/alerts.py
Alert manager — sends alerts to Telegram when something goes wrong.
"""
from __future__ import annotations
import time
import asyncio
from typing import Optional
import httpx
from loguru import logger

from core.config import get_settings


class AlertManager:
    def __init__(self):
        self._cooldowns: dict[str, float] = {}
        self._cooldown_sec = 300  # 5 min

    async def alert(self, severity: str, title: str, body: str, key: Optional[str] = None):
        """Send an alert. Cooldown prevents spam on the same `key`."""
        k = key or f"{severity}:{title}"
        now = time.time()
        last = self._cooldowns.get(k, 0)
        if now - last < self._cooldown_sec:
            return
        self._cooldowns[k] = now
        msg = f"{'🚨' if severity=='critical' else '⚠️'} *{title}*\n\n{body}"
        logger.warning(f"ALERT: {msg}")
        await self._send_telegram(msg)
        await self._send_healthchecks_failure()

    async def _send_telegram(self, text: str):
        s = get_settings()
        if not (s.telegram_bot_token and s.admin_telegram_id):
            return
        try:
            async with httpx.AsyncClient(timeout=10) as c:
                await c.post(
                    f"https://api.telegram.org/bot{s.telegram_bot_token}/sendMessage",
                    json={"chat_id": s.admin_telegram_id, "text": text, "parse_mode": "Markdown"},
                )
        except Exception as e:
            logger.error(f"Alert Telegram send failed: {e!r}")

    async def _send_healthchecks_failure(self):
        s = get_settings()
        if s.ping_url:
            try:
                # Append /fail to signal failure
                url = s.ping_url.rstrip("/") + "/fail"
                async with httpx.AsyncClient(timeout=5) as c:
                    await c.get(url)
            except Exception:
                pass


_alert: AlertManager | None = None
def get_alert_manager() -> AlertManager:
    global _alert
    if _alert is None:
        _alert = AlertManager()
    return _alert
