"""
monitoring/health.py
Multi-component health checker.
"""
from __future__ import annotations
import time
import asyncio
from typing import Dict, List
from loguru import logger
import httpx

from core.config import get_settings
from core.models import get_router
from memory.manager import get_memory_manager
from tenants.store import get_store
from channels.manager import get_manager
from rag.pipeline import get_rag


class HealthChecker:
    async def check_all(self) -> Dict:
        s = get_settings()
        checks: Dict[str, Dict] = {}

        # App itself
        checks["app"] = {"status": "ok", "ts": time.time()}

        # LLM providers
        providers = []
        try:
            r = get_router()
            providers = [p.name for p in r.providers]
            checks["llm"] = {"status": "ok" if providers else "warn",
                              "providers": providers}
        except Exception as e:
            checks["llm"] = {"status": "error", "error": str(e)}

        # Storage
        try:
            tcount = len(get_store().list_all())
            checks["storage"] = {"status": "ok", "tenants": tcount}
        except Exception as e:
            checks["storage"] = {"status": "error", "error": str(e)}

        # Memory
        try:
            checks["memory"] = {"status": "ok", **get_memory_manager().stats()}
        except Exception as e:
            checks["memory"] = {"status": "error", "error": str(e)}

        # Channels
        mgr = get_manager()
        channels = {}
        for name in ["whatsapp", "instagram", "messenger", "tiktok", "webchat", "gmail", "sms"]:
            ad = mgr.get(name)
            channels[name] = ad.is_connected if ad else False
        checks["channels"] = {"status": "ok", "details": channels}

        # RAG
        try:
            rag = get_rag()
            checks["rag"] = {"status": "ok", "embeddings_model": rag.embedding.name}
        except Exception as e:
            checks["rag"] = {"status": "warn", "error": str(e)}

        # External ping (healthchecks.io)
        if s.ping_url:
            try:
                async with httpx.AsyncClient(timeout=5) as c:
                    await c.get(s.ping_url)
                checks["external_ping"] = {"status": "ok"}
            except Exception as e:
                checks["external_ping"] = {"status": "warn", "error": str(e)}

        # Overall
        statuses = [v.get("status") for v in checks.values()]
        if "error" in statuses:
            overall = "down"
        elif "warn" in statuses:
            overall = "degraded"
        else:
            overall = "ok"
        return {"overall": overall, "checks": checks, "ts": time.time()}
