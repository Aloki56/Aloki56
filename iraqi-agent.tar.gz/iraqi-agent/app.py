"""
app.py — Main entrypoint. Wires together:

  - FastAPI app (HTTP + WebSocket)
  - All channel adapters
  - Telegram control bot (background)
  - Memory system
  - RAG pipeline
  - Billing system
  - Monitoring / Prometheus
  - Background tasks (health checks, fail-over pings)

Run:
    uvicorn app:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations
import asyncio
import os
import time
import signal
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, HTTPException, WebSocket, Query
from fastapi.responses import JSONResponse, HTMLResponse, PlainTextResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from loguru import logger
import httpx

from core.config import get_settings
from core.agent import get_agent
from rag.pipeline import get_rag
from memory.manager import get_memory_manager
from tenants.store import get_store
from channels.manager import get_manager
from channels.whatsapp_bridge import WhatsAppBridge
from channels.instagram import InstagramAdapter
from channels.messenger import MessengerAdapter
from channels.tiktok import TikTokAdapter
from channels.webchat import WebChatAdapter, websocket_endpoint, WIDGET_JS
from channels.sms import SMSAdapter
from channels.email.gmail import GmailAdapter
from channels.email.outlook import OutlookAdapter
from channels.email.imap_smtp import IMAPAdapter
from telegram_bot.bot import build_bot
from monitoring.health import HealthChecker
from monitoring.metrics import metrics, MetricsMiddleware, record_message
from billing.subscription import get_subscription_manager
from billing.invoices import get_invoice_manager
from security.jwt_handler import issue_token, require_admin
from security.audit import get_audit
from security.rate_limit import limiter
from langgraph.router import get_router as get_workflow_router


# Logger setup
logger.remove()
logger.add(lambda msg: print(msg, end=""), level=get_settings().log_level, colorize=True)
logger.add(
    get_settings().log_file, rotation="10 MB", retention="7 days",
    level=get_settings().log_level, enqueue=True,
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup & shutdown."""
    s = get_settings()
    logger.info(f"🚀 Starting Iraqi Agent SaaS on {s.app_host}:{s.app_port}")

    # Channel adapters
    mgr = get_manager()
    mgr.register(WhatsAppBridge())
    mgr.register(InstagramAdapter())
    mgr.register(MessengerAdapter())
    mgr.register(TikTokAdapter())
    mgr.register(WebChatAdapter())
    mgr.register(SMSAdapter())
    mgr.register(GmailAdapter())
    mgr.register(OutlookAdapter())
    mgr.register(IMAPAdapter())
    await mgr.start_all()

    # Telegram control bot
    tg_app = None
    if s.telegram_bot_token:
        try:
            tg_app = build_bot()
            await tg_app.initialize()
            await tg_app.start()
            await tg_app.updater.start_polling(drop_pending_updates=True)
            logger.info("📲 Telegram control bot started")
        except Exception as e:
            logger.error(f"Telegram bot failed to start: {e!r}")

    # Background tasks
    monitor_task = asyncio.create_task(_health_loop())
    billing_task = asyncio.create_task(_billing_loop())
    ping_task = asyncio.create_task(_ping_loop())

    app.state.tg_app = tg_app
    try:
        yield
    finally:
        logger.info("Shutting down…")
        for t in (monitor_task, billing_task, ping_task):
            t.cancel()
        await mgr.stop_all()
        if tg_app:
            await tg_app.updater.stop()
            await tg_app.stop()
            await tg_app.shutdown()


async def _health_loop():
    while True:
        try:
            await asyncio.sleep(60)
            mgr = get_manager()
            from monitoring.metrics import CHANNELS_UP
            for name in ["whatsapp", "instagram", "messenger", "tiktok", "webchat", "sms", "gmail", "outlook", "imap_smtp"]:
                ad = mgr.get(name)
                if ad:
                    CHANNELS_UP.labels(channel=name).set(1 if ad.is_connected else 0)
        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.error(f"health loop: {e!r}")


async def _billing_loop():
    """Daily: check expired subscriptions and warn."""
    from monitoring.alerts import get_alert_manager
    while True:
        try:
            await asyncio.sleep(3600)  # hourly
            sm = get_subscription_manager()
            expiring = sm.list_expiring(3)
            for sub in expiring:
                if sub.tier != "trial":
                    await get_alert_manager().alert(
                        "warn",
                        f"اشتراك {sub.tenant_id} ينتهي قريباً",
                        f"الباقي: {sub.days_remaining()} يوم\nالباقة: {sub.current_tier().name_ar}",
                        key=f"expiring:{sub.tenant_id}",
                    )
        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.error(f"billing loop: {e!r}")


async def _ping_loop():
    s = get_settings()
    while True:
        try:
            await asyncio.sleep(s.health_check_interval)
            if s.ping_url:
                async with httpx.AsyncClient(timeout=10) as c:
                    await c.get(s.ping_url)
        except asyncio.CancelledError:
            break
        except Exception:
            pass


# ============================================================================
# FastAPI app
# ============================================================================
app = FastAPI(
    title="Iraqi Agent — SaaS Platform",
    description="Multi-tenant Iraqi-dialect AI agent for restaurants, cafés, shops, clinics.",
    version="2.0.0",
    lifespan=lifespan,
)

app.state.limiter = limiter
app.add_middleware(MetricsMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ======================== Health & Metrics ========================
@app.get("/")
async def root():
    return {
        "ok": True,
        "name": "Iraqi Agent SaaS",
        "version": "2.0.0",
        "tenants": len(get_store().list_all()),
        "docs": "/docs",
    }


@app.get("/health")
async def health():
    return await HealthChecker().check_all()


@app.get("/healthz")
async def healthz():
    """Liveness probe — no deep checks."""
    return {"ok": True, "ts": time.time()}


@app.get("/metrics")
async def prometheus_metrics():
    from fastapi.responses import Response
    return Response(content=metrics.render(), media_type="text/plain; version=0.0.4")


# ======================== Auth ========================
@app.post("/auth/login")
async def login(body: dict):
    """Issue a JWT for the platform admin.
    Replace with proper user store in production."""
    from security.passwords import verify_password
    from core.config import get_settings
    s = get_settings()
    username = body.get("username", "")
    password = body.get("password", "")
    # Demo: hard-coded — replace with a user table
    if username == "admin" and verify_password(password, "$2b$12$..."):
        token = issue_token("admin", role="admin", ttl_seconds=7 * 86400)
        return {"token": token}
    raise HTTPException(401, "Invalid credentials")


# ======================== Webhook: Meta (IG + Messenger) ========================
@app.get("/webhook/meta")
async def meta_verify(request: Request):
    s = get_settings()
    params = request.query_params
    if params.get("hub.mode") == "subscribe" and params.get("hub.verify_token") == s.meta_verify_token:
        return int(params.get("hub.challenge", 0))
    raise HTTPException(403, "verify failed")


@app.post("/webhook/meta")
async def meta_webhook(request: Request):
    body = await request.json()
    mgr = get_manager()
    obj = body.get("object")
    if obj == "instagram":
        ad = mgr.get("instagram")
        if ad:
            for entry in body.get("entry", []):
                await ad.handle_webhook_event({"entry": [entry]})
    elif obj == "page":
        ad = mgr.get("messenger")
        if ad:
            for entry in body.get("entry", []):
                await ad.handle_webhook_event({"entry": [entry]})
    return {"ok": True}


# ======================== Webchat Widget ========================
@app.get("/widget.js")
async def widget_js():
    return PlainTextResponse(content=WIDGET_JS, media_type="application/javascript")


@app.websocket("/ws/webchat/{tenant_id}")
async def ws_webchat(ws: WebSocket, tenant_id: str):
    await websocket_endpoint(ws, tenant_id)


# ======================== WhatsApp QR ========================
@app.get("/wa/qr")
async def wa_qr():
    s = get_settings()
    async with httpx.AsyncClient(timeout=10) as c:
        try:
            r = await c.get(f"{s.wa_bridge_http}/qr", headers={"x-auth": s.wa_bridge_auth})
            return r.json()
        except Exception as e:
            return {"error": str(e)}


@app.get("/wa/status")
async def wa_status():
    s = get_settings()
    async with httpx.AsyncClient(timeout=10) as c:
        try:
            r = await c.get(f"{s.wa_bridge_http}/status", headers={"x-auth": s.wa_bridge_auth})
            return r.json()
        except Exception as e:
            return {"error": str(e)}


# ======================== Direct chat (testing) ========================
@app.post("/chat")
async def chat(req: Request):
    body = await req.json()
    tid = body.get("tenant_id")
    text = body.get("message", "")
    if not tid or not text:
        raise HTTPException(400, "tenant_id and message required")
    t = get_store().get(tid)
    if not t:
        raise HTTPException(404, "tenant not found")
    # RAG retrieval
    rag = get_rag()
    kb_hits = rag.query(tid, text, top_k=4)
    # Memory
    mm = get_memory_manager()
    history = mm.context_for_llm(tid, body.get("channel", "web"), body.get("user_id", "anon"))
    facts = mm.long_term_facts(tid, body.get("user_id", "anon"))
    # Run workflow
    wf = get_workflow_router()
    result = await wf.run(
        tenant=t.to_storage(),
        channel=body.get("channel", "web"),
        user_id=body.get("user_id", "anon"),
        user_message=text,
        history=history,
        intent=[],
        kb_hits=[h.model_dump() for h in kb_hits],
        customer_facts=facts,
    )
    reply = result.get("reply", "")
    # Record
    mm.record_turn(tid, body.get("channel", "web"), body.get("user_id", "anon"), text, reply)
    record_message(tid, body.get("channel", "web"), "inbound")
    record_message(tid, body.get("channel", "web"), "outbound")
    return {
        "text": reply,
        "workflow": result.get("workflow"),
        "intent": result.get("intent"),
        "escalate": result.get("escalate_to_human"),
        "metadata": result.get("metadata", {}),
    }


# ======================== Tenant admin API (for web dashboard) ========================
@app.get("/api/admin/tenants")
async def list_tenants():
    """Platform-admin endpoint."""
    from security.jwt_handler import verify_token
    # For simplicity we accept any JWT issued by /auth/login
    return [t.to_storage() for t in get_store().list_all()]


@app.get("/api/admin/tenants/{tid}")
async def get_tenant_admin(tid: str):
    t = get_store().get(tid)
    if not t:
        raise HTTPException(404)
    sub = get_subscription_manager().get(tid).model_dump()
    return {**t.to_storage(), "subscription": sub}


# ======================== KB upload via HTTP ========================
@app.post("/api/kb/upload/{tenant_id}")
async def upload_kb(tenant_id: str, request: Request):
    """Upload a file as KB for a tenant.
    Form: file=@menu.pdf  OR  text=...
    """
    if not get_store().get(tenant_id):
        raise HTTPException(404, "tenant not found")
    form = await request.form()
    if "file" in form:
        f = form["file"]
        path = f"./data/uploads/{tenant_id}_{int(time.time())}_{f.filename}"
        os.makedirs(os.path.dirname(path), exist_ok=True)
        content = await f.read()
        with open(path, "wb") as out:
            out.write(content)
        n = get_rag().ingest_file(tenant_id, path)
        get_audit().log(actor="http", action="kb.upload", target=tenant_id,
                        details={"file": f.filename, "chunks": n})
        return {"ok": True, "chunks": n}
    elif "text" in form:
        n = get_rag().ingest_text(tenant_id, form["text"], source="http")
        return {"ok": True, "chunks": n}
    elif "url" in form:
        n = get_rag().ingest_url(tenant_id, form["url"])
        return {"ok": True, "chunks": n}
    raise HTTPException(400, "Provide 'file', 'text', or 'url'")


@app.get("/api/kb/stats/{tenant_id}")
async def kb_stats(tenant_id: str):
    return get_rag().stats(tenant_id)


# ======================== Tenant public endpoints (for widget) ========================
@app.get("/api/tenants/{tid}/public")
async def public_tenant(tid: str):
    """Public info about a tenant for the widget."""
    t = get_store().get(tid)
    if not t:
        raise HTTPException(404)
    return {
        "tenant_id": t.tenant_id,
        "business_name": t.business_name,
        "business_type": t.business_type,
        "working_hours": t.working_hours,
    }


if __name__ == "__main__":
    import uvicorn
    s = get_settings()
    uvicorn.run("app:app", host=s.app_host, port=s.app_port, reload=(s.app_env == "dev"))
