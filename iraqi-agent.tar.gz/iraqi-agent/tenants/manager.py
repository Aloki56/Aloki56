"""
tenants/manager.py
High-level operations: onboarding, channel linking, suspend, etc.
"""
from __future__ import annotations
from typing import Optional
from loguru import logger

from tenants.schemas import Tenant, ChannelConfig
from tenants.store import get_store


def create_tenant(
    tenant_id: str,
    business_name: str,
    owner_name: str,
    owner_phone: str,
    business_type: str = "مطعم",
    **kwargs,
) -> Tenant:
    """Create a new tenant. Raises ValueError if the id already exists."""
    store = get_store()
    if store.get(tenant_id):
        raise ValueError(f"Tenant '{tenant_id}' already exists")
    tenant = Tenant(
        tenant_id=tenant_id,
        business_name=business_name,
        business_type=business_type,
        owner_name=owner_name,
        owner_phone=owner_phone,
        **kwargs,
    )
    store.upsert(tenant)
    logger.info(f"✅ Created tenant {tenant_id} ({business_name})")
    return tenant


def link_whatsapp(tenant_id: str, phone_number: str):
    """Bind a WhatsApp phone number to a tenant."""
    store = get_store()
    t = store.get(tenant_id)
    if not t:
        raise ValueError("Tenant not found")
    t.channels.whatsapp_number = phone_number
    t.channels.enabled = True
    store.upsert(t)
    logger.info(f"📲 Linked WhatsApp {phone_number} → {tenant_id}")


def link_instagram(tenant_id: str, handle: str, business_id: str, page_token: str):
    store = get_store()
    t = store.get(tenant_id)
    if not t:
        raise ValueError("Tenant not found")
    t.channels.instagram_handle = handle
    t.channels.instagram_business_id = business_id
    t.channels.instagram_page_token = page_token
    t.channels.enabled = True
    store.upsert(t)
    logger.info(f"📷 Linked Instagram @{handle} → {tenant_id}")


def link_messenger(tenant_id: str, page_id: str, page_token: str):
    store = get_store()
    t = store.get(tenant_id)
    if not t:
        raise ValueError("Tenant not found")
    t.channels.messenger_page_id = page_id
    t.channels.messenger_page_token = page_token
    t.channels.enabled = True
    store.upsert(t)
    logger.info(f"💬 Linked Messenger page {page_id} → {tenant_id}")


def link_tiktok(tenant_id: str, handle: str):
    store = get_store()
    t = store.get(tenant_id)
    if not t:
        raise ValueError("Tenant not found")
    t.channels.tiktok_handle = handle
    t.channels.enabled = True
    store.upsert(t)
    logger.info(f"🎵 Linked TikTok @{handle} → {tenant_id}")


def suspend_tenant(tenant_id: str):
    get_store().set_status(tenant_id, "suspended")


def activate_tenant(tenant_id: str):
    get_store().set_status(tenant_id, "active")


def update_knowledge_base(tenant_id: str, kb: str):
    store = get_store()
    t = store.get(tenant_id)
    if not t:
        raise ValueError("Tenant not found")
    t.knowledge_base = kb
    store.upsert(t)


def update_monthly_fee(tenant_id: str, iqd: int):
    store = get_store()
    t = store.get(tenant_id)
    if not t:
        raise ValueError("Tenant not found")
    t.monthly_fee_iqd = iqd
    store.upsert(t)
