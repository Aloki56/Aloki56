"""
tenants/schemas.py
Pydantic models for tenant configuration.
"""
from __future__ import annotations
from datetime import datetime
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field, field_validator
import re


class ChannelConfig(BaseModel):
    """How a tenant is connected to one messaging channel."""
    enabled: bool = False
    # WhatsApp
    whatsapp_number: Optional[str] = None
    # Instagram
    instagram_business_id: Optional[str] = None
    instagram_page_token: Optional[str] = None
    instagram_handle: Optional[str] = None
    # Messenger
    messenger_page_id: Optional[str] = None
    messenger_page_token: Optional[str] = None
    # TikTok
    tiktok_handle: Optional[str] = None


class Tenant(BaseModel):
    tenant_id: str = Field(..., min_length=3, max_length=64)
    business_name: str
    business_type: str = "مطعم"  # مطعم، كافيه، كوفي شوب، حلويات...
    owner_name: str
    owner_phone: str
    phone: str = ""               # business public phone
    address: str = ""
    working_hours: str = "يومياً ١٠ ص - ١١ م"
    branches: str = "الفرع الرئيسي فقط"
    knowledge_base: str = ""
    channels: ChannelConfig = Field(default_factory=ChannelConfig)
    monthly_fee_iqd: int = 50000  # default 50k IQD / month
    status: str = "active"        # active | suspended | trial
    created_at: datetime = Field(default_factory=datetime.utcnow)
    notes: str = ""

    @field_validator("tenant_id")
    @classmethod
    def tenant_id_alnum(cls, v):
        if not re.match(r"^[a-z0-9_-]{3,64}$", v):
            raise ValueError("tenant_id must be lowercase, 3-64 chars, [a-z0-9_-]")
        return v

    def to_storage(self) -> Dict[str, Any]:
        d = self.model_dump()
        d["created_at"] = self.created_at.isoformat()
        return d

    @classmethod
    def from_storage(cls, d: Dict[str, Any]) -> "Tenant":
        d = dict(d)
        if isinstance(d.get("created_at"), str):
            d["created_at"] = datetime.fromisoformat(d["created_at"])
        return cls(**d)
