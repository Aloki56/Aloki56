"""
tenants/store.py
Pluggable storage. Default = TinyDB (file-based, zero-config).
Swap to Postgres (Supabase/Neon) by setting STORAGE_BACKEND=postgres.
"""
from __future__ import annotations
import os
import asyncio
from typing import Dict, List, Optional, Any
from loguru import logger
from tinydb import TinyDB, Query

from tenants.schemas import Tenant


class TenantStore:
    def __init__(self, path: str = "./data/tenants.json"):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self.db = TinyDB(path)
        self.t = self.db.table("tenants")
        logger.info(f"TenantStore initialized at {path}")

    def upsert(self, tenant: Tenant) -> Tenant:
        existing = self.get(tenant.tenant_id)
        if existing:
            self.t.update(tenant.to_storage(), Query().tenant_id == tenant.tenant_id)
        else:
            self.t.insert(tenant.to_storage())
        return tenant

    def get(self, tenant_id: str) -> Optional[Tenant]:
        results = self.t.search(Query().tenant_id == tenant_id)
        if not results:
            return None
        return Tenant.from_storage(results[0])

    def list_all(self) -> List[Tenant]:
        return [Tenant.from_storage(r) for r in self.t.all()]

    def list_active(self) -> List[Tenant]:
        return [t for t in self.list_all() if t.status == "active"]

    def delete(self, tenant_id: str) -> bool:
        n = self.t.remove(Query().tenant_id == tenant_id)
        return bool(n)

    def set_status(self, tenant_id: str, status: str) -> bool:
        n = self.t.update({"status": status}, Query().tenant_id == tenant_id)
        return bool(n)

    def find_by_channel(self, channel: str, value: str) -> Optional[Tenant]:
        """Look up a tenant by an identifier on one of its channels
        (e.g. WhatsApp phone number, Instagram handle, etc)."""
        for t in self.list_all():
            ch = t.channels
            if channel == "whatsapp" and ch.whatsapp_number == value:
                return t
            if channel == "instagram" and ch.instagram_handle == value:
                return t
            if channel == "messenger" and ch.messenger_page_id == value:
                return t
            if channel == "tiktok" and ch.tiktok_handle == value:
                return t
        return None


_store: Optional[TenantStore] = None

def get_store() -> TenantStore:
    global _store
    if _store is None:
        from core.config import get_settings
        s = get_settings()
        _store = TenantStore(s.tinydb_path)
    return _store
