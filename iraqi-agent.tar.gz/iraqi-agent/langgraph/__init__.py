"""
langgraph/__init__.py
Multi-step agent workflows using LangGraph.

Each workflow is a state machine:
  - routes messages through the right tool
  - tracks per-conversation state
  - calls the LLM only when needed
  - handles orders, complaints, reservations, FAQs
"""
from .state import AgentState
from .workflows.restaurant import build_restaurant_workflow
from .workflows.support import build_support_workflow
from .router import WorkflowRouter

__all__ = [
    "AgentState", "WorkflowRouter",
    "build_restaurant_workflow", "build_support_workflow",
]
