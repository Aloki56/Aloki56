"""
langgraph/workflows/restaurant.py
Multi-step restaurant workflow:
  1) Greet
  2) Classify intent (menu/order/reservation/complaint)
  3) Route to specialist node
  4) If multi-turn (e.g. order), collect fields (name, items, delivery, time)
  5) Confirm & write to "orders" store
  6) Hand off to a human if needed
"""
from __future__ import annotations
import time
from typing import Dict, Any
from loguru import logger

try:
    from langgraph.graph import StateGraph, END
    HAS_LG = True
except ImportError:
    HAS_LG = False
    StateGraph = None
    END = "__end__"

from ..state import AgentState


# ---------------- Nodes ----------------
async def greet_node(state: AgentState) -> AgentState:
    state["current_node"] = "greet"
    # The actual greeting is in the prompt; here we just route
    return state


async def classify_node(state: AgentState) -> AgentState:
    msg = state["user_message"]
    intents = state.get("intent") or []
    state["current_node"] = "classify"
    if not intents:
        # Lazy-import to avoid hard dep cycle
        from core.iraqi import detect_intent
        intents = detect_intent(msg)
        state["intent"] = intents
    return state


async def menu_node(state: AgentState) -> AgentState:
    state["current_node"] = "menu"
    # The reply is generated in the synthesis step
    return state


async def order_collect_node(state: AgentState) -> AgentState:
    """Try to extract order details, ask for missing fields."""
    state["current_node"] = "order_collect"
    msg = state["user_message"]
    # Light regex extraction (free). Heavy NLU in the LLM node.
    import re
    items = re.findall(r"(كباب|برياني|دجاج|سمك|برجر|شاورما|بيتزا|كنافة|قهوة|شاي)", msg)
    if items:
        state["collected"]["items"] = list(set(items))
    phone_match = re.search(r"(\+?9647[0-9]{9}|07[0-9]{9})", msg)
    if phone_match:
        state["collected"]["phone"] = phone_match.group(0)
    if any(w in msg for w in ["ديليفري", "توصيل", "يوصل"]):
        state["collected"]["delivery"] = True
    elif any(w in msg for w in ["استلام", "آخذ", "بس آخذه"]):
        state["collected"]["delivery"] = False
    # What's still missing?
    missing = []
    if "items" not in state["collected"]:
        missing.append("الصنف")
    if state["collected"].get("delivery") and "phone" not in state["collected"]:
        missing.append("رقم الهاتف للتوصيل")
    if "name" not in state["collected"]:
        missing.append("الاسم")
    state["metadata"]["missing_fields"] = missing
    return state


async def reservation_collect_node(state: AgentState) -> AgentState:
    state["current_node"] = "reservation_collect"
    import re
    msg = state["user_message"]
    m = re.search(r"(\d{1,2})\s*(شخص|نفر)", msg)
    if m:
        state["collected"]["party_size"] = int(m.group(1))
    m = re.search(r"(الساعة|بـ|في)\s*(\d{1,2})", msg)
    if m:
        state["collected"]["time"] = m.group(2)
    m = re.search(r"(اليوم|بكرة|غدا|غداً|الأحد|الإثنين|الثلاثاء|الأربعاء|الخميس|الجمعة|السبت)", msg)
    if m:
        state["collected"]["date"] = m.group(1)
    missing = []
    if "date" not in state["collected"]: missing.append("اليوم")
    if "time" not in state["collected"]: missing.append("الساعة")
    if "party_size" not in state["collected"]: missing.append("عدد الأشخاص")
    state["metadata"]["missing_fields"] = missing
    return state


async def complaint_node(state: AgentState) -> AgentState:
    state["current_node"] = "complaint"
    state["escalate_to_human"] = True
    return state


async def llm_synthesize_node(state: AgentState) -> AgentState:
    """Call the LLM to produce the user-facing reply."""
    state["current_node"] = "synthesize"
    from core.agent import get_agent
    from core.prompts import build_system_prompt
    # Get tenant from a side-channel (state has only the dict we passed)
    tenant = {"tenant_id": state["tenant_id"]}  # minimal; the LLM will pick up from history
    # Pull the full tenant from store
    from tenants.store import get_store
    full_tenant = get_store().get(state["tenant_id"])
    if full_tenant:
        tenant = full_tenant.to_storage()
    system_prompt = build_system_prompt(tenant)
    # Add workflow context
    if state.get("current_node") == "order_collect":
        system_prompt += "\n\n## السياق: الزبون يريد يطلب. الحقول اللي تم جمعها: " + \
                         str(state.get("collected", {})) + \
                         "\nإذا ناقص شي، اسأل بأدب."
    if state.get("current_node") == "reservation_collect":
        system_prompt += "\n\n## السياق: الزبون يريد يحجز. الحقول: " + \
                         str(state.get("collected", {})) + \
                         "\nإذا ناقص، اسأل."
    if state.get("current_node") == "complaint":
        system_prompt += "\n\n## السياق: الزبون عنده شكوى. اعتذر بصدق، گول راح أوصّلها للمسؤول."
    if state.get("kb_hits"):
        from rag.pipeline import RAGPipeline
        system_prompt += "\n\n" + RAGPipeline.format_for_prompt(state["kb_hits"])
    if state.get("customer_facts"):
        system_prompt += "\n\n" + state["customer_facts"]

    # Build messages
    messages = [{"role": "system", "content": system_prompt}]
    messages.extend(state.get("history") or [])
    messages.append({"role": "user", "content": state["user_message"]})

    # Reuse the agent's LLM router
    agent = get_agent()
    try:
        result = await agent.router.chat(messages, max_tokens=400, temperature=0.7)
        state["reply"] = result["text"]
        state["metadata"]["provider"] = result["provider"]
        state["metadata"]["latency_ms"] = result["latency_ms"]
    except Exception as e:
        logger.error(f"LLM call in workflow failed: {e!r}")
        state["reply"] = "عيني، عندي مشكلة فنية بسيطة. حاول مرة ثانية 🙏"
    return state


# ---------------- Routing ----------------
def _route_after_classify(state: AgentState) -> str:
    intents = state.get("intent") or []
    if "complaint" in intents:
        return "complaint"
    if "reservation" in intents:
        return "reservation_collect"
    if "order" in intents:
        return "order_collect"
    if "menu" in intents or "price" in intents:
        return "menu"
    return "synthesize"


def build_restaurant_workflow():
    if not HAS_LG:
        logger.warning("langgraph not installed; restaurant workflow falls back to direct LLM")
        # Return a simple callable that just runs the synthesize step
        class _DummyCompiled:
            async def ainvoke(self, state):
                return await llm_synthesize_node({**state, "current_node": "synthesize"})
        return _DummyCompiled()

    g = StateGraph(AgentState)
    g.add_node("greet", greet_node)
    g.add_node("classify", classify_node)
    g.add_node("menu", menu_node)
    g.add_node("order_collect", order_collect_node)
    g.add_node("reservation_collect", reservation_collect_node)
    g.add_node("complaint", complaint_node)
    g.add_node("synthesize", llm_synthesize_node)

    g.set_entry_point("greet")
    g.add_edge("greet", "classify")
    g.add_conditional_edges(
        "classify",
        _route_after_classify,
        {
            "menu": "menu",
            "order_collect": "order_collect",
            "reservation_collect": "reservation_collect",
            "complaint": "complaint",
            "synthesize": "synthesize",
        },
    )
    g.add_edge("menu", "synthesize")
    g.add_edge("order_collect", "synthesize")
    g.add_edge("reservation_collect", "synthesize")
    g.add_edge("complaint", "synthesize")
    g.add_edge("synthesize", END)
    return g.compile()
