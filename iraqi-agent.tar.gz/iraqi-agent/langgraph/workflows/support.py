"""
langgraph/workflows/support.py
Generic support workflow — used as a fallback for non-restaurant
businesses. Always uses the LLM to respond; just adds sentiment
analysis to escalate unhappy customers to a human.
"""
from __future__ import annotations
import re
from loguru import logger

try:
    from langgraph.graph import StateGraph, END
    HAS_LG = True
except ImportError:
    HAS_LG = False
    StateGraph = None
    END = "__end__"

from ..state import AgentState


SAD_WORDS = [
    "زعلان", "متضايق", "سيء", "سيئة", "خربان", "خربانة", "ما طاب", "ما عجبني",
    "أريد أشگو", "مشكلة", "تأخر", "بارد", "أبداً", "never", "bad", "angry",
]


def detect_sentiment_ar(text: str) -> str:
    t = text or ""
    if any(w in t for w in SAD_WORDS):
        return "negative"
    if any(w in t for w in ["مرحبا", "شكرا", "مشكور", "خوش", "زين", "حلو", "عجبني"]):
        return "positive"
    return "neutral"


async def analyze_node(state: AgentState) -> AgentState:
    state["current_node"] = "analyze"
    state["metadata"]["sentiment"] = detect_sentiment_ar(state.get("user_message", ""))
    if state["metadata"]["sentiment"] == "negative":
        state["escalate_to_human"] = True
    return state


async def respond_node(state: AgentState) -> AgentState:
    state["current_node"] = "respond"
    from core.prompts import build_system_prompt
    from core.agent import get_agent
    from tenants.store import get_store

    full_tenant = get_store().get(state["tenant_id"])
    tenant_dict = full_tenant.to_storage() if full_tenant else {"tenant_id": state["tenant_id"]}
    system = build_system_prompt(tenant_dict)
    if state.get("metadata", {}).get("sentiment") == "negative":
        system += "\n\n⚠️ الزبون زعلان. اعتذر بصدق، گول راح أوصّل الشكوى للمسؤول."
    if state.get("kb_hits"):
        from rag.pipeline import RAGPipeline
        system += "\n\n" + RAGPipeline.format_for_prompt(state["kb_hits"])
    if state.get("customer_facts"):
        system += "\n\n" + state["customer_facts"]

    msgs = [{"role": "system", "content": system}]
    msgs.extend(state.get("history") or [])
    msgs.append({"role": "user", "content": state["user_message"]})

    agent = get_agent()
    try:
        r = await agent.router.chat(msgs, max_tokens=400, temperature=0.7)
        state["reply"] = r["text"]
    except Exception as e:
        logger.error(f"Support LLM call failed: {e!r}")
        state["reply"] = "عيني، مشكلة فنية بسيطة. حاول بعد دقيقة 🙏"
    return state


def build_support_workflow():
    if not HAS_LG:
        class _DummyCompiled:
            async def ainvoke(self, state):
                return await respond_node(await analyze_node(state))
        return _DummyCompiled()

    g = StateGraph(AgentState)
    g.add_node("analyze", analyze_node)
    g.add_node("respond", respond_node)
    g.set_entry_point("analyze")
    g.add_edge("analyze", "respond")
    g.add_edge("respond", END)
    return g.compile()
