"""
langgraph/state.py
The state object passed through every node of every workflow.
"""
from __future__ import annotations
import time
from typing import Dict, Any, List, Optional
from pydantic import BaseModel, Field
from typing_extensions import TypedDict


class AgentState(TypedDict, total=False):
    # Identity
    tenant_id: str
    channel: str
    user_id: str
    user_name: Optional[str]

    # Conversation
    user_message: str
    history: List[Dict[str, str]]
    intent: List[str]

    # Retrieved context
    kb_hits: List[Dict[str, Any]]
    customer_facts: str

    # Workflow state
    workflow: str             # restaurant | support | general
    current_node: str
    collected: Dict[str, Any] # e.g. {"name": "...", "phone": "..."}
    awaiting_field: Optional[str]

    # Output
    reply: str
    tool_calls: List[Dict[str, Any]]
    escalate_to_human: bool
    metadata: Dict[str, Any]


def empty_state(tenant_id: str, channel: str, user_id: str) -> AgentState:
    return AgentState(
        tenant_id=tenant_id,
        channel=channel,
        user_id=user_id,
        user_message="",
        history=[],
        intent=[],
        kb_hits=[],
        customer_facts="",
        workflow="general",
        current_node="start",
        collected={},
        awaiting_field=None,
        reply="",
        tool_calls=[],
        escalate_to_human=False,
        metadata={"ts": time.time()},
    )
