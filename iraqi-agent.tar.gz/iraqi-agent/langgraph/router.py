"""
langgraph/router.py
Picks the right workflow for a tenant (or a message), executes it,
returns the final reply.
"""
from __future__ import annotations
from typing import Dict, Optional
from loguru import logger

from .state import AgentState, empty_state
from .workflows.restaurant import build_restaurant_workflow
from .workflows.support import build_support_workflow


WORKFLOWS = {
    "restaurant": build_restaurant_workflow,
    "cafe":       build_restaurant_workflow,
    "support":    build_support_workflow,
    "general":    build_support_workflow,
}


class WorkflowRouter:
    def __init__(self):
        self._compiled: Dict[str, any] = {}

    def _get(self, workflow: str):
        if workflow not in self._compiled:
            builder = WORKFLOWS.get(workflow, build_support_workflow)
            self._compiled[workflow] = builder()
        return self._compiled[workflow]

    async def run(self, tenant: dict, channel: str, user_id: str,
                  user_message: str, history: list, intent: list,
                  kb_hits: list, customer_facts: str) -> AgentState:
        # Pick workflow from tenant.business_type
        wf = tenant.get("business_type", "general")
        wf = "restaurant" if wf in ("مطعم", "كافيه", "حلويات", "بقالة") else wf
        wf = wf if wf in WORKFLOWS else "support"

        state = empty_state(tenant["tenant_id"], channel, user_id)
        state["user_message"] = user_message
        state["history"] = history
        state["intent"] = intent
        state["kb_hits"] = kb_hits
        state["customer_facts"] = customer_facts
        state["workflow"] = wf
        state["tenant_business_name"] = tenant.get("business_name", "")
        state["tenant_business_type"] = tenant.get("business_type", "")

        compiled = self._get(wf)
        try:
            result = await compiled.ainvoke(state)
        except Exception as e:
            logger.error(f"Workflow {wf} failed: {e!r}")
            result = dict(state)
            result["reply"] = "عيني صار عندي مشكلة بسيطة. حاول مرة ثانية وراح أردلك بأسرع وقت 🙏"
        return result


_router: Optional[WorkflowRouter] = None
def get_router() -> WorkflowRouter:
    global _router
    if _router is None:
        _router = WorkflowRouter()
    return _router
