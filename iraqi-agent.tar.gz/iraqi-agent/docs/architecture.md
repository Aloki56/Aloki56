# 🏗 المعمارية الكاملة (Architecture)

> شرح تقني مفصّل لكل طبقة في النظام.

---

## 1. نظرة عامة

منصة **Iraqi Agent** هي نظام Multi-Tenant SaaS مبني على:

- **Backend**: Python 3.11 + FastAPI (async)
- **Frontend** (للوحة التحكم): Telegram Bot
- **Database**: PostgreSQL (relational) + Qdrant (vector) + Redis (cache)
- **Storage**: MinIO / S3 (files, backups)
- **Orchestration**: LangGraph (multi-step workflows)
- **LLM**: Multi-provider with auto-fallback
- **Observability**: Prometheus + Grafana + loguru
- **Deployment**: Docker / Kubernetes / Fly.io

---

## 2. طبقات النظام

### 2.1 طبقة الـ Agent (`core/`)

```
core/
├── agent.py          # الـ Orchestrator الرئيسي
├── models.py         # LLM Router (5 providers)
├── prompts.py        # Iraqi System Prompt
├── iraqi.py          # أدوات اللهجة
├── memory.py         # Memory in-process (legacy)
└── config.py         # Settings (pydantic-settings)
```

**`Agent.reply()`** يستلم:
- `tenant` — بيانات المشروع
- `user_message` — رسالة الزبون
- `channel` — من وين جت
- `user_id` — معرف الزبون

**يشتغل:**
1. يبني system prompt ديناميكياً (مع KB)
2. يجيب الـ history من memory
3. يصنّف الـ intent
4. يستدعي LLM Router
5. يضيف flavor عراقي
6. يخزّن في memory

### 2.2 طبقة الـ RAG (`rag/`)

```
rag/
├── loaders/         # استخراج النص من الملفات
│   ├── pdf_loader.py
│   ├── docx_loader.py
│   ├── xlsx_loader.py
│   ├── csv_loader.py
│   ├── text_loader.py
│   ├── url_loader.py
│   ├── google_sheets.py
│   └── facebook_loader.py
├── chunkers/
│   └── text_splitter.py    # Arabic-aware chunker
├── embeddings/
│   ├── local.py            # sentence-transformers (مجاني)
│   └── google.py           # Gemini embeddings
├── retrievers/
│   ├── vector_store.py     # Qdrant wrapper
│   └── hybrid.py           # vector + BM25 with RRF
└── pipeline.py             # End-to-end
```

**التدفق:**
1. ملف/رابط → Loader → Document(s)
2. Documents → Chunker → Chunks
3. Chunks → Embedding → Vectors
4. Vectors + Payloads → Qdrant
5. Chunks + Tokens → BM25 index
6. Query → Vector search + BM25 → RRF merge → Top-K

### 2.3 طبقة الـ Memory (`memory/`)

أربع طبقات:

| الطبقة | المدة | المكان | الاستخدام |
|--------|------|--------|-----------|
| ShortTerm | ٦ ساعات | Redis / in-process | buffer للـ LLM |
| LongTerm | دائم | PostgreSQL | حقائق عن الزبون |
| Conversation | دائم | PostgreSQL | أرشيف كل المحادثات |
| Customer | دائم | PostgreSQL | profile + history |

### 2.4 طبقة القنوات (`channels/`)

كل قناة adapter يلتزم بـ `ChannelAdapter` interface:

```python
class ChannelAdapter(ABC):
    name: str
    async def start()
    async def stop()
    async def send(recipient_id, text, **kwargs)
    @property
    def is_connected -> bool
```

**القنوات المدعومة:**
- WhatsApp (Baileys Node bridge → Python WS)
- Instagram (Meta Graph webhook)
- Messenger (Meta Graph webhook)
- TikTok (Business API webhook)
- Web Chat (WebSocket + JS widget)
- Email (Gmail API, Outlook Graph, IMAP/SMTP)
- SMS (Twilio / custom HTTP)

### 2.5 طبقة الـ Workflows (`langgraph/`)

State machine متعددة الخطوات:

```
START → greet → classify → [menu | order_collect | reservation_collect | complaint | synthesize] → END
```

- **`restaurant.py`**: workflow خاص بالمطاعم
- **`support.py`**: workflow عام (support)
- **`router.py`**: يختار الـ workflow حسب نوع المشروع

### 2.6 طبقة الأمان (`security/`)

- **JWT** (`jwt_handler.py`): إصدار/تحقق tokens
- **Passwords** (`passwords.py`): bcrypt
- **API Keys** (`api_keys.py`): per-tenant
- **RBAC** (`rbac.py`): ٥ أدوار، ١٤ صلاحية
- **Rate Limiting** (`rate_limit.py`): slowapi
- **Audit** (`audit.py`): JSON log لكل عملية privileged

### 2.7 طبقة الإدارة من تليكرام (`telegram_bot/`)

- **`bot.py`**: يبني الـ Application
- **`handlers/admin_v2.py`**: ٣٠+ أمر إداري
- **`handlers/add_wizard.py`**: معالج إضافة مشروع
- **`handlers/broadcast.py`**: بث رسائل

**الأوامر الرئيسية:**
- `/dashboard` — لوحة معلومات
- `/tenants` — قائمة المشاريع
- `/add` — إضافة مشروع
- `/upload <id>` — رفع KB
- `/invoice <id> <tier> <months>` — فاتورة
- `/broadcast <id> <نص>` — بث
- `/stats`, `/monitoring`, `/audit`

### 2.8 طبقة الـ Billing (`billing/`)

- **`tiers.py`**: ٤ باقات (تجربة، أساسي، احترافي، مؤسسي)
- **`subscription.py`**: حالة الاشتراك لكل tenant
- **`invoices.py``: إصدار فواتير بـ IQD
- **`payments.py`**: تسجيل الدفع (زين كاش / فاست باي / FIB)

### 2.9 طبقة المراقبة (`monitoring/`)

- **`metrics.py`**: Prometheus counters/gauges/histograms
- **`health.py`**: فحص شامل لكل المكونات
- **`alerts.py`**: تنبيهات تليكرام

---

## 3. تدفّق الرسالة (Message Flow)

### 3.1 واردة من واتساب
```
1. User → WhatsApp
2. Baileys (Node) يستقبل
3. WebSocket event → channels/whatsapp_bridge.py
4. ChannelManager.handle_inbound(channel="whatsapp", user_id, text)
5. TenantStore.find_by_channel() يحدد المشروع
6. Agent.reply():
   a) RAG query → KB hits
   b) MemoryManager.context_for_llm() → history
   c) LongTermMemory facts → customer_facts
   d) WorkflowRouter.run() → multi-step workflow
   e) LLM Router → Groq/Google/etc
   f) Post-process (Iraqi flavor)
   g) MemoryManager.record_turn()
7. WhatsAppBridge.send() → Baileys → User
8. Monitoring.record_message()
```

### 3.2 واردة من إنستكرام
```
1. User → Instagram DM
2. Meta → POST /webhook/meta
3. InstagramAdapter.handle_webhook_event()
4. find tenant by IG business ID
5. (same as WhatsApp from step 5)
6. Send via Meta Graph API
```

### 3.3 واردة من بوت تليكرام (admin)
```
1. Admin → /add
2. add_wizard (ConversationHandler)
3. Step-by-step questions
4. tenants.manager.create_tenant()
5. Audit log entry
6. Confirmation message
```

### 3.4 سؤال مع KB (RAG)
```
1. User: "بكم الكباب؟"
2. Intent detection → ["menu", "price"]
3. RAG query → top-5 KB chunks
4. LLM receives:
   - System prompt (persona + business info)
   - KB hits (formatted)
   - Conversation history
   - Customer facts
   - User message
5. LLM response
6. Memory recorded
```

---

## 4. Multi-Tenancy

### 4.1 عزل البيانات
- **Tenants**: كل واحد له `tenant_id` فريد
- **KB**: مجموعة منفصلة في Qdrant (`kb_<tenant_id>`)
- **Memory**: مفاتيح بـ `(tenant_id, channel, user_id)`
- **Billing**: subscription خاصة
- **API keys**: per-tenant

### 4.2 Row-Level Security
في PostgreSQL، كل استعلام يفلتر بـ `tenant_id`. الـ API ما يگدر يجيب بيانات tenant غير تبعه.

### 4.3 Tenant Limits
من الباقة:
- max channels
- max monthly messages
- max KB chunks
- concurrent agents

عند التجاوز → تنبيه + auto-suspend (اختياري).

---

## 5. LLM Fallback Strategy

```
Request → Router
            ↓
    ┌───────┴───────┬──────────┬──────────┬──────────┐
    ▼               ▼          ▼          ▼          ▼
  Groq           Google    OpenRouter  Together    HF
 (primary)      (backup 1) (backup 2) (backup 3) (backup 4)
    │               │          │          │          │
    └───────────────┴──────────┴──────────┴──────────┘
                ↓
         First success → return
         All fail → friendly error
```

**Retry policy**:
- Timeout: 30s
- Retries: 0 (instant fallback to next provider)
- Rate-limit detection: 429 / 503 → skip immediately

---

## 6. Deployment Topology

### 6.1 Single-server (dev)
```
[1 VM with Docker Compose]
  ├─ API
  ├─ Worker
  ├─ Postgres
  ├─ Redis
  ├─ Qdrant
  └─ MinIO
```

### 6.2 Production (Fly.io)
```
[Fly.io region]
  ├─ API (FastAPI)
  ├─ Worker (background)
  └─ Volume (persistent data)

[External free services]
  ├─ Supabase (Postgres)
  ├─ Upstash (Redis)
  ├─ Qdrant Cloud (vectors)
  └─ Cloudflare (DNS + CDN)
```

### 6.3 Multi-server (HA)
```
[Fly.io primary]  ←── DNS
[Oracle backup]   ←── DNS

[Upstash Redis]   ←── leader election
[healthchecks.io] ←── alerting
```

راح يفشل Fly.io؟ Oracle ياخذ مكانه. يفشل الاثنين؟ healthchecks.io يرسلك تنبيه.

---

## 7. Scaling Strategy

| Scale | Approach |
|-------|----------|
| 1-10 tenants | Single VM, 256MB RAM |
| 10-100 | Fly.io (multi-region), 512MB |
| 100-1000 | K8s + horizontal scaling |
| 1000+ | Sharding by tenant_id across DBs |

**Bottlenecks & solutions:**
- LLM rate limits → multi-provider fallback
- DB writes → read replicas + caching
- Webhook storms → queue with Redis + worker
- KB search → Qdrant shards

---

## 8. Security Architecture

```
User Request
    ↓
Rate Limiter (slowapi)
    ↓
Auth Middleware (JWT)
    ↓
RBAC Check
    ↓
Tenant Isolation Filter
    ↓
Audit Log
    ↓
Handler
    ↓
Response
```

**Per-request headers:**
- `Authorization: Bearer <jwt>` (admin)
- `X-API-Key: ak_xxx` (tenant programmatic)
- `X-Webhook-Signature: <hmac>` (Meta, Telegram)

**Encryption:**
- At rest: AES-256 (database)
- In transit: TLS 1.3 (Let's Encrypt)
- Secrets: env vars (never in code)

---

## 9. Observability

### Logs
- `loguru` → stdout + `./logs/agent.log` (rotated 10MB)
- JSON-structured
- Levels: DEBUG, INFO, WARNING, ERROR

### Metrics (Prometheus)
- `iraqi_agent_messages_total{tenant, channel, direction}`
- `iraqi_agent_llm_requests_total{provider, result}`
- `iraqi_agent_llm_latency_seconds{provider}`
- `iraqi_agent_active_tenants`
- `iraqi_agent_channels_up{channel}`

### Health checks
- `GET /healthz` — liveness
- `GET /health` — readiness (checks all components)

### Alerts
- Telegram (immediate)
- Email (digest)
- PagerDuty (for enterprise tier)

---

## 10. Disaster Recovery

- **DB**: Daily backup to S3/MinIO
- **Tenant data**: Export to JSON
- **WhatsApp auth**: Backed up in `data/wa_auth/`
- **RAG indexes**: Persist in Qdrant
- **Disaster recovery RTO**: 5 min (redeploy from Docker image)

---

## 📊 ملخص الإحصائيات

| البند | القيمة |
|-------|--------|
| Languages | Python 3.11, Node.js 20, SQL, YAML |
| Lines of code | 8,000+ |
| Files | 80+ |
| LLM providers | 5 (auto-fallback) |
| Channels | 8 (WA, IG, FB, TT, Web, Email×3, SMS) |
| Memory tiers | 4 |
| Memory backends | in-process, Redis, PostgreSQL |
| Vector store | Qdrant + BM25 hybrid |
| Subsystem | 12 (core, RAG, channels, billing, ...) |
| Tests | 10+ |
| Documentation | 1,500+ lines |
| Total dependencies | 50+ (all open source) |
| Monthly cost (free tier) | $0 |

🇮🇶 **كلشي مفتوح المصدر، مجاني، ملكك.**
