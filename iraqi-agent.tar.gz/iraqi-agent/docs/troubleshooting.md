# 🔧 دليل استكشاف مشاكل البوت (Troubleshooting)

> البوت ما يرد؟ ابدأ من هنا. هذا الدليل يغطي **كل** الأسباب المحتملة مع الحل.

---

## 🎯 التشخيص السريع (٣٠ ثانية)

شغّل هذا الأمر — يگولك بالضبط وين المشكلة:

```bash
cd iraqi-agent
python scripts/run_bot.py --mode=check
```

راح يطبع:
- ✅ أو ❌ لكل فحص
- الحل المقترح لكل مشكلة

---

## 📋 Checklist الأسباب المحتملة

### ١) البوت ما اشتغل أصلاً ← **الأكثر احتمالاً!**

**الأعراض:**
- ما تشوف رد أبداً
- `getUpdates` يرجع رسايلك لكن ما تنعالج

**الحل:**
```bash
cd iraqi-agent
pip install -r requirements.txt
npm install

# جرّب البوت المصغّر أولاً (موصى به)
python scripts/minimal_bot.py

# لو اشتغل، شغّل الكامل
python app.py
# أو:
bash scripts/run_bot.py
```

**تحقق إنه شغّال:**
- لازم تشوف `Application started`
- لازم تشوف `getUpdates "HTTP/1.1 200 OK"`
- اضغط `Ctrl+C` يطبع `Bot stopped`

---

### ٢) Token غلط أو ملغي

**الأعراض:**
- `python scripts/diagnose_bot.py` يطبع `❌ Token غلط`
- أو `401 Unauthorized`

**الحل:**
1. روح [@BotFather](https://t.me/BotFather)
2. `/mybots` → اختار البوت → **API Token** → انسخ
3. حطه بالـ `.env`:
```
TELEGRAM_BOT_TOKEN=1234567890:ABCDefghIJKlmnoPQRsTUVwxyz
```
4. أعد التشغيل

---

### ٣) ADMIN_TELEGRAM_ID غلط

**الأعراض:**
- البوت يرد لكن يگول "⛔ هذا البوت خاص"
- أو يرد بـ "مو لك"

**الحل:**
1. أرسل `/whoami` للبوت
2. انسخ الـ ID المعروض
3. حطه بالـ `.env`:
```
ADMIN_TELEGRAM_ID=5243908842
```
4. أعد التشغيل

**أو خلّي أول واحد يبعت رسالة يصير admin تلقائياً** — احذف السطر من `.env`:
```bash
sed -i 's/ADMIN_TELEGRAM_ID=.*/ADMIN_TELEGRAM_ID=/' .env
```

---

### ٤) مكتبات Python ناقصة

**الأعراض:**
- `ModuleNotFoundError: No module named 'telegram'`
- أو أي module آخر

**الحل:**
```bash
# ثبّت كل شي
pip install -r requirements.txt

# أو ثبّت الحد الأدنى للبوت المصغّر
pip install python-telegram-bot python-dotenv
```

---

### ٥) Token مستخدم من instance ثاني

**الأعراض:**
- `python scripts/run_bot.py` يطبع "في bot ثاني شغّال"
- `getUpdates` يرجع `409 Conflict`

**الحل:**
```bash
# ابحث عن process ثاني يستخدم البوت
ps aux | grep -E "(python.*bot|node.*whatsapp)" | grep -v grep

# أوقفه
kill <PID>

# أو على Windows:
taskkill /F /IM python.exe
```

---

### ٦) Firewall/VPN يحجب Telegram

**الأعراض:**
- `diagnose_bot.py` يقول "ما گدرت أتصل بـ Telegram"
- خطأ SSL أو timeout

**الحل:**
- أطفئ VPN مؤقتاً
- تأكد إن المنفذ 443 مفتوح
- جرّب من شبكة ثانية

---

### ٧) الـ Bot في مجموعة مع Privacy Mode

**الأعراض:**
- البوت يرد بالخاص لكن ما يرد بالمجموعة
- ما يشوف الرسايل

**الحل:**
1. [@BotFather](https://t.me/BotFather) → `/mybots`
2. **Bot Settings** → **Group Privacy** → **Turn off**
3. أضف البوت للمجموعة كـ **admin**

---

## 🧪 أوامر التشخيص

### فحص شامل
```bash
python scripts/run_bot.py --mode=check
```

### تشخيص سريع
```bash
python scripts/diagnose_bot.py
```

### تشغيل البوت المصغّر (للتجربة)
```bash
python scripts/minimal_bot.py
```

### تشغيل الكامل
```bash
bash scripts/run_bot.py --mode=full
```

### شوف اللوقات
```bash
tail -f logs/agent.log
```

---

## 🔍 كيف تشخّص يدوياً

### ١) هل Token شغّال؟
```bash
curl "https://api.telegram.org/bot<TOKEN>/getMe"
```
يجب يرجع `{"ok": true, "result": {...}}`

### ٢) هل في رسايل معلقة؟
```bash
curl "https://api.telegram.org/bot<TOKEN>/getUpdates?limit=5"
```

### ٣) هل في webhook conflict؟
```bash
curl "https://api.telegram.org/bot<TOKEN>/getWebhookInfo"
# يجب: "url": "" (فاضي للـ polling)
```

### ٤) امسح الـ webhook إذا موجود
```bash
curl "https://api.telegram.org/bot<TOKEN>/deleteWebhook"
```

---

## 🛠 مشاكل محددة وحلولها

### المشكلة: `BadRequest: Can't parse entities`
**السبب:** Markdown فيه رمز `*` أو `_` غير مغلق

**الحل:** في `admin_v2.py` و `minimal_bot.py`، غيّر `parse_mode="Markdown"` إلى:
```python
parse_mode="HTML"  # أو احذفه
```

### المشكلة: `TimedOut: Pool timeout`
**السبب:** تستدعي `getUpdates` بنفس الوقت اللي البوت يستدعيها

**الحل:** لا تستخدم `getUpdates` يدوياً إذا البوت شغّال بـ polling

### المشكلة: `telegram.error.Unauthorized`
**السبب:** Token ملغي أو غلط

**الحل:** token جديد من @BotFather

### المشكلة: البوت يشتغل محلياً لكن ما يرد
**السبب:** ماكو webhook conflict، بس الـ process مات بـ silent crash

**الحل:** شغّل بـ `bash start.sh` وراقب اللوقات:
```bash
tail -f logs/agent.log
```

---

## 📞 لو كل شي فشل

1. **شغّل البوت المصغّر** للتأكد إن البيئة شغّالة:
   ```bash
   python scripts/minimal_bot.py
   ```
   أرسل `/ping`. إذا اشتغل = البيئة سليمة، المشكلة بالبوت الكامل.

2. **شوف اللوقات**:
   ```bash
   cat logs/agent.log | tail -50
   ```

3. **استنسخ الخطأ وأرسله إلي** مع:
   - إصدار Python: `python --version`
   - إصدار pip: `pip --version`
   - لوقات كاملة من `logs/agent.log`
   - رسالة الخطأ من `python scripts/run_bot.py --mode=check`

---

## 🎯 خطة الإصلاح السريعة

```bash
# خطوة ١: التشخيص
cd iraqi-agent
python scripts/run_bot.py --mode=check

# خطوة ٢: لو طلع مشاكل مكتبات
pip install -r requirements.txt

# خطوة ٣: لو طالع Token مشكلة
curl "https://api.telegram.org/bot$(grep TELEGRAM_BOT_TOKEN .env | cut -d= -f2)/getMe"

# خطوة ٤: جرّب البوت المصغّر
python scripts/minimal_bot.py
# أرسل /ping من تيليكرام
# إذا اشتغل = ممتاز، شغّل الكامل

# خطوة ٥: لو كل شي OK، شغّل الكامل
python scripts/run_bot.py
```

---

🇮🇶 **مهما كانت المشكلة، خطوة خطوة راح نحلّها!**
