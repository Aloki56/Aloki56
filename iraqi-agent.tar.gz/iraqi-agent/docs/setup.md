# 🚀 دليل الإعداد الكامل (بالعراقي)

هذا الدليل يأخذك من الصفر لمنصة كاملة شغّالة ٢٤/٧.

---

## المرحلة ١: المتطلبات

### على جهازك
- **Python 3.11+** — [python.org](https://python.org)
- **Node.js 18+** — [nodejs.org](https://nodejs.org)
- **Docker + Docker Compose** — [docker.com](https://docker.com) (للنشر)
- **Git** — [git-scm.com](https://git-scm.com)
- **حساب GitHub** — للنشر و CI/CD

### حسابات مجانية تحتاجها
| الخدمة | الغرض | الحد المجاني |
|--------|------|------------|
| [Groq](https://console.groq.com) | LLM primary | 30 req/min |
| [Google AI Studio](https://aistudio.google.com) | LLM + embeddings | 60 req/min |
| [OpenRouter](https://openrouter.ai) | LLM backup | 20 req/min |
| [Telegram @BotFather](https://t.me/BotFather) | Control bot | مفتوح |
| [healthchecks.io](https://healthchecks.io) | Self-monitoring | ٢٠ فحص |
| [Fly.io](https://fly.io) | Hosting | ٣ VMs مجانية |
| [Oracle Cloud](https://cloud.oracle.com) | Backup host | Always free ARM |
| [Upstash](https://upstash.com) | Redis مجاني | ١٠K req/day |
| [Qdrant Cloud](https://cloud.qdrant.io) | Vector store | ١GB مجاني |
| [Supabase](https://supabase.com) | Postgres | ٥٠٠ MB |

---

## المرحلة ٢: تجهيز API Keys

### أ) Groq (الموفر الأساسي) ⭐
1. روح [console.groq.com](https://console.groq.com) → سجّل بـ Google
2. **API Keys** → **Create API Key**
3. انسخ الـ Key، حطه في `.env`:
```
GROQ_API_KEY=gsk_xxxxxxxx
GROQ_MODEL=llama-3.3-70b-versatile
```
**مجاني**، سريع جداً ⚡، ممتاز بالعربي والعراقي.

### ب) Google AI Studio
1. [aistudio.google.com](https://aistudio.google.com) → **Get API Key**
```
GOOGLE_API_KEY=AIzaSy...
GOOGLE_MODEL=gemini-1.5-flash
```
**مجاني**، ٦٠ طلب/دقيقة، جيد جداً.

### ج) OpenRouter (موديلات :free)
1. [openrouter.ai](https://openrouter.ai) → سجّل
2. **Keys** → **Create**
```
OPENROUTER_API_KEY=sk-or-v1-...
OPENROUTER_MODEL=meta-llama/llama-3.1-70b-instruct:free
```

### د) Telegram Bot
1. افتح [@BotFather](https://t.me/BotFather) في تيليكرام
2. `/newbot` → سمّيه → حط username
3. انسخ الـ Token:
```
TELEGRAM_BOT_TOKEN=1234567890:ABCDef...
```

### هـ) Telegram Admin ID
1. افتح [@userinfobot](https://t.me/userinfobot)
2. `/start` → انسخ الـ ID
```
ADMIN_TELEGRAM_ID=123456789
```

### و) Fly.io
1. [fly.io](https://fly.io) → سجّل
2. نصب CLI: `curl -L https://fly.io/install.sh | sh`
3. `fly auth login`

---

## المرحلة ٣: نصب المشروع

```bash
# 1) انسخ الكود
git clone <your-repo> iraqi-agent
cd iraqi-agent

# 2) بيئة افتراضية (اختياري)
python -m venv venv
source venv/bin/activate

# 3) نصب Python deps
pip install -r requirements.txt

# 4) نصب Node deps (WhatsApp)
npm install

# 5) انسخ env
cp .env.example .env
nano .env   # عبّي المفاتيح
```

---

## المرحلة ٤: التشغيل المحلي

```bash
# الطريقة السريعة
bash start.sh
```

أو بـ Docker (الطريقة الموصى بها):
```bash
docker compose up -d
```

### افتح اللينكات
- **API**: http://localhost:8000
- **Health**: http://localhost:8000/health
- **Prometheus metrics**: http://localhost:8000/metrics
- **Grafana**: http://localhost:3000 (admin/changeme)
- **MinIO**: http://localhost:9001 (iraqi/changeme123)
- **WhatsApp QR**: http://localhost:8000/wa/qr

---

## المرحلة ٥: بوت تيليكرام

افتح بوتك في تيليكرام:
```
/start
```

شوف الـ dashboard:
```
/dashboard
```

أضف أول مستأجر:
```
/add
```

---

## المرحلة ٦: ربط الواتساب

1. افتح [http://localhost:8000/wa/qr](http://localhost:8000/wa/qr)
2. انسخ الـ QR
3. واتساب → الإعدادات → الأجهزة المرتبطة → ربط جهاز
4. امسح الـ QR
5. راح تشوف `✅ WhatsApp connected`

---

## المرحلة ٧: النشر على Fly.io (مجاني ٢٤/٧)

```bash
fly launch --copy-config
fly secrets set \
  APP_SECRET=$(openssl rand -hex 32) \
  GROQ_API_KEY=gsk_xxx \
  GOOGLE_API_KEY=xxx \
  OPENROUTER_API_KEY=xxx \
  TELEGRAM_BOT_TOKEN=xxx \
  ADMIN_TELEGRAM_ID=123456789 \
  WA_BRIDGE_AUTH=$(openssl rand -hex 16) \
  META_VERIFY_TOKEN=$(openssl rand -hex 16)

fly volumes create iraqi_data --size 1
fly deploy
```

لما ينتهي، راح تحصل على URL مثل: `https://iraqi-agent.fly.dev`

**للـ ٢٤/٧ المجاني الكامل:**
- شغّل على Fly.io كسيرفر رئيسي
- شغّل على Oracle Cloud كسيرفر احتياطي
- `scripts/failover.py` يتنقل بينهم تلقائياً
- Cloudflare DNS يحدّث نفسه

---

## المرحلة ٨: ربط القنوات الثانية

راجع [`docs/channel_setup.md`](channel_setup.md) للتفاصيل الكاملة.

### Instagram + Messenger
- أنشئ Meta App
- احصل على Page Access Token
- اربط بـ webhook: `https://yourdomain.com/webhook/meta`
- من البوت: `/link_ig <id> <handle> <ig_business_id>`

### TikTok
- TikTok for Business
- Comment auto-reply
- `/link_tt <id> <handle>`

### Web Widget
- أضف هذا لأي موقع:
```html
<script src="https://yourdomain.com/widget.js"
        data-tenant="baghdad_kebab"
        data-api="https://yourdomain.com"
        data-color="#f5576c"></script>
```

---

## المرحلة ٩: التسعير والبيع

راجع [`docs/monetization.md`](monetization.md).

### إعداد الباقات
كل باقة لها KB chunks، عدد القنوات، عدد الرسائل شهرياً.

### إصدار فاتورة
```
/invoice baghdad_kebab basic 1
```

### تسجيل دفعة
```
/paid INV-ABC12345 zain_cash:REF123
```

### البوت يذكّر الزبائن
البوت يرسل تلقائياً تنبيهات قبل انتهاء الاشتراك.

---

## المرحلة ١٠: CI/CD (اختياري)

ارفع الكود على GitHub:
```bash
git push origin main
```

GitHub Actions:
- ✅ يختبر كل push
- ✅ يبني Docker image
- ✅ ينشر على Fly.io تلقائياً

---

## 🆘 مشاكل شائعة

### البوت ما يرد
- `/stats` شوف الـ providers
- إذا فاضي، أضف API key

### WhatsApp disconnected
- احذف `data/wa_auth/` واعد الربط
- تأكد من اتصال الإنترنت

### Telegram bot unauthorized
- تأكد `ADMIN_TELEGRAM_ID` صحيح

### Memory leak
- استخدم `--workers 1` في uvicorn
- الذاكرة in-process، تنمسح كل restart

### Port 8000 مشغول
- `APP_PORT=8001` بـ `.env`

---

## 🎉 مبروك!

عندك الآن منصة SaaS كاملة، عراقية، مجانية، احترافية. يلا بسم الله وانطلق! 🚀🇮🇶
