# 📡 دليل ربط القنوات (واتساب، إنستكرام، ماسنجر، تيك توك)

---

## 1. واتساب (Baileys) — الأسهل ✅

**المتطلبات:** رقم هاتف ثاني (أو نفس رقم المشروع)

### محلياً
1. شغّل `bash start.sh`
2. افتح [http://localhost:8000/wa/qr](http://localhost:8000/wa/qr)
3. انسخ نص الـ QR
4. واتساب → الإعدادات → الأجهزة المرتبطة → ربط جهاز
5. امسح الـ QR

### على Fly.io
1. ادخل على الـ URL العام: `https://iraqi-agent.fly.dev/wa/qr`
2. نفس الخطوات

### ربط المستأجر
```
/link_wa <tenant_id> 96477xxxxxxxx
```

---

## 2. Instagram (Meta Graph API) — رسمي ومجاني

**المتطلبات:**
- حساب Instagram **Business** (مو Personal)
- صفحة Facebook مرتبطة بيه
- Meta Developer account

### أ) أنشئ Meta App
1. [developers.facebook.com](https://developers.facebook.com) → **My Apps** → **Create App**
2. اختار **Business**
3. سمّيه `Iraqi Agent`
4. أضف المنتج **Instagram** → **Instagram Graph API**

### ب) ربط Instagram Business Account
1. في App Dashboard → **Instagram** → **API setup**
2. **Add Account** → اربط حساب الـ IG Business
3. اربطه بالـ Facebook Page

### ج) احصل على الـ Tokens
1. **Tools** → **Graph API Explorer**
2. اختار تطبيقك
3. **Generate Access Token** مع الصلاحيات:
   - `instagram_basic`
   - `instagram_manage_messages`
   - `pages_messaging`
   - `pages_manage_metadata`
4. **Convert to Long-Lived Token** (60 يوم)
5. احصل على الـ IDs:
   ```bash
   # الـ IG Business ID
   GET /me/accounts?access_token=XXX
   # يطلعلك صفحة Facebook → استخدم /<page_id>?fields=instagram_business_account
   GET /<page_id>?fields=instagram_business_account&access_token=XXX
   ```

### د) Webhook
1. App Dashboard → **Webhooks** → **Instagram** → **Subscribe**
2. اشترك بأحداث: `messages`, `messaging_postbacks`
3. **Callback URL**: `https://yourdomain.com/webhook/meta`
4. **Verify Token**: نفس `META_VERIFY_TOKEN` من `.env`

### هـ) ربط المستأجر
```
/link_ig <tenant_id> <handle> <ig_business_id>
# بعدها يطلب Page Access Token
```

---

## 3. Messenger — نفس الـ Meta App

نفس الخطوات بالأعلى، بس:
- أضف منتج **Messenger** في الـ App
- Subscribe لحدث `messages` على الـ Webhook
- Page Access Token مختلف (من **Messenger Settings**)

```
/link_fb <tenant_id> <page_id>
# بعدها يطلب Page Access Token
```

---

## 4. TikTok — محدود (تعليقات فقط)

**⚠️ TikTok ما عندها API رسمي للـ DMs.**

الخيار المجاني الرسمي: **Comment Auto-Reply**

### أ) TikTok for Business
1. [ads.tiktok.com](https://ads.tiktok.com) → سجّل Business account
2. **Content** → **Connect TikTok Account**

### ب) TikTok Developer App
1. [developers.tiktok.com](https://developers.tiktok.com)
2. أنشئ App
3. **Add Product** → **Content Posting API**
4. Subscribe لـ `video.comment.create` webhook

### ج) Webhook
- **Callback URL**: `https://yourdomain.com/webhook/tiktok`
- Verify Token: عيّنه بأي شي

### د) ربط المستأجر
```
/link_tt <tenant_id> <handle>
```

> 💡 **نصيحة:** إذا الزبون يريد DMs على تيك توك، وجّهه للإنستكرام.

---

## 5. تيليكرام (للتحكم)

مو للقنوات، هذا **لوحة التحكم**:
1. [@BotFather](https://t.me/BotFather) → `/newbot`
2. حط الـ Token في `.env`
3. حط `ADMIN_TELEGRAM_ID` بـ `.env`

---

## 🌐 كل شي مع بعض

```bash
# Terminal 1: المشروع
bash start.sh

# Terminal 2: ngrok (إذا تبي تجرب من بيتك)
ngrok http 8000
# انسخ الـ URL من ngrok وضعه بـ Meta Webhook
```

---

## 🧪 اختبر كل قناة

```bash
# Health
curl http://localhost:8000/health

# Direct chat (لا يحتاج ربط)
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"tenant_id":"baghdad_kebab","message":"هلا","user_id":"test1"}'
```

---

## 🆘 مشاكل شائعة

### "Webhook verification failed"
- تأكد `META_VERIFY_TOKEN` نفسه بـ Meta App وبـ `.env`
- تأكد الـ URL **HTTPS**

### "Page Access Token expired"
- Tokens العادية تنتهي بعد ساعة
- استخدم **Long-Lived** (60 يوم)
- أو **System User Token** (أبداً) عبر Business Settings

### "WhatsApp disconnected"
- هذا طبيعي. الـ Node bridge يعيد الاتصال تلقائياً
- إذا استمرت المشكلة، احذف `data/wa_auth/` واعد الربط

### "Instagram messages not received"
- تأكد الحساب **Business** مو Personal
- تأكد الـ Page مربوط فيه
- تأكد الـ App عنده صلاحية `instagram_manage_messages`

---

## 📊 جدول المقارنة

| القناة | المجاني | السهل | الـ DMs | الصعوبة |
|--------|---------|-------|---------|---------|
| واتساب (Baileys) | ✅ | ✅ | ✅ | سهل |
| إنستكرام (Meta) | ✅ | متوسط | ✅ | متوسط |
| ماسنجر (Meta) | ✅ | متوسط | ✅ | متوسط |
| تيك توك (تعليقات) | ✅ | صعب | ❌ | صعب |
| تيليكرام (تحكم) | ✅ | سهل | — | سهل جداً |
