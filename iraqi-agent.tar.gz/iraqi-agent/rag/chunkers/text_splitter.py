"""
rag/chunkers/text_splitter.py
Smart Arabic-aware text chunker.

Uses a recursive strategy that respects:
- Arabic sentence boundaries (۔ ، . ! ؟)
- Paragraph breaks
- Token budget (via tiktoken)
"""
from __future__ import annotations
from typing import List, Dict, Any
from pydantic import BaseModel
import re
import tiktoken

# Arabic + Latin sentence enders
_SENTENCE_END = re.compile(r"(?<=[.!?؟۔])\s+|(?<=\n)\s*")


class Chunk(BaseModel):
    text: str
    doc_id: str
    source: str
    source_type: str
    chunk_index: int
    metadata: Dict[str, Any] = {}
    token_count: int = 0


class TextChunker:
    def __init__(self, max_tokens: int = 400, overlap: int = 60, model: str = "cl100k_base"):
        self.max_tokens = max_tokens
        self.overlap = overlap
        try:
            self.enc = tiktoken.get_encoding(model)
        except Exception:
            self.enc = tiktoken.get_encoding("cl100k_base")

    def split(self, doc) -> List[Chunk]:
        """
        doc: a Document from rag.loaders
        Returns: list of Chunk objects (each carries doc_id and source).
        """
        text = doc.content
        # 1) Split into paragraphs
        paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
        # 2) If a paragraph is too long, split by sentences
        units: List[str] = []
        for p in paragraphs:
            if self._tokens(p) <= self.max_tokens:
                units.append(p)
            else:
                units.extend(self._split_sentences(p))
        # 3) Pack units into chunks respecting max_tokens
        chunks: List[Chunk] = []
        buf: List[str] = []
        buf_tokens = 0
        idx = 0
        for u in units:
            ut = self._tokens(u)
            if buf_tokens + ut > self.max_tokens and buf:
                chunks.append(self._make_chunk(" ".join(buf), doc, idx))
                idx += 1
                # Carry over overlap
                if self.overlap > 0 and buf:
                    tail = self._tail_with_tokens(buf, self.overlap)
                    buf = [tail] if tail else []
                    buf_tokens = self._tokens(buf[0]) if buf else 0
                else:
                    buf = []
                    buf_tokens = 0
            buf.append(u)
            buf_tokens += ut
        if buf:
            chunks.append(self._make_chunk(" ".join(buf), doc, idx))
        return chunks

    # ---- helpers ----
    def _tokens(self, s: str) -> int:
        return len(self.enc.encode(s, disallowed_special=()))

    def _split_sentences(self, paragraph: str) -> List[str]:
        parts = _SENTENCE_END.split(paragraph)
        return [p.strip() for p in parts if p.strip()]

    def _tail_with_tokens(self, buf: List[str], target_tokens: int) -> str:
        # Take the last items up to `target_tokens` tokens (for overlap).
        out, tokens = [], 0
        for u in reversed(buf):
            ut = self._tokens(u)
            if tokens + ut > target_tokens:
                break
            out.insert(0, u)
            tokens += ut
        return " ".join(out)

    def _make_chunk(self, text: str, doc, idx: int) -> Chunk:
        return Chunk(
            text=text.strip(),
            doc_id=doc.doc_id,
            source=doc.source,
            source_type=doc.source_type,
            chunk_index=idx,
            metadata=doc.to_chunk_metadata(),
            token_count=self._tokens(text),
        )
