"""
rag/loaders/docx_loader.py
"""
from typing import List
import docx
from .base import BaseLoader, Document


class DOCXLoader(BaseLoader):
    source_type = "docx"

    def load(self, source: str, **kwargs) -> List[Document]:
        d = docx.Document(source)
        paragraphs = [p.text for p in d.paragraphs if p.text.strip()]
        # Include tables
        for t in d.tables:
            for row in t.rows:
                for cell in row.cells:
                    if cell.text.strip():
                        paragraphs.append(cell.text)
        full_text = "\n".join(paragraphs)
        return [Document(
            content=full_text,
            source=source,
            source_type=self.source_type,
            mime_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            metadata={"paragraphs": len(paragraphs)},
        )]
