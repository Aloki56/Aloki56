"""
rag/loaders/text_loader.py
Plain text + Markdown loader.
"""
from typing import List
from .base import BaseLoader, Document


class TextLoader(BaseLoader):
    source_type = "txt"

    def load(self, source: str, **kwargs) -> List[Document]:
        with open(source, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
        if not content.strip():
            return []
        return [Document(
            content=content,
            source=source,
            source_type=self.source_type,
            mime_type="text/plain",
            metadata={"chars": len(content)},
        )]
