"""
rag/loaders/url_loader.py
Generic web page loader. Strips HTML to text, removes boilerplate.
"""
from typing import List
import httpx
import trafilatura
from bs4 import BeautifulSoup
from .base import BaseLoader, Document


class URLLoader(BaseLoader):
    source_type = "url"

    def load(self, source: str, **kwargs) -> List[Document]:
        max_pages = kwargs.get("max_pages", 1)
        docs = []
        r = httpx.get(
            source,
            timeout=30,
            headers={"User-Agent": "Mozilla/5.0 IraqiAgent/1.0"},
            follow_redirects=True,
        )
        r.raise_for_status()
        html = r.text
        # trafilatura is the best at extracting main content
        text = trafilatura.extract(html, include_links=False, include_images=False) or ""
        if not text:
            soup = BeautifulSoup(html, "lxml")
            for tag in soup(["script", "style", "nav", "footer", "header"]):
                tag.decompose()
            text = soup.get_text("\n", strip=True)
        if not text.strip():
            return []
        docs.append(Document(
            content=text,
            source=source,
            source_type=self.source_type,
            mime_type=r.headers.get("content-type", "").split(";")[0],
            metadata={"title": self._extract_title(html), "url": source},
        ))
        return docs

    def _extract_title(self, html: str) -> str:
        try:
            soup = BeautifulSoup(html, "lxml")
            return (soup.title.string or "").strip()
        except Exception:
            return ""
