"""
rag/loaders/csv_loader.py
"""
from typing import List
import pandas as pd
from .base import BaseLoader, Document


class CSVLoader(BaseLoader):
    source_type = "csv"

    def load(self, source: str, **kwargs) -> List[Document]:
        # source can be path or URL
        df = pd.read_csv(source, encoding="utf-8", on_bad_lines="skip")
        # Convert to readable text — header + each row
        text_lines = [" | ".join(df.columns)]
        for _, row in df.iterrows():
            text_lines.append(" | ".join(str(v) for v in row.values))
        content = "\n".join(text_lines)
        return [Document(
            content=content,
            source=source,
            source_type=self.source_type,
            mime_type="text/csv",
            metadata={"rows": len(df), "columns": list(df.columns)},
        )]
