"""
rag/loaders/google_sheets.py
Loads a public Google Sheet as a document. No API key needed for public sheets.
"""
from typing import List
import httpx
import csv
from io import StringIO
from .base import BaseLoader, Document


class GoogleSheetsLoader(BaseLoader):
    source_type = "gsheet"

    def load(self, source: str, **kwargs) -> List[Document]:
        """
        source: Google Sheets URL or sheet ID
        """
        sheet_id = self._extract_id(source)
        if not sheet_id:
            raise ValueError(f"Could not extract Google Sheet ID from: {source}")

        gid = kwargs.get("gid", 0)
        url = f"https://docs.google.com/spreadsheets/d/{sheet_id}/export?format=csv&gid={gid}"
        r = httpx.get(url, timeout=30, follow_redirects=True)
        r.raise_for_status()
        # Parse CSV
        reader = csv.reader(StringIO(r.text))
        rows = [r for r in reader if any(c.strip() for c in r)]
        if not rows:
            return []
        text_lines = [" | ".join(rows[0])]  # header
        text_lines += [" | ".join(r) for r in rows[1:]]
        content = "\n".join(text_lines)
        return [Document(
            content=content,
            source=source,
            source_type=self.source_type,
            mime_type="text/csv",
            metadata={"sheet_id": sheet_id, "rows": len(rows)},
        )]

    def _extract_id(self, url_or_id: str) -> str:
        if "/" not in url_or_id and len(url_or_id) > 20:
            return url_or_id
        # https://docs.google.com/spreadsheets/d/<ID>/edit
        parts = url_or_id.split("/")
        for i, p in enumerate(parts):
            if p == "d" and i + 1 < len(parts):
                return parts[i + 1]
        return ""
