"""
rag/loaders/pdf_loader.py
"""
from typing import List
from pathlib import Path
import pypdf
from .base import BaseLoader, Document


class PDFLoader(BaseLoader):
    source_type = "pdf"

    def load(self, source: str, **kwargs) -> List[Document]:
        # source can be a file path or a URL
        if source.startswith(("http://", "https://")):
            import httpx
            r = httpx.get(source, timeout=30)
            r.raise_for_status()
            from io import BytesIO
            reader = pypdf.PdfReader(BytesIO(r.content))
            return self._extract(reader, source)
        else:
            reader = pypdf.PdfReader(source)
            return self._extract(reader, source)

    def _extract(self, reader, source: str) -> List[Document]:
        docs = []
        for i, page in enumerate(reader.pages):
            text = page.extract_text() or ""
            if not text.strip():
                continue
            docs.append(Document(
                content=text,
                source=f"{source}#page={i+1}",
                source_type=self.source_type,
                mime_type="application/pdf",
                metadata={"page": i + 1, "total_pages": len(reader.pages)},
            ))
        return docs
