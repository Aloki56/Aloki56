"""
rag/loaders/facebook_loader.py
Loads a public Facebook page's posts. Uses the Graph API if a token is
configured, otherwise falls back to basic public scraping (limited).
"""
from typing import List
import httpx
from .base import BaseLoader, Document


GRAPH = "https://graph.facebook.com/v20.0"


class FacebookLoader(BaseLoader):
    source_type = "fb"

    def load(self, source: str, **kwargs) -> List[Document]:
        """
        source: Facebook page name or full URL
        Requires META_PAGE_TOKEN (any page token with pages_read_engagement)
        """
        from core.config import get_settings
        s = get_settings()
        if not s.meta_app_id or not s.meta_app_secret:
            # Public scraping fallback (best-effort, often blocked)
            return self._scrape_public(source)

        page_name = self._extract_name(source)
        # Get page id
        r = httpx.get(
            f"{GRAPH}/{page_name}",
            params={"access_token": s.meta_app_id + "|" + s.meta_app_secret,
                    "fields": "id,name"},
            timeout=15,
        )
        if r.status_code != 200:
            return []
        page_id = r.json().get("id")
        # Get recent posts
        r = httpx.get(
            f"{GRAPH}/{page_id}/posts",
            params={
                "access_token": s.meta_app_id + "|" + s.meta_app_secret,
                "fields": "message,created_time,permalink_url",
                "limit": 25,
            },
            timeout=15,
        )
        if r.status_code != 200:
            return []
        posts = r.json().get("data", [])
        docs = []
        for p in posts:
            msg = p.get("message", "")
            if not msg:
                continue
            docs.append(Document(
                content=msg,
                source=p.get("permalink_url", source),
                source_type=self.source_type,
                mime_type="text/plain",
                metadata={"created": p.get("created_time", ""), "page": page_name},
            ))
        return docs

    def _scrape_public(self, source: str) -> List[Document]:
        # Fallback: try to load the page with HTML
        import httpx
        r = httpx.get(
            source,
            timeout=15,
            headers={"User-Agent": "Mozilla/5.0"},
            follow_redirects=True,
        )
        if r.status_code != 200:
            return []
        # Extract Open Graph meta + visible text
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(r.text, "lxml")
        text = soup.get_text("\n", strip=True)[:5000]
        if not text.strip():
            return []
        return [Document(content=text, source=source, source_type=self.source_type, mime_type="text/html")]

    def _extract_name(self, source: str) -> str:
        if "facebook.com/" in source:
            parts = source.split("facebook.com/")[-1].split("/")[0].split("?")[0]
            return parts
        return source
