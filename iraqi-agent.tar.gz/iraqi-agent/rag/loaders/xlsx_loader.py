"""
rag/loaders/xlsx_loader.py
Reads all sheets in an xlsx file. Each sheet becomes one document.
"""
from typing import List
import openpyxl
from .base import BaseLoader, Document


class XLSXLoader(BaseLoader):
    source_type = "xlsx"

    def load(self, source: str, **kwargs) -> List[Document]:
        wb = openpyxl.load_workbook(source, data_only=True, read_only=True)
        docs = []
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            rows = []
            for row in ws.iter_rows(values_only=True):
                vals = [str(v) if v is not None else "" for v in row]
                if any(vals):
                    rows.append(" | ".join(vals))
            if not rows:
                continue
            content = f"Sheet: {sheet_name}\n" + "\n".join(rows)
            docs.append(Document(
                content=content,
                source=f"{source}#sheet={sheet_name}",
                source_type=self.source_type,
                mime_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                metadata={"sheet": sheet_name, "rows": len(rows)},
            ))
        wb.close()
        return docs
