"""
rag/loaders/__init__.py
Document loaders for various file types.
"""
from .base import BaseLoader, Document
from .pdf_loader import PDFLoader
from .docx_loader import DOCXLoader
from .xlsx_loader import XLSXLoader
from .csv_loader import CSVLoader
from .text_loader import TextLoader
from .url_loader import URLLoader
from .google_sheets import GoogleSheetsLoader
from .facebook_loader import FacebookLoader

__all__ = [
    "BaseLoader", "Document",
    "PDFLoader", "DOCXLoader", "XLSXLoader", "CSVLoader", "TextLoader",
    "URLLoader", "GoogleSheetsLoader", "FacebookLoader",
]
