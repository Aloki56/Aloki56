"""
rag/loaders/base.py
Base classes for document loaders.
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
from pydantic import BaseModel
import hashlib
import mimetypes
from pathlib import Path


class Document(BaseModel):
    """A single loaded document with metadata."""
    content: str
    source: str               # filename / URL / sheet name
    source_type: str          # pdf | docx | xlsx | csv | txt | url | gsheet | fb
    mime_type: Optional[str] = None
    doc_id: str = ""          # hash of content + source
    metadata: Dict[str, Any] = {}

    def model_post_init(self, __context):
        if not self.doc_id:
            h = hashlib.sha256()
            h.update(self.source.encode())
            h.update(self.content.encode()[:10_000].encode("utf-8", errors="ignore"))
            self.doc_id = h.hexdigest()[:16]

    def to_chunk_metadata(self) -> Dict[str, Any]:
        return {
            "doc_id": self.doc_id,
            "source": self.source,
            "source_type": self.source_type,
            **self.metadata,
        }


class BaseLoader(ABC):
    """Base class — every loader turns a source into List[Document]."""

    source_type: str = "base"

    @abstractmethod
    def load(self, source: str, **kwargs) -> List[Document]:
        ...

    def _guess_mime(self, path: str) -> str:
        mime, _ = mimetypes.guess_type(path)
        return mime or "application/octet-stream"
