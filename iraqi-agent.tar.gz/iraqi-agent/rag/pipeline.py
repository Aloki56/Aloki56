"""
rag/pipeline.py
End-to-end RAG ingestion + retrieval pipeline.

Usage:
    pipe = RAGPipeline(embedding_provider, vector_store)
    pipe.ingest_file(tenant_id, "menu.pdf")
    pipe.ingest_url(tenant_id, "https://restaurant.com")
    hits = pipe.query(tenant_id, "بكم الكباب؟", top_k=5)
"""
from __future__ import annotations
import os
import asyncio
from typing import List, Optional, Dict, Any
from loguru import logger
from concurrent.futures import ThreadPoolExecutor

from .loaders import (
    PDFLoader, DOCXLoader, XLSXLoader, CSVLoader, TextLoader,
    URLLoader, GoogleSheetsLoader, FacebookLoader, Document,
)
from .chunkers import TextChunker
from .embeddings import EmbeddingProvider, LocalEmbeddings, GoogleEmbeddings
from .retrievers import QdrantVectorStore, HybridRetriever, RetrievedDoc


_LOADERS = {
    ".pdf":  PDFLoader(),
    ".docx": DOCXLoader(),
    ".xlsx": XLSXLoader(),
    ".xls":  XLSXLoader(),
    ".csv":  CSVLoader(),
    ".txt":  TextLoader(),
    ".md":   TextLoader(),
    ".log":  TextLoader(),
}


class RAGPipeline:
    def __init__(
        self,
        embedding: Optional[EmbeddingProvider] = None,
        vector_store: Optional[QdrantVectorStore] = None,
        chunker: Optional[TextChunker] = None,
    ):
        self.embedding = embedding or LocalEmbeddings()
        self.vec = vector_store or QdrantVectorStore()
        self.chunker = chunker or TextChunker()
        self.retriever = HybridRetriever(self.vec)
        # Track indexed files per tenant (to avoid re-indexing)
        self._seen: Dict[str, set] = {}
        # Thread pool for CPU-bound embedding
        self._exec = ThreadPoolExecutor(max_workers=2, thread_name_prefix="rag-emb")

    # ---- ingestion ----
    def ingest_file(self, tenant_id: str, path: str) -> int:
        """Returns number of chunks indexed."""
        ext = os.path.splitext(path)[1].lower()
        loader = _LOADERS.get(ext)
        if not loader:
            raise ValueError(f"Unsupported file type: {ext}")
        docs = loader.load(path)
        return self._index_documents(tenant_id, docs)

    def ingest_url(self, tenant_id: str, url: str) -> int:
        loader = URLLoader()
        docs = loader.load(url)
        return self._index_documents(tenant_id, docs)

    def ingest_google_sheet(self, tenant_id: str, url: str, gid: int = 0) -> int:
        docs = GoogleSheetsLoader().load(url, gid=gid)
        return self._index_documents(tenant_id, docs)

    def ingest_facebook_page(self, tenant_id: str, page: str) -> int:
        docs = FacebookLoader().load(page)
        return self._index_documents(tenant_id, docs)

    def ingest_text(self, tenant_id: str, text: str, source: str = "manual") -> int:
        doc = Document(content=text, source=source, source_type="manual", mime_type="text/plain")
        return self._index_documents(tenant_id, [doc])

    def _index_documents(self, tenant_id: str, docs: List[Document]) -> int:
        if not docs:
            return 0
        # De-duplicate against seen
        seen = self._seen.setdefault(tenant_id, set())
        new_docs = [d for d in docs if d.doc_id not in seen]
        for d in new_docs:
            seen.add(d.doc_id)
        if not new_docs:
            return 0
        # Chunk
        all_chunks = []
        for d in new_docs:
            all_chunks.extend(self.chunker.split(d))
        if not all_chunks:
            return 0
        # Ensure collection exists
        self.vec.ensure_collection(tenant_id, dim=self.embedding.dim)
        # Embed (offload to thread)
        texts = [c.text for c in all_chunks]
        future = self._exec.submit(self.embedding.embed, texts)
        vectors = future.result()
        # Index
        self.retriever.add(tenant_id, all_chunks, vectors)
        logger.info(f"📚 Indexed {len(all_chunks)} chunks for tenant={tenant_id}")
        return len(all_chunks)

    # ---- query ----
    def query(self, tenant_id: str, question: str, top_k: int = 5) -> List[RetrievedDoc]:
        if self.vec.count(tenant_id) == 0:
            return []
        # Embed the question
        if hasattr(self.embedding, "embed_query"):
            qvec = self.embedding.embed_query(question)
        else:
            qvec = self.embedding.embed_one(question)
        return self.retriever.query(tenant_id, question, qvec, top_k=top_k)

    # ---- format for prompt ----
    @staticmethod
    def format_for_prompt(hits: List[RetrievedDoc], max_chars: int = 3000) -> str:
        if not hits:
            return ""
        out = ["## معلومات من قاعدة المعرفة (استخدمها للإجابة):"]
        used = 0
        for h in hits:
            block = f"\n### من: {h.source}\n{h.text}\n"
            if used + len(block) > max_chars:
                break
            out.append(block)
            used += len(block)
        return "\n".join(out)

    # ---- admin ----
    def reset_tenant(self, tenant_id: str):
        self.vec.delete_collection(tenant_id)
        # Re-init BM25
        from rank_bm25 import BM25Okapi
        self.retriever._bm25.pop(tenant_id, None)
        self.retriever._bm25_payloads.pop(tenant_id, None)
        self._seen.pop(tenant_id, None)

    def stats(self, tenant_id: str) -> Dict[str, Any]:
        return {
            "vectors": self.vec.count(tenant_id),
            "bm25_docs": len(self.retriever._bm25_payloads.get(tenant_id, [])),
        }


# Singleton
_pipeline: Optional[RAGPipeline] = None


def get_rag() -> RAGPipeline:
    global _pipeline
    if _pipeline is None:
        # Try Google embeddings first if a key is set, else local
        from core.config import get_settings
        s = get_settings()
        emb = None
        if s.google_api_key:
            emb = GoogleEmbeddings(s.google_api_key)
        if emb is None:
            emb = LocalEmbeddings()
        _pipeline = RAGPipeline(embedding=emb)
    return _pipeline
