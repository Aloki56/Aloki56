"""
rag/retrievers/vector_store.py
Qdrant vector store wrapper.

- One collection per tenant (tenant_id is a payload filter, but for
  stronger isolation we use a separate collection per tenant).
- Falls back to an in-process memory store if Qdrant isn't reachable
  (good for local dev / free tier hiccups).
"""
from __future__ import annotations
import os
import time
from typing import List, Dict, Any, Optional
from pydantic import BaseModel
from loguru import logger


class RetrievedDoc(BaseModel):
    text: str
    source: str
    source_type: str
    score: float
    doc_id: str
    metadata: Dict[str, Any] = {}


class QdrantVectorStore:
    """
    Persistent vector store backed by Qdrant. If QDRANT_URL is not
    set, we use an in-memory fallback (so dev still works).
    """

    def __init__(self, url: Optional[str] = None, api_key: Optional[str] = None):
        self.url = url or os.environ.get("QDRANT_URL", "http://localhost:6333")
        self.api_key = api_key or os.environ.get("QDRANT_API_KEY")
        self._client = None
        self._mem: Dict[str, List[Dict[str, Any]]] = {}  # collection -> list of {vec, payload}
        self._try_connect()

    def _try_connect(self):
        if not self.url or self.url.startswith("memory://"):
            logger.warning("QdrantVectorStore running in in-memory mode")
            return
        try:
            from qdrant_client import QdrantClient
            self._client = QdrantClient(url=self.url, api_key=self.api_key, timeout=5)
            self._client.get_collections()  # ping
            logger.info(f"✅ Qdrant connected at {self.url}")
        except Exception as e:
            logger.warning(f"Qdrant unreachable, using in-memory: {e!r}")
            self._client = None

    # ---- collection management ----
    def _collection(self, tenant_id: str) -> str:
        return f"kb_{tenant_id}"

    def ensure_collection(self, tenant_id: str, dim: int):
        name = self._collection(tenant_id)
        if self._client is not None:
            from qdrant_client.models import Distance, VectorParams
            if name not in [c.name for c in self._client.get_collections().collections]:
                self._client.create_collection(
                    collection_name=name,
                    vectors_config=VectorParams(size=dim, distance=Distance.COSINE),
                )
        else:
            self._mem.setdefault(name, [])

    # ---- CRUD ----
    def upsert(self, tenant_id: str, vectors: List[List[float]], payloads: List[Dict[str, Any]]):
        if not vectors:
            return
        if self._client is not None:
            from qdrant_client.models import PointStruct
            name = self._collection(tenant_id)
            points = [
                PointStruct(id=int(time.time() * 1e6) + i, vector=v, payload=p)
                for i, (v, p) in enumerate(zip(vectors, payloads))
            ]
            self._client.upsert(collection_name=name, points=points)
        else:
            name = self._collection(tenant_id)
            self._mem.setdefault(name, [])
            for v, p in zip(vectors, payloads):
                self._mem[name].append({"vec": v, "payload": p})

    def search(self, tenant_id: str, query_vector: List[float], top_k: int = 5) -> List[RetrievedDoc]:
        if self._client is not None:
            from qdrant_client.models import SearchRequest
            name = self._collection(tenant_id)
            try:
                hits = self._client.search(
                    collection_name=name, query_vector=query_vector, limit=top_k
                )
            except Exception as e:
                logger.error(f"Qdrant search failed: {e!r}")
                return []
            return [
                RetrievedDoc(
                    text=h.payload.get("text", ""),
                    source=h.payload.get("source", ""),
                    source_type=h.payload.get("source_type", ""),
                    score=float(h.score),
                    doc_id=str(h.id),
                    metadata={k: v for k, v in h.payload.items() if k not in ("text",)},
                )
                for h in hits
            ]
        else:
            # Cosine similarity in-memory
            import numpy as np
            name = self._collection(tenant_id)
            rows = self._mem.get(name, [])
            if not rows:
                return []
            q = np.array(query_vector, dtype=np.float32)
            scores = []
            for r in rows:
                v = np.array(r["vec"], dtype=np.float32)
                denom = (np.linalg.norm(q) * np.linalg.norm(v)) or 1e-9
                scores.append(float(np.dot(q, v) / denom))
            order = sorted(range(len(rows)), key=lambda i: scores[i], reverse=True)[:top_k]
            return [
                RetrievedDoc(
                    text=rows[i]["payload"].get("text", ""),
                    source=rows[i]["payload"].get("source", ""),
                    source_type=rows[i]["payload"].get("source_type", ""),
                    score=scores[i],
                    doc_id=str(i),
                    metadata=rows[i]["payload"],
                )
                for i in order
            ]

    def delete_collection(self, tenant_id: str):
        name = self._collection(tenant_id)
        if self._client is not None:
            try:
                self._client.delete_collection(name)
            except Exception:
                pass
        self._mem.pop(name, None)

    def count(self, tenant_id: str) -> int:
        name = self._collection(tenant_id)
        if self._client is not None:
            try:
                return self._client.count(name).count
            except Exception:
                return 0
        return len(self._mem.get(name, []))
