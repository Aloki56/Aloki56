"""
rag/retrievers/hybrid.py
Hybrid retrieval = vector similarity (semantic) + BM25 (keyword).
Combines both with reciprocal-rank-fusion for the best of both worlds.
"""
from __future__ import annotations
import re
from typing import List, Dict, Any
from rank_bm25 import BM25Okapi
from .vector_store import QdrantVectorStore, RetrievedDoc


_TOKENIZE = re.compile(r"\w+", re.UNICODE)


def _tokenize(text: str) -> List[str]:
    return [t.lower() for t in _TOKENIZE.findall(text or "")]


class HybridRetriever:
    """
    Holds an in-memory BM25 index PLUS a Qdrant vector store.
    On query, run both and merge with reciprocal-rank-fusion.
    """

    def __init__(self, vector_store: QdrantVectorStore):
        self.vec = vector_store
        # Per-tenant BM25: tenant_id -> (BM25Okapi, list of payloads)
        self._bm25: Dict[str, Any] = {}
        self._bm25_payloads: Dict[str, List[Dict[str, Any]]] = {}

    def add(self, tenant_id: str, chunks: List, vectors: List[List[float]]):
        """Index a batch of chunks for a tenant."""
        if not chunks:
            return
        # ---- vector store ----
        payloads = [
            {
                "text": c.text,
                "source": c.source,
                "source_type": c.source_type,
                "doc_id": c.doc_id,
                "chunk_index": c.chunk_index,
                **c.metadata,
            }
            for c in chunks
        ]
        self.vec.upsert(tenant_id, vectors, payloads)

        # ---- BM25 ----
        tokenized = [_tokenize(c.text) for c in chunks]
        if tenant_id not in self._bm25:
            self._bm25[tenant_id] = BM25Okapi(tokenized)
            self._bm25_payloads[tenant_id] = payloads
        else:
            # extend
            self._bm25[tenant_id].extend(tokenized) if hasattr(self._bm25[tenant_id], "extend") else None
            self._bm25_payloads[tenant_id].extend(payloads)
            # BM25Okapi doesn't extend — rebuild
            all_tokens = [_tokenize(p["text"]) for p in self._bm25_payloads[tenant_id]]
            self._bm25[tenant_id] = BM25Okapi(all_tokens)

    def query(self, tenant_id: str, query: str, query_vector: List[float], top_k: int = 5) -> List[RetrievedDoc]:
        vector_hits = self.vec.search(tenant_id, query_vector, top_k=top_k)
        # ---- BM25 ----
        bm25_hits: List[RetrievedDoc] = []
        if tenant_id in self._bm25:
            scores = self._bm25[tenant_id].get_scores(_tokenize(query))
            order = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:top_k]
            for i in order:
                p = self._bm25_payloads[tenant_id][i]
                bm25_hits.append(RetrievedDoc(
                    text=p.get("text", ""),
                    source=p.get("source", ""),
                    source_type=p.get("source_type", ""),
                    score=float(scores[i]),
                    doc_id=p.get("doc_id", ""),
                    metadata=p,
                ))
        # ---- RRF merge ----
        return self._rrf_merge(vector_hits, bm25_hits, top_k=top_k)

    def _rrf_merge(self, a: List[RetrievedDoc], b: List[RetrievedDoc], top_k: int, k: int = 60) -> List[RetrievedDoc]:
        scores: Dict[str, float] = {}
        lookup: Dict[str, RetrievedDoc] = {}
        for rank, hit in enumerate(a):
            key = f"{hit.source}::{hit.doc_id}::{hit.text[:40]}"
            scores[key] = scores.get(key, 0) + 1.0 / (k + rank + 1)
            lookup[key] = hit
        for rank, hit in enumerate(b):
            key = f"{hit.source}::{hit.doc_id}::{hit.text[:40]}"
            scores[key] = scores.get(key, 0) + 1.0 / (k + rank + 1)
            lookup.setdefault(key, hit)
        merged = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)[:top_k]
        out = []
        for key, s in merged:
            d = lookup[key]
            d.score = s
            out.append(d)
        return out
