"""
rag/embeddings/local.py
Local sentence-transformers embeddings (no API key, runs on CPU/GPU).

Default model: intfloat/multilingual-e5-small
- 384 dim
- ~120MB download
- Multilingual, excellent Arabic
- MIT license
- Free forever
"""
from typing import List
import numpy as np
from .base import EmbeddingProvider


_MODEL = None  # lazy loaded


def _load_model(model_name: str = "intfloat/multilingual-e5-small"):
    global _MODEL
    if _MODEL is None:
        from sentence_transformers import SentenceTransformer
        _MODEL = SentenceTransformer(model_name, device="cpu")
    return _MODEL


class LocalEmbeddings(EmbeddingProvider):
    name = "local"
    dim = 384

    def __init__(self, model_name: str = "intfloat/multilingual-e5-small"):
        self.model_name = model_name
        # Map model name → dim
        dim_map = {
            "intfloat/multilingual-e5-small": 384,
            "intfloat/multilingual-e5-base": 768,
            "intfloat/multilingual-e5-large": 1024,
            "BAAI/bge-m3": 1024,
            "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2": 384,
        }
        self.dim = dim_map.get(model_name, 384)

    def embed(self, texts: List[str]) -> List[List[float]]:
        m = _load_model(self.model_name)
        # e5 family expects "query: " or "passage: " prefix
        prefix = ""
        if "e5" in self.model_name.lower():
            prefix = "passage: "
        vecs = m.encode([prefix + t for t in texts], normalize_embeddings=True,
                        show_progress_bar=False, convert_to_numpy=True)
        return vecs.tolist()

    def embed_query(self, text: str) -> List[float]:
        m = _load_model(self.model_name)
        prefix = "query: " if "e5" in self.model_name.lower() else ""
        v = m.encode([prefix + text], normalize_embeddings=True, show_progress_bar=False)
        return v[0].tolist()
