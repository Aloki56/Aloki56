"""
rag/embeddings/__init__.py
Embedding providers for RAG.

We default to a free, local, high-quality multilingual model that
works well for Arabic: `intfloat/multilingual-e5-small` (384 dim,
~120MB). For higher quality (but heavier), use `e5-large` or
`bge-m3` (1024 dim, multilingual).

Falls back to a remote provider if the local model can't load.
"""
from .base import EmbeddingProvider
from .local import LocalEmbeddings
from .google import GoogleEmbeddings

__all__ = ["EmbeddingProvider", "LocalEmbeddings", "GoogleEmbeddings"]
