"""
rag/embeddings/base.py
"""
from abc import ABC, abstractmethod
from typing import List


class EmbeddingProvider(ABC):
    name: str = "base"
    dim: int = 384

    @abstractmethod
    def embed(self, texts: List[str]) -> List[List[float]]:
        ...

    def embed_one(self, text: str) -> List[float]:
        return self.embed([text])[0]
