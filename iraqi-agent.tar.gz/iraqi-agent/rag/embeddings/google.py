"""
rag/embeddings/google.py
Google Generative AI embeddings (free tier, 60 req/min).
"""
from typing import List
import httpx
from .base import EmbeddingProvider


class GoogleEmbeddings(EmbeddingProvider):
    name = "google"
    dim = 768

    def __init__(self, api_key: str, model: str = "text-embedding-004"):
        self.api_key = api_key
        self.model = model
        self.url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:batchEmbedContents"

    def embed(self, texts: List[str]) -> List[List[float]]:
        body = {
            "requests": [
                {"model": f"models/{self.model}", "content": {"parts": [{"text": t}]}}
                for t in texts
            ]
        }
        with httpx.Client(timeout=30) as c:
            r = c.post(f"{self.url}?key={self.api_key}", json=body)
            r.raise_for_status()
            data = r.json()
        return [e["values"] for e in data["embeddings"]]
