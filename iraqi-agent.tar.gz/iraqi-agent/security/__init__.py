"""
security/__init__.py
Security primitives:
  - JWT issuance & verification
  - Password hashing
  - API key management per tenant
  - Rate limiting (slowapi)
  - RBAC
  - Audit log
"""
from .jwt_handler import issue_token, verify_token, require_admin
from .passwords import hash_password, verify_password
from .api_keys import APIKeyManager
from .rbac import Role, Permission, has_permission
from .audit import AuditLog
from .rate_limit import limiter, rate_limit

__all__ = [
    "issue_token", "verify_token", "require_admin",
    "hash_password", "verify_password",
    "APIKeyManager",
    "Role", "Permission", "has_permission",
    "AuditLog",
    "limiter", "rate_limit",
]
