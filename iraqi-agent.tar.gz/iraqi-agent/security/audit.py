"""
security/audit.py
Audit log of every privileged action.
"""
from __future__ import annotations
import time
import json
from typing import Dict, List, Optional
from pathlib import Path
from loguru import logger


class AuditLog:
    def __init__(self, path: str = "./logs/audit.log"):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def log(
        self,
        actor: str,                  # user/role performing
        action: str,                 # "tenant.create"
        target: str = "",            # what was affected
        details: dict = None,
        ip: str = "",
    ):
        entry = {
            "ts": time.time(),
            "actor": actor,
            "action": action,
            "target": target,
            "details": details or {},
            "ip": ip,
        }
        try:
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception as e:
            logger.error(f"Audit log write failed: {e!r}")

    def query(self, actor: str = None, action: str = None, limit: int = 100) -> List[dict]:
        if not self.path.exists():
            return []
        out: List[dict] = []
        with open(self.path, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    e = json.loads(line)
                except Exception:
                    continue
                if actor and e.get("actor") != actor: continue
                if action and e.get("action") != action: continue
                out.append(e)
        return out[-limit:]


_audit: AuditLog | None = None
def get_audit() -> AuditLog:
    global _audit
    if _audit is None:
        _audit = AuditLog()
    return _audit
