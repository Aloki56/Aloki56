"""
security/rate_limit.py
Rate limiting with slowapi. Applied to public endpoints to prevent abuse.
"""
from slowapi import Limiter
from slowapi.util import get_remote_address

# 100 req/min default
limiter = Limiter(key_func=get_remote_address, default_limits=["100/minute"])


def rate_limit(times: str):
    """Decorator shorthand: @rate_limit("10/minute")"""
    def deco(func):
        return limiter.limit(times)(func)
    return deco
