"""
security/rbac.py
Role-based access control.
"""
from enum import Enum
from typing import Set


class Role(str, Enum):
    OWNER = "owner"           # platform owner (you)
    ADMIN = "admin"           # platform operator
    TENANT_OWNER = "tenant_owner"    # restaurant/cafe owner
    TENANT_AGENT = "tenant_agent"    # restaurant staff
    CUSTOMER = "customer"


class Permission(str, Enum):
    # Tenant management
    CREATE_TENANT = "tenant.create"
    DELETE_TENANT = "tenant.delete"
    SUSPEND_TENANT = "tenant.suspend"
    VIEW_TENANTS = "tenant.view"

    # Tenant self-service
    EDIT_OWN_TENANT = "tenant.edit_own"
    UPLOAD_KB = "kb.upload"
    VIEW_OWN_STATS = "stats.view_own"

    # Billing
    MANAGE_BILLING = "billing.manage"
    VIEW_BILLING = "billing.view"

    # Conversations
    VIEW_CONVERSATIONS = "conversations.view"
    BROADCAST = "conversations.broadcast"

    # System
    VIEW_ALL_STATS = "system.view_all_stats"
    MANAGE_PROVIDERS = "system.manage_providers"


ROLE_PERMISSIONS: dict[Role, Set[Permission]] = {
    Role.OWNER: set(Permission),
    Role.ADMIN: {
        Permission.CREATE_TENANT, Permission.DELETE_TENANT, Permission.SUSPEND_TENANT,
        Permission.VIEW_TENANTS, Permission.EDIT_OWN_TENANT, Permission.UPLOAD_KB,
        Permission.VIEW_OWN_STATS, Permission.MANAGE_BILLING, Permission.VIEW_BILLING,
        Permission.VIEW_CONVERSATIONS, Permission.BROADCAST,
        Permission.VIEW_ALL_STATS, Permission.MANAGE_PROVIDERS,
    },
    Role.TENANT_OWNER: {
        Permission.EDIT_OWN_TENANT, Permission.UPLOAD_KB,
        Permission.VIEW_OWN_STATS, Permission.VIEW_BILLING,
        Permission.VIEW_CONVERSATIONS, Permission.BROADCAST,
    },
    Role.TENANT_AGENT: {
        Permission.VIEW_OWN_STATS, Permission.VIEW_CONVERSATIONS,
    },
    Role.CUSTOMER: set(),
}


def has_permission(role: Role, perm: Permission) -> bool:
    return perm in ROLE_PERMISSIONS.get(role, set())
