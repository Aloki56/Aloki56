"""
security/jwt_handler.py
JWT issuance & verification.
"""
from __future__ import annotations
import time
from typing import Optional, Dict, Any
from fastapi import HTTPException, Header, Depends
from jose import jwt, JWTError
from pydantic import BaseModel

from core.config import get_settings


ALG = "HS256"


class TokenPayload(BaseModel):
    sub: str                 # subject (admin|tenant_id|user_id)
    role: str = "admin"      # admin | operator | tenant
    tenant_id: Optional[str] = None
    exp: int = 0


def issue_token(subject: str, role: str = "admin", tenant_id: str = None,
                ttl_seconds: int = 7 * 86400) -> str:
    s = get_settings()
    payload = {
        "sub": subject,
        "role": role,
        "tenant_id": tenant_id,
        "exp": int(time.time()) + ttl_seconds,
        "iat": int(time.time()),
    }
    return jwt.encode(payload, s.app_secret, algorithm=ALG)


def verify_token(token: str) -> TokenPayload:
    s = get_settings()
    try:
        data = jwt.decode(token, s.app_secret, algorithms=[ALG])
    except JWTError as e:
        raise HTTPException(401, f"Invalid token: {e}")
    return TokenPayload(**data)


async def require_admin(authorization: Optional[str] = Header(None)) -> TokenPayload:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Missing bearer token")
    token = authorization.split(" ", 1)[1]
    payload = verify_token(token)
    if payload.role not in ("admin", "operator"):
        raise HTTPException(403, "Admin only")
    return payload
