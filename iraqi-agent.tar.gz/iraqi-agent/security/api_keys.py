"""
security/api_keys.py
Per-tenant API keys for programmatic access to the agent.
"""
from __future__ import annotations
import secrets
import hashlib
from typing import Optional


class APIKeyManager:
    def __init__(self):
        # key_hash -> tenant_id
        self._store: dict[str, str] = {}

    def generate(self, tenant_id: str) -> str:
        raw = "ak_" + secrets.token_urlsafe(32)
        self._store[self._hash(raw)] = tenant_id
        return raw

    def verify(self, key: str) -> Optional[str]:
        return self._store.get(self._hash(key))

    def revoke(self, tenant_id: str):
        for h, t in list(self._store.items()):
            if t == tenant_id:
                self._store.pop(h, None)

    def _hash(self, raw: str) -> str:
        return hashlib.sha256(raw.encode()).hexdigest()


_mgr: APIKeyManager | None = None
def get_api_key_manager() -> APIKeyManager:
    global _mgr
    if _mgr is None:
        _mgr = APIKeyManager()
    return _mgr
