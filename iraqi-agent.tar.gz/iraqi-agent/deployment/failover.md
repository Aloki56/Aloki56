# deployment/failover.md
# Multi-server free failover setup.

# Components:
# 1) Fly.io (primary)  → always-on, free
# 2) Oracle Cloud VM  → always-on, free
# 3) Upstash Redis    → free 10k req/day, holds leadership state
# 4) Cloudflare DNS   → free, points to the current leader
# 5) healthchecks.io  → free, alerts if the leader dies

# Flow:
# - All instances run the same Docker image.
# - Every 20s each instance tries `SET <key> leader-<id> EX 25 NX`.
# - The first to succeed becomes "leader". Others stay "standby".
# - Standbys poll the public URL of the leader every 60s.
#   If leader is down for >90s, a standby:
#     a) takes leadership in Redis,
#     b) updates a Cloudflare DNS A-record (via API) to its own public IP.
# - healthchecks.io receives a ping every 30s from the current leader.
#   If the ping is missed, you get an email/Telegram alert.

# Why this is bulletproof:
# - Each "free" instance can die. The next one auto-takes over.
# - You get alerts when something is wrong.
# - Cloudflare free tier handles DNS, so no downtime for the user.

# ---- Minimal Python snippet (scripts/failover.py) ----

import os, time, json, socket, requests, redis

CF_API = "https://api.cloudflare.com/client/v4"
CF_TOKEN = os.environ["CF_TOKEN"]
CF_ZONE = os.environ["CF_ZONE_ID"]
CF_RECORD = os.environ["CF_RECORD_ID"]   # A record for your domain
PUBLIC_IP = os.environ["PUBLIC_IP"]      # this instance's public IP
REDIS_URL = os.environ["UPSTASH_REDIS_URL"]

r = redis.from_url(REDIS_URL)
KEY = "iraqi-agent:leader"
HEARTBEAT_TTL = 25
ID = f"{socket.gethostname()}-{os.getpid()}"

def am_i_leader():
    return r.set(KEY, ID, ex=HEARTBEAT_TTL, nx=True) or r.get(KEY) == ID.encode()

def renew():
    r.set(KEY, ID, ex=HEARTBEAT_TTL)

def become_leader():
    r.set(KEY, ID, ex=HEARTBEAT_TTL)
    # Update DNS
    requests.put(
        f"{CF_API}/zones/{CF_ZONE}/dns_records/{CF_RECORD}",
        headers={"Authorization": f"Bearer {CF_TOKEN}"},
        json={"type": "A", "name": "agent", "content": PUBLIC_IP, "ttl": 60, "proxied": False},
    ).raise_for_status()

while True:
    if am_i_leader():
        renew()
        print("I am leader")
    else:
        print("standby")
    time.sleep(20)
