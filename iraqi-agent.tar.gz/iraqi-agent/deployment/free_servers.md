# Free Cloud Deployment — كلشي بالمجاني 🆓

هنا عندك خيارات متعدد للسيرفرات المجانية. مو كلهم يستوون ٢٤/٧، فأنصح تخلّي **٢–٣** منهم شغّالين بنظام failover حتى لو واحد نام، الثاني يگوم.

---

## 1. Fly.io — ⭐ الأفضل للسيرفر الرئيسي (مجاني للأبد)
- ٣ VMs بـ 256MB RAM + 3GB volume = **مجاني ١٠٠٪**
- ما ينام (no auto-stop) ✓
- يدعم Node + Python + Docker ✓

**الإعداد:**
```bash
# ثبّت flyctl
curl -L https://fly.io/install.sh | sh

# سجّل
fly auth signup

# بمجلد المشروع
fly launch --copy-config --name iraqi-agent
fly secrets set \
  APP_SECRET=$(openssl rand -hex 32) \
  GROQ_API_KEY=gsk_xxx \
  GOOGLE_API_KEY=xxx \
  TELEGRAM_BOT_TOKEN=xxx \
  ADMIN_TELEGRAM_ID=123456789 \
  WA_BRIDGE_AUTH=$(openssl rand -hex 16)
fly deploy
fly volumes create iraqi_data --size 1
```

**النتيجة:** راح تحصل على URL مثل `https://iraqi-agent.fly.dev`.

---

## 2. Render.com — جيد، بس ينام
- Web service مجاني ٧٥٠ ساعة/شهر
- **ينام** بعد ١٥ دقيقة بدون حركة (cold start ~50 ثانية)

**الإعداد:**
1. ارفع الكود على GitHub
2. في Render → New → Blueprint → اختر الريبو
3. راح يقرأ `render.yaml` تلقائياً وينشئ الخدمة

**ملاحظة:** للـ WhatsApp bridge، النوم مشكلة — لأنه ما يوصل messages إذا نايم. **الحل**: استخدم الخيار ١ (Fly.io) للسيرفر الرئيسي.

---

## 3. Railway.app
- $5 رصيد مجاني شهرياً
- ما ينام ✓
- للاستخدام الخفيف يكفي شهر كامل مجاناً

**الإعداد:**
1. اربط حساب GitHub
2. New Project → Deploy from GitHub
3. عدّل الـ Variables بنفس مفاتيح .env

---

## 4. Oracle Cloud "Always Free"
- VPS مجاني للأبد (ARM، 4 cores، 24GB RAM)
- الأقوى بالمجاني، بس يحتاج إعداد يدوي

```bash
# SSH إلى VM
ssh ubuntu@<your-vm-ip>

# ثبّت Docker
sudo apt update
sudo apt install -y docker.io docker-compose
sudo usermod -aG docker ubuntu
# logout & login again

# شغّل
git clone <your-repo> iraqi-agent
cd iraqi-agent
cp .env.example .env
nano .env  # fill in keys
docker compose up -d
```

---

## 5. Koyeb.com
- Web service مجاني
- ما ينام ✓
- Deploys from GitHub

---

## 6. Hugging Face Spaces (Docker)
- مجاني، بس مخصص أكثر لعروض ML
- مناسب إذا تبي نموذج محلي

---

## 🛡 Failover تلقائي (نظام "ما يموت أبداً")

الفكرة: شغّل الوكيل على **٢–٣** سيرفرات مجانية بنفس الـ DB (Supabase / Neon). كل سيرفر:
- يحفظ heartbeat على Redis مجاني (Upstash)
- يگلب من السيرفرات الثانية — إذا الثاني مات، يگوم يأخذ مكانه

**الملف `deployment/failover.md` يوضح الكود بالتفصيل، باختصار:**

```python
# كل 30 ثانية
- اذا أنا مش شغّال، صرت leader
- اذا فيه leader ثاني، أنا standby
- لو leader ما ارسل heartbeat من 60 ثانية، هذاك standby ياخذ الـ DNS
```

**الـ DNS المجاني**: Cloudflare (free tier) يوجه لـ IP الـ leader.

---

## 📊 مقارنة سريعة

| المنصة         | مجاني؟   | ينام؟  | مناسب لـ       |
|----------------|----------|--------|----------------|
| Fly.io         | ✓ للأبد  | ❌     | الرئيسي        |
| Render         | ✓ شهرياً | ✅ بعد 15 دق | تطوير/تجربة  |
| Railway        | ✓ $5/شهر | ❌     | الرئيسي البديل |
| Oracle Cloud   | ✓ للأبد  | ❌     | المتحكمين      |
| Koyeb          | ✓        | ❌     | السريع         |
| HuggingFace    | ✓        | ❌     | النماذج المحلية |

---

## 🔑 اعتماداتي (التوصية)

1. **Fly.io** = السيرفر الرئيسي (24/7 مجاناً)
2. **Oracle Cloud** = السيرفر الاحتياطي (24/7 مجاناً)
3. **healthchecks.io** = مراقب مجاني يرسلي تنبيه إذا واحد منهم نام
4. **Upstash Redis** = تنسيق بين السيرفرات (مجاني ١٠k requests/يوم)

كلهم **مجاني ١٠٠٪**، ولو امتلأ أي واحد من الحدود، شغّل سيرفر رابع.
