"""
channels/email/imap_smtp.py
Generic IMAP+SMTP fallback for any email account.
Useful for custom domains like info@your-iraqi-restaurant.com.
"""
from __future__ import annotations
import asyncio
from typing import Optional, Dict, Any
import aiosmtplib
from email.message import EmailMessage
from loguru import logger

from channels.base import ChannelAdapter


class IMAPAdapter(ChannelAdapter):
    name = "imap_smtp"

    def __init__(self):
        self._connected = True

    @property
    def is_connected(self) -> bool:
        return self._connected

    async def start(self):
        logger.info("📧 IMAP/SMTP adapter ready")

    async def stop(self):
        self._connected = False

    async def send(self, recipient_id: str, text: str, **kwargs):
        tenant = kwargs.get("tenant")
        smtp_host = kwargs.get("smtp_host")
        smtp_port = kwargs.get("smtp_port", 587)
        smtp_user = kwargs.get("smtp_user")
        smtp_pass = kwargs.get("smtp_pass")
        if not (smtp_host and smtp_user and smtp_pass):
            logger.error("IMAP send: missing SMTP credentials")
            return False
        msg = EmailMessage()
        msg["From"] = smtp_user
        msg["To"] = recipient_id
        msg["Subject"] = kwargs.get("subject", "رد تلقائي")
        msg.set_content(text)
        try:
            await aiosmtplib.send(
                msg, hostname=smtp_host, port=smtp_port,
                username=smtp_user, password=smtp_pass, start_tls=True,
            )
            return True
        except Exception as e:
            logger.error(f"SMTP send failed: {e!r}")
            return False
