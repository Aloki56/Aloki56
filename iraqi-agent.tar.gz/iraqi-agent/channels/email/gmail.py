"""
channels/email/gmail.py
Gmail adapter — uses the Gmail API (OAuth2).
Free, official, 1B quota/day (way more than we need).
"""
from __future__ import annotations
import asyncio
from typing import Dict, Any, Optional
from loguru import logger

from channels.base import ChannelAdapter
from channels.manager import get_manager


class GmailAdapter(ChannelAdapter):
    name = "gmail"

    def __init__(self):
        self._connected = False
        self._creds_by_tenant: Dict[str, Any] = {}

    @property
    def is_connected(self) -> bool:
        return self._connected

    async def start(self):
        # OAuth flow handled at tenant-link time
        self._connected = True
        logger.info("📧 Gmail adapter ready (per-tenant OAuth)")

    async def stop(self):
        self._connected = False

    async def send(self, recipient_id: str, text: str, **kwargs):
        tenant = kwargs.get("tenant")
        if not tenant or not tenant.email or "gmail.com" not in tenant.email:
            logger.error("Gmail send: tenant has no Gmail account")
            return False
        # Production: use google-api-python-client with stored refresh_token
        # For now, log + return True so the rest of the flow works.
        logger.info(f"📧 [Gmail → {recipient_id}] {text[:200]}")
        return True

    async def poll_inbox(self, tenant_id: str):
        """Called by a periodic task to pull new messages.
        Implement with googleapiclient.discovery + history.list"""
        # TODO: implement Gmail History API poll
        return []
