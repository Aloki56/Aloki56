"""
channels/email/__init__.py
Email channels — Gmail and Outlook / generic IMAP+SMTP.
"""
from .gmail import GmailAdapter
from .outlook import OutlookAdapter
from .imap_smtp import IMAPAdapter

__all__ = ["GmailAdapter", "OutlookAdapter", "IMAPAdapter"]
