"""
channels/email/outlook.py
Microsoft Graph / Outlook adapter.
Free, official, via Microsoft Graph API.
"""
from __future__ import annotations
import httpx
from typing import Optional, Dict, Any
from loguru import logger

from channels.base import ChannelAdapter
from channels.manager import get_manager


GRAPH = "https://graph.microsoft.com/v1.0"


class OutlookAdapter(ChannelAdapter):
    name = "outlook"

    def __init__(self):
        self._http = httpx.AsyncClient(timeout=20)
        self._connected = True

    @property
    def is_connected(self) -> bool:
        return self._connected

    async def start(self):
        logger.info("📧 Outlook adapter ready")

    async def stop(self):
        await self._http.aclose()

    async def send(self, recipient_id: str, text: str, **kwargs):
        tenant = kwargs.get("tenant")
        token = kwargs.get("access_token")
        if not token:
            logger.error("Outlook send: missing access_token")
            return False
        r = await self._http.post(
            f"{GRAPH}/me/sendMail",
            headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
            json={
                "message": {
                    "subject": kwargs.get("subject", "رد تلقائي"),
                    "body": {"contentType": "Text", "content": text},
                    "toRecipients": [{"emailAddress": {"address": recipient_id}}],
                },
                "saveToSentItems": "true",
            },
        )
        if r.status_code >= 300:
            logger.error(f"Outlook send failed: {r.status_code} {r.text}")
            return False
        return True
