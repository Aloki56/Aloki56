"""
channels/manager.py
Central registry — owns one adapter per channel, routes inbound
messages to the agent, and pushes replies back.
"""
from __future__ import annotations
import asyncio
from typing import Dict, Optional, Any
from loguru import logger

from core.agent import get_agent
from core.config import get_settings
from tenants.store import get_store
from channels.base import ChannelAdapter


class ChannelManager:
    def __init__(self):
        self.adapters: Dict[str, ChannelAdapter] = {}
        self._tasks: list[asyncio.Task] = []
        # tenant_id -> {"channel": "...", "value": "..."}  reverse lookup
        self._route: Dict[str, Dict[str, str]] = {}

    # --- registration ---
    def register(self, adapter: ChannelAdapter):
        self.adapters[adapter.name] = adapter
        logger.info(f"📡 Channel registered: {adapter.name}")

    def has(self, name: str) -> bool:
        return name in self.adapters

    def get(self, name: str) -> Optional[ChannelAdapter]:
        return self.adapters.get(name)

    # --- lifecycle ---
    async def start_all(self):
        for name, ad in self.adapters.items():
            try:
                await ad.start()
                logger.info(f"✅ Channel started: {name}")
            except Exception as e:
                logger.error(f"❌ Channel {name} failed to start: {e!r}")

    async def stop_all(self):
        for name, ad in self.adapters.items():
            try:
                await ad.stop()
            except Exception:
                pass

    # --- routing ---
    async def handle_inbound(
        self,
        channel: str,
        user_id: str,
        text: str,
        user_name: Optional[str] = None,
        tenant_id: Optional[str] = None,
        raw: Optional[Dict[str, Any]] = None,
    ):
        """Called by adapters. Resolves tenant → replies → sends back."""
        # 1) Find tenant
        if tenant_id is None:
            # Try to find by some other signal
            tenant = get_store().find_by_channel(channel, user_id)
            if not tenant:
                # Maybe a direct message to the bot itself
                logger.warning(f"⚠️  No tenant for {channel}:{user_id}")
                return None
            tenant_id = tenant.tenant_id
        else:
            tenant = get_store().get(tenant_id)

        if not tenant or tenant.status != "active":
            logger.info(f"⏸  Tenant {tenant_id} not active — message dropped")
            return None

        # 2) Generate reply
        agent = get_agent()
        result = await agent.reply(
            tenant=tenant.to_storage() if hasattr(tenant, "to_storage") else tenant,
            channel=channel,
            user_id=user_id,
            user_message=text,
            user_name=user_name,
        )

        # 3) Send back
        adapter = self.get(channel)
        if adapter:
            try:
                await adapter.send(user_id, result["text"])
            except Exception as e:
                logger.error(f"❌ Send back on {channel} failed: {e!r}")

        return result


_manager: Optional[ChannelManager] = None
def get_manager() -> ChannelManager:
    global _manager
    if _manager is None:
        _manager = ChannelManager()
    return _manager
