"""
channels/messenger.py
Meta Messenger adapter (also free for messaging use cases).

Same shape as the Instagram adapter — webhook-driven. A tenant
binds a Facebook Page; we receive messages via webhook and reply
through the Send API.
"""
from __future__ import annotations
from typing import Dict, Any
import httpx
from loguru import logger

from channels.base import ChannelAdapter


GRAPH = "https://graph.facebook.com/v20.0"


class MessengerAdapter(ChannelAdapter):
    name = "messenger"

    def __init__(self):
        self._http = httpx.AsyncClient(timeout=15)

    @property
    def is_connected(self) -> bool:
        return True

    async def start(self):
        logger.info("💬 Messenger adapter ready (webhook-driven)")

    async def stop(self):
        await self._http.aclose()

    async def handle_webhook_event(self, event: Dict[str, Any]):
        try:
            entry = event.get("entry", [{}])[0]
            page_id = entry.get("id")
            from tenants.store import get_store
            tenant = None
            for t in get_store().list_all():
                if t.channels.messenger_page_id == page_id:
                    tenant = t
                    break
            if not tenant:
                logger.warning(f"No tenant for FB page {page_id}")
                return
            for m in entry.get("messaging", []):
                sender_id = m.get("sender", {}).get("id")
                msg = m.get("message") or {}
                text = msg.get("text")
                if not text or not sender_id:
                    continue
                from channels.manager import get_manager
                result = await get_manager().handle_inbound(
                    channel="messenger",
                    user_id=sender_id,
                    text=text,
                    tenant_id=tenant.tenant_id,
                )
                if result:
                    await self.send(sender_id, result["text"], tenant=tenant)
        except Exception as e:
            logger.error(f"Messenger webhook error: {e!r}")

    async def send(self, recipient_id: str, text: str, **kwargs):
        tenant = kwargs.get("tenant")
        if not tenant or not tenant.channels.messenger_page_token:
            logger.error("Messenger send: missing tenant page token")
            return False
        url = f"{GRAPH}/me/messages"
        params = {"access_token": tenant.channels.messenger_page_token}
        payload = {
            "recipient": {"id": recipient_id},
            "message": {"text": text},
        }
        r = await self._http.post(url, params=params, json=payload)
        if r.status_code >= 300:
            logger.error(f"Messenger send failed: {r.status_code} {r.text}")
            return False
        return True
