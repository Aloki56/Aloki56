/**
 * channels/whatsapp/server.js
 *
 * Baileys-based WhatsApp bridge. Runs as a separate Node process.
 * Exposes a tiny HTTP+WS interface to the Python side:
 *
 *   GET  /qr          -> PNG/SVG QR for first-time pairing
 *   GET  /status      -> { connected, phone, lastError }
 *   POST /send        -> { to, text }  -> send a message
 *   WS   /ws          -> bidirectional event stream (Python subscribes)
 *
 * Auth: shared secret in header `x-auth: <WA_BRIDGE_AUTH>`.
 * First run will print a QR to the console and to GET /qr.
 */

require("dotenv").config();
const express = require("express");
const http = require("http");
const QRCode = require("qrcode-terminal");
const { WebSocketServer } = require("ws");
const pino = require("pino");
const {
  default: makeWASocket,
  DisconnectReason,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
} = require("@whiskeysockets/baileys");

const logger = pino({ level: process.env.LOG_LEVEL || "info" });
const PORT = parseInt(process.env.WA_BRIDGE_PORT || "3001", 10);
const AUTH = process.env.WA_BRIDGE_AUTH || "change-me";

let sock = null;
let currentQR = null;
let connectedPhone = null;
let lastError = null;
const wsClients = new Set();

function broadcast(evt) {
  const msg = JSON.stringify(evt);
  for (const c of wsClients) {
    try { c.send(msg); } catch (_) {}
  }
}

async function startSock() {
  const { state, saveCreds } = await useMultiFileAuthState("./data/wa_auth");
  const { version } = await fetchLatestBaileysVersion();

  sock = makeWASocket({
    version,
    auth: state,
    printQRInTerminal: false,
    logger: pino({ level: "warn" }),
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect, qr } = update;
    if (qr) {
      currentQR = qr;
      QRCode.generate(qr, { small: true });
      broadcast({ type: "qr", qr });
    }
    if (connection === "open") {
      connectedPhone = sock.user?.id?.split(":")[0];
      currentQR = null;
      lastError = null;
      logger.info({ phone: connectedPhone }, "WhatsApp connected");
      broadcast({ type: "connected", phone: connectedPhone });
    }
    if (connection === "close") {
      const reason = lastDisconnect?.error?.output?.statusCode;
      lastError = `Disconnected (code=${reason})`;
      logger.warn({ reason }, "WhatsApp disconnected");
      broadcast({ type: "disconnected", reason });
      if (reason !== DisconnectReason.loggedOut) {
        setTimeout(startSock, 3000);
      } else {
        logger.error("Logged out — delete ./data/wa_auth and re-pair");
      }
    }
  });

  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;
    for (const m of messages) {
      if (!m.message || m.key.fromMe) continue;
      const text =
        m.message.conversation ||
        m.message.extendedTextMessage?.text ||
        m.message.imageMessage?.caption ||
        "";
      if (!text) continue;
      const userId = m.key.remoteJid; // e.g. 9647701234567@s.whatsapp.net
      const userName = m.pushName || "";
      broadcast({
        type: "message",
        userId,
        userName,
        text,
        raw: m,
      });
    }
  });
}

const app = express();
app.use(express.json({ limit: "1mb" }));
app.use((req, res, next) => {
  if (req.headers["x-auth"] !== AUTH) return res.status(401).end();
  next();
});

app.get("/status", (req, res) => {
  res.json({
    connected: !!connectedPhone,
    phone: connectedPhone,
    lastError,
    hasQR: !!currentQR,
  });
});

app.get("/qr", async (req, res) => {
  if (!currentQR) return res.status(404).json({ error: "No QR — already connected?" });
  // Return as text + data URL alternative
  res.json({ qr: currentQR });
});

app.post("/send", async (req, res) => {
  const { to, text } = req.body || {};
  if (!sock || !connectedPhone) return res.status(503).json({ error: "Not connected" });
  if (!to || !text) return res.status(400).json({ error: "Missing 'to' or 'text'" });
  try {
    const jid = to.includes("@") ? to : `${to}@s.whatsapp.net`;
    await sock.sendMessage(jid, { text });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

app.post("/logout", async (req, res) => {
  try {
    if (sock) await sock.logout();
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: "/ws" });
wss.on("connection", (ws) => {
  wsClients.add(ws);
  ws.on("close", () => wsClients.delete(ws));
  ws.send(JSON.stringify({ type: "hello", connected: !!connectedPhone }));
});

server.listen(PORT, () => {
  logger.info(`WhatsApp bridge listening on :${PORT}`);
  startSock().catch((e) => logger.error({ err: e }, "startSock failed"));
});
