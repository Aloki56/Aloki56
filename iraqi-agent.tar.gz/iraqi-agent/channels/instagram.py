"""
channels/instagram.py
Instagram DM adapter via Meta Graph API (free for messaging use cases).

How it works:
- You connect an Instagram BUSINESS account to a Meta App.
- Subscribe to `messages` webhook events.
- We verify the webhook (GET /webhook), then handle POSTs.

Per-tenant: the page access token + IG business ID live in the
tenant record (linked via the Telegram bot).
"""
from __future__ import annotations
import asyncio
from typing import Optional, Dict, Any
import httpx
from loguru import logger

from core.config import get_settings
from channels.base import ChannelAdapter
from channels.manager import get_manager


GRAPH = "https://graph.facebook.com/v20.0"


class InstagramAdapter(ChannelAdapter):
    name = "instagram"

    def __init__(self):
        self._connected = True   # Webhook-driven, always "connected" once app is set up
        self._http = httpx.AsyncClient(timeout=15)

    @property
    def is_connected(self) -> bool:
        return self._connected

    async def start(self):
        # Nothing to do — the FastAPI app will register the webhook.
        logger.info("📷 Instagram adapter ready (webhook-driven)")

    async def stop(self):
        await self._http.aclose()

    # Used by the FastAPI webhook endpoint
    async def handle_webhook_event(self, event: Dict[str, Any]):
        """Process one webhook event from Meta."""
        try:
            entry = event.get("entry", [{}])[0]
            # Determine which IG business ID this is for
            ig_business_id = entry.get("id")
            # Find the tenant by IG business ID
            from tenants.store import get_store
            tenant = None
            for t in get_store().list_all():
                if t.channels.instagram_business_id == ig_business_id:
                    tenant = t
                    break
            if not tenant:
                logger.warning(f"No tenant for IG business {ig_business_id}")
                return

            for m in entry.get("messaging", []):
                sender_id = m.get("sender", {}).get("id")
                if not sender_id:
                    continue
                # Text message?
                text = None
                for msg in m.get("message", {}).get("text", ""):
                    pass
                msg_block = m.get("message") or {}
                text = msg_block.get("text") or msg_block.get("quick_reply", {}).get("payload")
                if not text:
                    continue

                mgr = get_manager()
                # Force-tenant to this IG business
                result = await mgr.handle_inbound(
                    channel="instagram",
                    user_id=sender_id,
                    text=text,
                    user_name=None,
                    tenant_id=tenant.tenant_id,
                )
                # Reply
                if result:
                    await self.send(sender_id, result["text"], tenant=tenant)
        except Exception as e:
            logger.error(f"Instagram webhook error: {e!r}")

    async def send(self, recipient_id: str, text: str, **kwargs):
        tenant = kwargs.get("tenant")
        if not tenant or not tenant.channels.instagram_page_token:
            logger.error("Instagram send: missing tenant page token")
            return False
        url = f"{GRAPH}/me/messages"
        payload = {
            "recipient": {"id": recipient_id},
            "message": {"text": text},
        }
        params = {"access_token": tenant.channels.instagram_page_token}
        r = await self._http.post(url, params=params, json=payload)
        if r.status_code >= 300:
            logger.error(f"IG send failed: {r.status_code} {r.text}")
            return False
        return True
