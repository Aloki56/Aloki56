"""
channels/base.py
Abstract base class every channel adapter must implement.
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Optional, Awaitable, Callable, Dict, Any
from loguru import logger


class ChannelAdapter(ABC):
    name: str = "base"

    @abstractmethod
    async def start(self):
        """Connect / open the channel."""
        ...

    @abstractmethod
    async def stop(self):
        """Tear down the channel."""
        ...

    @abstractmethod
    async def send(self, recipient_id: str, text: str, **kwargs):
        """Push a text message to `recipient_id` on this channel."""
        ...

    @property
    @abstractmethod
    def is_connected(self) -> bool:
        ...


# All adapters expose the same `on_inbound` event. The FastAPI / bot
# framework registers a handler that:
#   1. resolves the tenant (who is this message for?)
#   2. calls core.agent.reply(...)
#   3. sends the reply back through the same adapter.
InboundHandler = Callable[[str, str, str, str, Dict[str, Any]], Awaitable[None]]
# signature: (channel, user_id, user_name, text, raw) -> None
