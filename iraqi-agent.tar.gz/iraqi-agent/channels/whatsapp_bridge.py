"""
channels/whatsapp_bridge.py
Python-side adapter that talks to the Node Baileys bridge over WS+HTTP.

We DON'T try to wrap Baileys in Python — it's a Node library with
no clean Python equivalent. Instead we run the Node server alongside
the Python app and use a thin WebSocket / HTTP shim.
"""
from __future__ import annotations
import asyncio
import json
from typing import Optional, Dict, Any
import httpx
import websockets
from loguru import logger

from core.config import get_settings
from channels.base import ChannelAdapter
from channels.manager import get_manager


class WhatsAppBridge(ChannelAdapter):
    name = "whatsapp"

    def __init__(self):
        s = get_settings()
        self.http_url = s.wa_bridge_http
        self.ws_url = s.wa_bridge_url
        self.auth = s.wa_bridge_auth
        self._ws: Optional[websockets.WebSocketClientProtocol] = None
        self._connected = False
        self._loop_task: Optional[asyncio.Task] = None

    @property
    def is_connected(self) -> bool:
        return self._connected

    async def start(self):
        self._loop_task = asyncio.create_task(self._run_ws())

    async def stop(self):
        if self._loop_task:
            self._loop_task.cancel()
        if self._ws:
            try:
                await self._ws.close()
            except Exception:
                pass

    async def _run_ws(self):
        """Maintain a persistent WS connection to the bridge."""
        backoff = 2
        while True:
            try:
                headers = {"x-auth": self.auth}  # ignored by WS, but useful
                async with websockets.connect(
                    self.ws_url, additional_headers=headers
                ) as ws:
                    self._ws = ws
                    logger.info("📡 Connected to WhatsApp bridge WS")
                    backoff = 2
                    async for raw in ws:
                        try:
                            evt = json.loads(raw)
                        except Exception:
                            continue
                        await self._on_event(evt)
            except Exception as e:
                logger.warning(f"WhatsApp bridge WS error: {e!r}, retry in {backoff}s")
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 60)

    async def _on_event(self, evt: dict):
        t = evt.get("type")
        if t == "connected":
            self._connected = True
            logger.info(f"✅ WhatsApp connected: {evt.get('phone')}")
        elif t == "disconnected":
            self._connected = False
            logger.warning(f"⚠️  WhatsApp disconnected: {evt.get('reason')}")
        elif t == "qr":
            # print a hint to the logs (the Node side already prints it)
            logger.info("📱 New QR code — scan from /wa/qr endpoint")
        elif t == "message":
            mgr = get_manager()
            await mgr.handle_inbound(
                channel="whatsapp",
                user_id=evt["userId"],
                text=evt.get("text", ""),
                user_name=evt.get("userName"),
            )

    async def send(self, recipient_id: str, text: str, **kwargs):
        if not self._connected:
            logger.warning("Cannot send — WhatsApp not connected")
            return False
        async with httpx.AsyncClient(timeout=15) as c:
            r = await c.post(
                f"{self.http_url}/send",
                headers={"x-auth": self.auth},
                json={"to": recipient_id, "text": text},
            )
            r.raise_for_status()
            return True
