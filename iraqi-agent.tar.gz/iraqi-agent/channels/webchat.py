"""
channels/webchat.py
Web Chat Widget — embeddable JavaScript snippet that connects
to the FastAPI backend via WebSocket.

Usage on a customer site:
<script src="https://agent.example.com/widget.js"></script>
"""
from __future__ import annotations
import asyncio
import secrets
from typing import Dict, Optional
from fastapi import WebSocket
from loguru import logger

from channels.base import ChannelAdapter
from channels.manager import get_manager


# In-memory map of active widget sessions: ws -> {tenant_id, user_id}
_widget_sessions: Dict[int, Dict[str, str]] = {}


class WebChatAdapter(ChannelAdapter):
    name = "webchat"

    def __init__(self):
        self._connected = True

    @property
    def is_connected(self) -> bool:
        return self._connected

    async def start(self):
        logger.info("🌐 Web chat adapter ready")

    async def stop(self):
        self._connected = False

    async def send(self, recipient_id: str, text: str, **kwargs):
        # recipient_id is the WebSocket object id (or a session token)
        ws = kwargs.get("ws")
        if ws is None:
            return False
        try:
            await ws.send_json({"type": "message", "text": text})
            return True
        except Exception as e:
            logger.error(f"WebChat send failed: {e!r}")
            return False


async def websocket_endpoint(websocket: WebSocket, tenant_id: str):
    """Called by the FastAPI route. Handles a single visitor session."""
    await websocket.accept()
    user_id = "web-" + secrets.token_hex(6)
    logger.info(f"🌐 WebSocket connected: tenant={tenant_id} user={user_id}")
    try:
        while True:
            data = await websocket.receive_json()
            if data.get("type") == "message":
                text = data.get("text", "")
                mgr = get_manager()
                await mgr.handle_inbound(
                    channel="webchat",
                    user_id=user_id,
                    text=text,
                    user_name=data.get("user_name"),
                    tenant_id=tenant_id,
                )
                # Reply is sent via webchat.send
    except Exception as e:
        logger.info(f"WebSocket closed: {e!r}")


WIDGET_JS = r"""
(function(){
  if (window.IraqiAgentWidget) return;
  var TENANT = document.currentScript.getAttribute('data-tenant') || '';
  var API    = document.currentScript.getAttribute('data-api')    || '';
  var COLOR  = document.currentScript.getAttribute('data-color')  || '#f5576c';
  window.IraqiAgentWidget = true;

  var box = document.createElement('div');
  box.style.cssText = 'position:fixed;bottom:20px;right:20px;width:360px;height:520px;background:#fff;border-radius:16px;box-shadow:0 10px 40px rgba(0,0,0,.2);display:none;flex-direction:column;z-index:99999;font-family:Tahoma,sans-serif;overflow:hidden;';
  box.innerHTML = ''
    + '<div style="background:'+COLOR+';color:#fff;padding:14px;font-weight:bold;">💬 المساعد الذكي</div>'
    + '<div id="ia-messages" style="flex:1;overflow-y:auto;padding:12px;background:#fafafa;"></div>'
    + '<div style="display:flex;border-top:1px solid #eee;">'
    +   '<input id="ia-input" placeholder="اكتب رسالتك..." style="flex:1;border:0;padding:12px;outline:none;font-size:14px;" />'
    +   '<button id="ia-send" style="background:'+COLOR+';color:#fff;border:0;padding:0 18px;cursor:pointer;">إرسال</button>'
    + '</div>';
  document.body.appendChild(box);

  var btn = document.createElement('button');
  btn.style.cssText = 'position:fixed;bottom:20px;right:20px;width:60px;height:60px;border-radius:50%;background:'+COLOR+';color:#fff;border:0;font-size:28px;cursor:pointer;box-shadow:0 5px 20px rgba(0,0,0,.3);z-index:99999;';
  btn.innerHTML = '💬';
  btn.onclick = function(){ box.style.display = box.style.display==='none' ? 'flex' : 'none'; };
  document.body.appendChild(btn);

  var ws;
  function connect(){
    var proto = location.protocol === 'https:' ? 'wss' : 'ws';
    ws = new WebSocket(proto + '://' + location.host + '/ws/webchat/' + TENANT);
    ws.onopen  = function(){ console.log('Iraqi Agent connected'); };
    ws.onclose = function(){ setTimeout(connect, 3000); };
    ws.onmessage = function(e){
      var m = JSON.parse(e.data);
      if (m.type === 'message') addBubble(m.text, 'agent');
    };
  }
  function addBubble(text, who){
    var d = document.createElement('div');
    d.style.cssText = 'max-width:75%;padding:8px 12px;margin:4px 0;border-radius:12px;font-size:14px;line-height:1.5;'
      + (who==='user' ? 'background:'+COLOR+';color:#fff;margin-left:auto;text-align:right;' : 'background:#e8e8e8;color:#222;');
    d.textContent = text;
    var m = document.getElementById('ia-messages');
    m.appendChild(d);
    m.scrollTop = m.scrollHeight;
  }
  document.getElementById('ia-send').onclick = sendMsg;
  document.getElementById('ia-input').onkeydown = function(e){ if (e.key==='Enter') sendMsg(); };
  function sendMsg(){
    var v = document.getElementById('ia-input').value.trim();
    if (!v) return;
    addBubble(v, 'user');
    ws.send(JSON.stringify({type:'message', text:v}));
    document.getElementById('ia-input').value = '';
  }
  connect();
})();
"""
