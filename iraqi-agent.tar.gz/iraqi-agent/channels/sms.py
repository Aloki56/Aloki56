"""
channels/sms.py
SMS gateway adapter. Twilio (free trial) or local Iraqi providers
(AlfaCell, Kalimat, etc.) via HTTP.
"""
from __future__ import annotations
import httpx
from typing import Optional
from loguru import logger

from core.config import get_settings
from channels.base import ChannelAdapter
from channels.manager import get_manager


class SMSAdapter(ChannelAdapter):
    name = "sms"

    def __init__(self):
        s = get_settings()
        self._http = httpx.AsyncClient(timeout=20)
        self.twilio_sid = s.twilio_account_sid
        self.twilio_token = s.twilio_auth_token
        self.twilio_from = s.twilio_from_number

    @property
    def is_connected(self) -> bool:
        return True

    async def start(self):
        logger.info("📱 SMS adapter ready")

    async def stop(self):
        await self._http.aclose()

    async def send(self, recipient_id: str, text: str, **kwargs):
        # Try Twilio first
        if self.twilio_sid and self.twilio_token and self.twilio_from:
            return await self._send_twilio(recipient_id, text)
        # Fallback: a configurable HTTP endpoint
        return await self._send_generic(recipient_id, text, **kwargs)

    async def _send_twilio(self, to: str, text: str) -> bool:
        url = f"https://api.twilio.com/2010-04-01/Accounts/{self.twilio_sid}/Messages.json"
        r = await self._http.post(
            url,
            auth=(self.twilio_sid, self.twilio_token),
            data={"From": self.twilio_from, "To": to, "Body": text},
        )
        if r.status_code >= 300:
            logger.error(f"Twilio SMS failed: {r.status_code} {r.text}")
            return False
        return True

    async def _send_generic(self, to: str, text: str, **kwargs) -> bool:
        from core.config import get_settings
        s = get_settings()
        if not s.sms_provider_url:
            logger.warning("No SMS provider configured; logging only")
            logger.info(f"📱 [SMS → {to}] {text[:200]}")
            return False
        try:
            r = await self._http.post(
                s.sms_provider_url,
                json={"to": to, "text": text, "api_key": s.sms_provider_key},
            )
            return r.status_code < 300
        except Exception as e:
            logger.error(f"Generic SMS send failed: {e!r}")
            return False
