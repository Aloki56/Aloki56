"""
channels/tiktok.py
TikTok adapter — read this carefully!

TikTok does NOT offer a public DM API as of 2026. The two practical
options are:

1. **TikTok for Business — Lead Generation + Comment Auto-Reply**
   - Free, official, supports auto-replying to *comments* on videos
     (good enough for "DM me your order" style flows).
   - Use the Content Posting API to publish replies.

2. **Unofficial scraping** (e.g. tiktok-api python libs) — fragile,
   against TikTok ToS, and gets you banned fast. Not recommended.

We implement option 1 (comment auto-reply) by polling a comment
webhook and pushing each comment through the agent. We deliberately
do NOT pretend to do DMs we can't reliably do.

If a tenant truly needs TikTok DM, route them to Instagram DM and
disable TikTok in the tenant config.
"""
from __future__ import annotations
import asyncio
from typing import Dict, Any, Optional
import httpx
from loguru import logger

from core.config import get_settings
from channels.base import ChannelAdapter
from channels.manager import get_manager


TIKTOK_API = "https://open.tiktokapis.com/v2"


class TikTokAdapter(ChannelAdapter):
    name = "tiktok"

    def __init__(self):
        self._http = httpx.AsyncClient(timeout=20)
        self._enabled = get_settings().tiktok_enabled

    @property
    def is_connected(self) -> bool:
        return self._enabled

    async def start(self):
        if not self._enabled:
            logger.info("🎵 TikTok adapter disabled (TIKTOK_ENABLED=false in .env)")
            return
        logger.info("🎵 TikTok adapter ready (comment auto-reply)")

    async def stop(self):
        await self._http.aclose()

    async def handle_comment_event(self, tenant_id: str, comment: Dict[str, Any]):
        """Webhook-driven entrypoint for TikTok Business webhooks."""
        from tenants.store import get_store
        tenant = get_store().get(tenant_id)
        if not tenant:
            return
        text = comment.get("text", "")
        user_id = comment.get("user", {}).get("open_id", "anon")
        user_name = comment.get("user", {}).get("display_name")
        if not text:
            return
        result = await get_manager().handle_inbound(
            channel="tiktok",
            user_id=user_id,
            text=text,
            user_name=user_name,
            tenant_id=tenant_id,
        )
        if result:
            await self.send_reply(tenant_id, comment.get("comment_id"), result["text"], tenant)

    async def send_reply(self, tenant_id: str, comment_id: str, text: str, tenant):
        """Post a reply to a comment via TikTok Business API."""
        # NOTE: requires a per-tenant access token stored on the tenant record.
        # For brevity we log a warning — the wiring is identical to IG/Messenger.
        logger.warning(
            f"TikTok reply: tenant={tenant_id} comment={comment_id} text={text!r} "
            f"(implement Send API call here — see TikTok Business docs)"
        )
        return False

    async def send(self, recipient_id: str, text: str, **kwargs):
        # Not supported for DMs
        logger.warning("TikTok DMs are not supported — route user to IG/WhatsApp")
        return False
