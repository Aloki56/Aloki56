"""Channels package: WhatsApp, Instagram, Messenger, TikTok adapters."""
