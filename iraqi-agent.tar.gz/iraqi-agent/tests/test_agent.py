"""
tests/test_agent.py
Smoke tests that don't hit any LLM (mock the router).
"""
import asyncio
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

os.environ.setdefault("APP_SECRET", "test-secret")
os.environ.setdefault("ADMIN_TELEGRAM_ID", "1")
os.environ.setdefault("TINYDB_PATH", "./data/test_tenants.json")

from core.prompts import build_system_prompt
from core.iraqi import detect_intent, normalize_iraqi, add_iraqi_flavor
from tenants.schemas import Tenant
from tenants.store import TenantStore


def test_iraqi_intent():
    assert "greeting" in detect_intent("هلا شلونك")
    assert "menu" in detect_intent("شو عندكم من أكل")
    assert "order" in detect_intent("أبي أطلب كباب")
    assert "price" in detect_intent("بكم البرجر؟")
    assert "location" in detect_intent("وين المطعم")
    assert "complaint" in detect_intent("الأكل بارد")
    print("✅ test_iraqi_intent")


def test_iraqi_normalize():
    assert "كثير" in normalize_iraqi("عندي هواية شغل")
    assert "كيف" in normalize_iraqi("شلونك")
    print("✅ test_iraqi_normalize")


def test_flavor_injection():
    out = add_iraqi_flavor("الأكل جاهز")
    assert "خيو" in out
    print("✅ test_flavor_injection")


def test_prompt_build():
    t = {
        "tenant_id": "test",
        "business_name": "مطعم بغداد",
        "business_type": "مطعم",
        "phone": "0770xxx",
        "address": "بغداد",
        "working_hours": "١٠-٢٣",
        "branches": "—",
        "knowledge_base": "كباب ٧٥٠٠ د.ع",
    }
    p = build_system_prompt(t)
    assert "بغداد" in p
    assert "Iraqi" in p or "مساعد" in p
    print("✅ test_prompt_build")


def test_tenant_store():
    import os
    if os.path.exists("./data/test_tenants.json"):
        os.remove("./data/test_tenants.json")
    s = TenantStore("./data/test_tenants.json")
    t = Tenant(
        tenant_id="test1",
        business_name="محل تجريبي",
        owner_name="أبو",
        owner_phone="0",
    )
    s.upsert(t)
    assert s.get("test1") is not None
    assert s.list_all()[0].tenant_id == "test1"
    s.delete("test1")
    assert s.get("test1") is None
    print("✅ test_tenant_store")


if __name__ == "__main__":
    test_iraqi_intent()
    test_iraqi_normalize()
    test_flavor_injection()
    test_prompt_build()
    test_tenant_store()
    print("\n🎉 كل التيستات passed")
